#include	<ctype.h>

int (isupper)(int c) {
	return isupper(c);
}
