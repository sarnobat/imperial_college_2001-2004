#include	<ctype.h>

int (isxdigit)(int c) {
	return isxdigit(c);
}
