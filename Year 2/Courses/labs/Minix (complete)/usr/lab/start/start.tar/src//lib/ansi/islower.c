#include	<ctype.h>

int (islower)(int c) {
	return islower(c);
}
