#include	<ctype.h>

int (ispunct)(int c) {
	return ispunct(c);
}
