/* $Header: nfa.c,v 2.2 90/11/06 12:59:32 ceriel Exp $ */
/*
 * (c) copyright 1990 by the Vrije Universiteit, Amsterdam, The Netherlands.
 * See the copyright notice in the ACK home directory, in the file "Copyright".
 */

/* Author: Hans van Eck */

#include	<pc_err.h>

extern _trp();

_nfa(bool)
{
	if (! bool) _trp(EFUNASS);
}
