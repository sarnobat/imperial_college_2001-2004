#include	<ctype.h>

int (iscntrl)(int c) {
	return iscntrl(c);
}
