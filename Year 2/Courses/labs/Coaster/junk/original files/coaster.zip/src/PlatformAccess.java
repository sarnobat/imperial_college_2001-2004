

/**
 * Complete the implementation of this class in line with the FSP model
 */

public class PlatformAccess {

  /* declarations required */

  public void arrive() throws InterruptedException {
    // complete implementation
  }

  public synchronized void depart() {
    // complete implementation
  }

}