<?
// Edit these variable names to reflect Yours.

$DBhost = "localhost";
$DBuser = "Your User Name";
$DBpass = "The database Password";
$DBName = "The database Name";
$table = "saveMovie";

?>