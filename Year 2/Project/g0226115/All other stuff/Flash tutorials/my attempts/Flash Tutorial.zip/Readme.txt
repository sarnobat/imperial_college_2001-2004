Title:  Introduction to using mySQL with PHP in Flash

Author: Jeffrey F. Hill

Recent Changes:  In case you are reading an older tutorial.  Please use the Include.php file instead of Include.inc file.  This was an overlook on my part.  The reason being that anyone that knew the link to your Include.inc file could download that file and view your database password.  Using the Include.php file eliminates this problem.  

For Support:
Please visit any of the following sites,

The Flashkit Message board (Scripting and Backend) - www.flashkit.com

PHPBuilder  - www.phpbuilder.com

Zend.com 'where PHP meets e-business' (Has complete documentation) - www.zend.com

PHP.net - Complete online PHP Documentation

mySQL.com - Information regarding mySQL



Also I'll try to post comments once in a while below the example for this Tutorial.


- www.flash-db.com
