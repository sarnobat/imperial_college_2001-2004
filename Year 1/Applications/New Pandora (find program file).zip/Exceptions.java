package NewPand;

/* this file consists of the class definitions for the
   exceptions the Pandora program might throw */


class InvalidTokenException extends Exception
{
	InvalidTokenException()
	/* constructor I - no parameters */
	{
		super();
	}

	InvalidTokenException(String message)
	/* constructor II - with a message */
	{
		super(message);
	}

}


class LexAnalyserException extends Exception
{
	LexAnalyserException()
	/* constructor I - no parameters */
	{
		super();
	}

	LexAnalyserException(String message)
	/* constructor II - with a message */
	{
		super(message);
	}

}

class InvalidCharException extends Exception
{
	InvalidCharException()
	/* constructor I - no parameters */
	{
		super();
	}

	InvalidCharException(String message)
	/* constructor II - with a message */
	{
		super(message);
	}

}

class InvalidIdentException extends Exception
{
	InvalidIdentException()
	/* constructor I - no parameters */
	{
		super();
	}

	InvalidIdentException(String message)
	/* constructor II - with a message */
	{
		super(message);
	}

}
class ParserException extends Exception
{
	ParserException()
	/* constructor I - no parameters */
	{
		super();
	}

	ParserException(String message)
	/* constructor II - with a message */
	{
		super(message);
	}

}

class InvalidContextException extends Exception
{

	InvalidContextException()
	/* constructor I - no parameters */
	{
		super();
	}

	InvalidContextException(String message)
	/* constructor II - with a message */
	{
		super(message);
	}

}

class InvalidOffsetException extends Exception
{
	InvalidOffsetException()
	/* constructor I - no parameters */
	{
		super();
	}

	InvalidOffsetException(String message)
	/* constructor II - with a message */
	{
		super(message);
	}

}