package NewPand;

/* this file defines the class the representing the dialog box
   which appears when some error (e.g. when saving/loading a proof)
   occurs */

import java.awt.*;
import java.util.*;

public class ErrorDlg extends Dialog
{

	/* member variables */
	
	Panel top; /* to hold the table */
	Panel bottom; /* to hold the 'ok' button */
	Label errorMessage; /* to display error message */
	String theMessage; /* to hold the actual error message */
	
	/* the dialog button */
	Button ok;

	/* methods */

	ErrorDlg(Frame parent, String message)
	/* constructor */   
	{
		super(parent, "Error", true);
		theMessage = message;
	}

	public void initialise()
	/* called for initialisation of dialog box with the
	   saving option */
	{
		setLayout(new BorderLayout());
		Panel top = new Panel();
		Panel bottom = new Panel();
		Font f = new Font("Helvetica", Font.BOLD, 14);
		setFont(f);
		Label errorMessage = new Label(theMessage);
		top.add(errorMessage);
		ok = new Button("OK");
		bottom.add(ok);
		add("South", bottom);
		add("Center", top);
		setBackground(new Color(200,200,200));
		pack();
		setResizable(false);
	}

	public boolean action(Event evt, Object target)
	/* to handle the button events */
	{
		if (evt.target == ok)
		{
			dispose();
			return true;
		}
		return false;
	}

	public boolean handleEvent(Event evt)
	/* to handle the window events */
	{
		switch (evt.id)
		{
			case Event.WINDOW_DESTROY :
			{
				dispose();
				return true;
			}
			default : return super.handleEvent(evt);
		}

	}
}