package NewPand;

//******************************************************************************
// NewPandora.java:	The main application file
//******************************************************************************

import java.applet.*;
import java.awt.*;
import java.util.*;
import java.io.*;

public class NewPandora extends Applet implements Runnable, Serializable
/* the main NewPandora class */
{
	/* =================== MEMBER VARIABLES ==================== */

	/* the thread object for this applet - for thread support.
	   NOTE: this version does not use threads at all */
	private transient Thread m_NewPandora = null;

	/* isStandAlone will be set to true if applet is run standalone.
	   NOTE: in the current version, the applet can only run 
	   standalone (isStandAlone is set to true in 'main') */
	private boolean isStandAlone = false;

	/* panels for holding screen elements */
	Panel top, bottom, statusBar, mainArea, topSub, functs, input;
	Scrollbar horiz, vert; /* horizontal and vertical scroll bars */
	int horizOffset,vertOffset; /* horizontal and vertical offsets (for scrolling) */
	Label status, saveStatus; /* the status bar */
	TextField proofStatus; /* the status of the current proof: either
							  "NO PROOF IN PROGRESS", "<no file>" or 
							  a specific valid file name */
	String currentFile; /* the current proof file */
	String currentDir; /* the absolute directory of the current file */
	TextArea appMsg; /* where messages to the user will be displayed */
	TextField dataEntry; /* where data. conclusion, etc. will be entered */
	Label assump; /* to indicate current assumption read */
	int currAssump; /* the index of the current assumption */
	ExprTree currExp; /* current expression read */
	ContextTree main; /* the main context */
	ProofArea pArea; /* the main proof area */
	ProofLine currLine; /* the currently selected line */
	String currRule; /* holds the rule currently being applied - 
					    only applicable for rules which require 
						the user to choose proof lines - e.g. ^I
						fowards */
	int currClick; /* how many times the user has clicked a proof line;
				      used to detect when the user has chosen all the
					  proof lines necessary for applying a rule */
	ProofLine clicked1; /* the first proof line the user has clicked */
	ProofLine clicked2; /* the second proof line the user has clicked */
	FontMetrics fm; /* the font metrics object */
	static transient Toolkit t; /* used for getting the screen size */
	static Dimension screenSize; /* the screen size */
	
	Button btnNewProof, btnLoadProof, btnQuit, 
		   btnAddAssump, btnFinishGiven, btnAcceptData, 
		   btnCancelData, btnApplyRule, btnUndo, btnCancelRule;
	Choice applyRule; /* a combo-box to choose the rule to apply */
	CheckboxGroup ruleTypes; /* the set of radio buttons for rule types */
	Checkbox intro, elim, others; /* to represent the different rule
								     type */
	
	int lineBoxHeight; /* once determined, the height of boxes around lines
					      is constant throughout */
	int lineHeight; /* the same as above, except this is the actual font height */
	
	int currentX, currentY;
	boolean inProgress; /* to indicate whether a proof is in progress */
	int dataEntryState; /* 0 if reading assumption, 1 if reading conclusion,
						   2 if reading data for "OrI"/"BottomE"/"Lemma", 
						   3 if adding assumption while constructing proof,
						   4 if reading data for "ForAllE"/"ThereExistsI"/"Reflex",
						   5 if reading data for "Eqsub",
						   6 if reading data for theorem mappings,
						   7 if reading no. of free vars (theorems),
						   8 if reading the free-variables,
						   9 otherwise */
	boolean isSaved; /* to indicate whether current proof is saved or not */
	int clickStatus; /* 0 if clicking a line would do nothing, 1 if waiting
	                    for user to select a line (e.g. when applying a rule),
						2 if clicking would make a line current */
	long currSkolem; /* a counter for generating skolem constants */
	DataInput datain; /* the parser */
	Stack undoStack; /* stack containing the previous actions taken
					    by the user - used for the Undo feature */

	public final int ENTER = 10; /* the code of the "Enter" key */
	public final int LEFTS = 108; /* the code of the 'l' key */
	public final int RIGHTS = 114; /* the code of the 'r' key */
	public final int BOTHS = 98; /* the code of the 'b' key */
	public final int LEFTC = 76; /* the code of the 'L' key */
	public final int RIGHTC = 82; /* the code of the 'R' key */
	public final int BOTHC = 66; /* the code of the 'B' key */
	public final int YESS = 121; /* the code of the 'y' key */
	public final int NOS = 110; /* the code of the 'n' key */
	public final int YESC = 89; /* the code of the 'Y' key */
	public final int NOC = 78; /* the code of the 'N' key */
	
	static final int winWidth = 760; /* width of applet frame */
	static final int winHeight = 570; /* height of applet frame */

	final int subDist = 10; /* the minimum distance between a
							   box and any one of its sub-boxes */
	final int siblingDist = 5; /* the minimum distance between
	 							  a box and its sibling, e.g. 
								  in And Introduction */

	/* the two variables below are only used for equality 
	   substitution (eqsub) */
	private int occurrences;
	private int tempLeftOrRight;

	int loadOrNewOrQuit; /* used to indicate whether user wants to load
					        a proof or start a new one - used when 
					        user selects the menu items "Load Proof" 
							and "New Proof". 
							Mapping: 0 -> load, 1 -> new, 2 -> quit */

	private Properties printPrefs; /* the user printer preferences */

	/* the 9 variables below are used for theorems */
	private Hashtable mappings; /* mappings for applying theorems */
	private Vector mapKeys; /* the elements that need to be mapped */
	int currMap; /* the current mapping */
	String currTheorem; /* the theorem currently processed */
	ExprTree currTheoremTree; /* the tree of the current theorem */
	ExprTree currInstanceExpr; /* the instance of the theorem */
	int numFreeVars; /* number of free variables in theorem instance */
	Vector freeVars; /* the list of free variables */
	int currFreeVar; /* the index of the current free var */


	/* ======================== METHODS ========================= */

	public static void main(String args[])
	/* first method called when application is started */
	{
		/* create top-level window to contain the application */
		NewPandoraFrame frame = new NewPandoraFrame("Welcome to New Pandora");

		frame.show();
        frame.hide();
		
		t = Toolkit.getDefaultToolkit();
		screenSize = t.getScreenSize();

		MainMenu menu = new MainMenu(frame);
		menu.CreateMenu();
		
		/* now disable some menu items */
		Vector disable = new Vector();
		disable.addElement("Save Proof");
		disable.addElement("Save Proof As...");
		disable.addElement("Print Proof");
		disable.addElement("Save As Theorem");
		disable.addElement("Kill Box");
		disable.addElement("Undo");
		disable.addElement("Clear Box");
		disable.addElement("Global Tables...");
		disable.addElement("Add Given");
		disable.addElement("Apply Theorem");
		disable.addElement("What Now?");
		menuItems(disable, frame, false);

		/* The following code starts the application running within the frame window.
		   It also sets isStandAlone to true */
		
		NewPandora applet_NewPandora = new NewPandora();

		frame.setLayout(new BorderLayout());
		frame.add("Center",applet_NewPandora);
		frame.setApp(applet_NewPandora);
		
		applet_NewPandora.isStandAlone = true;
		applet_NewPandora.init();
		applet_NewPandora.start();

		/* resize the main frame */
		frame.reshape((screenSize.width - winWidth) / 2 , (screenSize.height - winHeight) / 2,
			          winWidth, winHeight);

		/* show the frame */
        frame.show();
	}

	public static void menuItems(Vector theItems, Frame theFrame,
								 boolean enable)
	/* a method to disable or enable the specified menu items in the menu
	   bar of the specified frame. Note: this cannot enable or disable
	   items of a sub-menu. The boolean enable indicates whether the
	   items are to be disabled or enabled */
	{
		MenuBar mb = theFrame.getMenuBar();
		for (int i = 0; i < mb.countMenus(); i++)
		/* do for each menu */
		{
			Menu m = mb.getMenu(i);
			for (int j = 0; j < m.countItems(); j++)
			/* do for each menu item */
			{
				MenuItem mi = m.getItem(j);
				if (theItems.contains(mi.getLabel()))
				/* if found what we wanted */
				{
					if (enable == true)
					{ 
						/* enable item */
						mi.enable();
					}
					else
					{
						/* disable item */
						mi.disable();
					}
				}
			}
		}
	}

	public NewPandora()
	/* NewPandora class constructor */
	{
	}

	public String getAppletInfo()
	{
		return "Name: New Pandora\r\n" +
		       "Author: Dan Ehrlich\r\n";
	}

	public void init()
	/* create and/or initialise user interface elements */
	{
		if (!isStandAlone)
		/* if running in a browser, need to create the application 
		   window here */
		{
			/* create top-level window to contain the application */
			NewPandoraFrame frame = new NewPandoraFrame("Welcome to New Pandora");

			frame.show();
			frame.hide();
		
			t = Toolkit.getDefaultToolkit();
			screenSize = t.getScreenSize();

			MainMenu menu = new MainMenu(frame);
			menu.CreateMenu();
		
			/* now disable some menu items */
			Vector disable = new Vector();
			disable.addElement("Load Proof");
			disable.addElement("Save Proof");
			disable.addElement("Save Proof As...");
			disable.addElement("Print Proof");
			disable.addElement("Save As Theorem");
			disable.addElement("Quit New Pandora");
			disable.addElement("Kill Box");
			disable.addElement("Undo");
			disable.addElement("Clear Box");
			disable.addElement("Global Tables...");
			disable.addElement("Add Given");
			disable.addElement("Apply Theorem");
			disable.addElement("What Now?");
			disable.addElement("User Guide");
			menuItems(disable, frame, false);

			frame.setLayout(new BorderLayout());
			frame.add("Center", this);
			frame.setApp(this);
		
			/* resize the main frame */
			frame.reshape((screenSize.width - winWidth) / 2 , (screenSize.height - winHeight) / 2,
				           winWidth, winHeight);

			/* show the frame */
			frame.show();
		}

		setLayout(new BorderLayout());
		
		top = new Panel();
		top.setLayout(new BorderLayout());
		
		mainArea = new Panel();
		mainArea.setLayout(new BorderLayout());
		
		topSub = new Panel();
		topSub.setLayout(new BorderLayout());

		functs = new Panel();
		functs.setLayout(new FlowLayout(FlowLayout.LEFT));
		functs.setBackground(new Color(145,145,145));
				
		/* create the main context and proof area */
		main = new ContextTree();
		main.setApp(this);
		pArea = new ProofArea(this);
				
		/* set background of proof area to a very light gray */
		pArea.setBackground(Color.white);
		pArea.setFont(new Font("Helvetica", Font.BOLD, 12));
		
		horiz = new Scrollbar(Scrollbar.HORIZONTAL,0,10,0,500);
		vert = new Scrollbar(Scrollbar.VERTICAL,0,10,0,500);
		horiz.disable();
		vert.disable();
				
		mainArea.add("East", vert);
		mainArea.add("South", horiz);
		mainArea.add("Center", pArea);

		btnNewProof = new Button("Start a new proof");
		btnLoadProof = new Button("Load a proof");
		btnQuit = new Button("Quit");
		if (!isStandAlone)
		/* disable load and quit buttons if running in browser */
		{
			btnLoadProof.disable();
			btnQuit.disable();
		}

		functs.add(btnNewProof);
		functs.add(btnLoadProof);
		functs.add(btnQuit);
		
		input = new Panel();
		input.setLayout(new FlowLayout(FlowLayout.LEFT));
	
		topSub.add("Center", functs);

		top.add("North", topSub);
		top.add("Center", mainArea);
		
		bottom = new Panel();
		bottom.setBackground(Color.lightGray);
		bottom.setLayout(new BorderLayout());

		statusBar = new Panel();
		statusBar.setLayout(new GridLayout(1,3));

		status = new Label("INITIALISING...");
		proofStatus = new TextField("NO PROOF IN PROGRESS");
		proofStatus.setEditable(false);
		saveStatus = new Label("", Label.RIGHT);
				
		Font f1 = new Font("Helvetica", Font.BOLD, 12);
		Font f2 = new Font("Times New Roman", Font.PLAIN, 12);
		status.setFont(f1);
		proofStatus.setFont(f2);
		saveStatus.setFont(f1);

		statusBar.add(status);
		statusBar.add(proofStatus);
		statusBar.add(saveStatus);

		appMsg = new TextArea(6,1);
		appMsg.setFont(f1);
		appMsg.setForeground(Color.blue);
		appMsg.setBackground(Color.white);
		appMsg.setEditable(false);
		appMsg.setText("Welcome to New Pandora - the Natural Deduction proof assistant !");
		appMsg.appendText("\n\nThis text area will be used extensively to display messages ");
		appMsg.appendText("to you as you work on your proofs, so watch this space!");
		appMsg.appendText("\nPlease choose now whether to start a new proof or load an ");
		appMsg.appendText("existing one by clicking on the corresponding button above.");
		
		bottom.add("North", appMsg);
		bottom.add("Center", statusBar);

		add("South", bottom);
		add("Center", top);

		/* initialise some member variables */
		currentY = 5;
		currentX = 5;
		horizOffset = 0;
		vertOffset = 0;
		fm = pArea.getFontMetrics(pArea.getFont());

		status.setText("READY");
		inProgress = false;
		isSaved = false;
		currentFile = null;
		currentDir = null;
		printPrefs = new Properties();
		clickStatus = 0;
		dataEntryState = 9;
		currRule = new String("");			
	}

	public void destroy()
	{
	}

	public void paint(Graphics g)
	/* NewPandora Paint Handler */
	{
		pArea.paintMe(horizOffset, vertOffset);
	}

	public void start()
	{
		if (m_NewPandora == null)
		{
			m_NewPandora = new Thread(this);
			m_NewPandora.start();
		}
	}
	
	public void stop()
	/* can only be called when application runs in a browser. 
	   Actually called when applet is stopped by the user */
	{
		if (m_NewPandora != null)
		{
			m_NewPandora.stop();
			m_NewPandora = null;
		}
		
		/* destroy the application window and any dialog boxes */
		((NewPandoraFrame)this.getParent()).dispose();
	}

	public void run()
	{
	
	}

	public boolean handleEvent(Event evt)
	/* this method is called whenever a specific user-interface action
	   is performed, e.g. user clicking on a scrollbar */
	{
		if (evt.target == horiz)
		/* if event concerns the horizontal scroll bar */
		{
			try
			{	switch (evt.id)
				{
					case Event.SCROLL_LINE_DOWN :
					case Event.SCROLL_LINE_UP :
					case Event.SCROLL_PAGE_DOWN :
					case Event.SCROLL_PAGE_UP :
					case Event.SCROLL_ABSOLUTE :
						int newValue = horiz.getValue();
						horiz.setValues(newValue,10,0,500);
						setHorizOffset(newValue*5);
				}
			}
			catch (InvalidOffsetException e) 
			{ System.out.println(e.getMessage()); }
			pArea.paintMe(horizOffset, vertOffset);
			return true;
		}
		else if (evt.target == vert)
		/* if event concerns the vertical scroll bar */
		{
			try
			{
				switch (evt.id)
				{
					case Event.SCROLL_LINE_DOWN :
					case Event.SCROLL_LINE_UP :
					case Event.SCROLL_PAGE_DOWN :
					case Event.SCROLL_PAGE_UP :
					case Event.SCROLL_ABSOLUTE :
						int newValue = vert.getValue();
						vert.setValues(newValue,10,0,500);
						setVertOffset(vert.getValue()*5);
				}
			}
			catch (InvalidOffsetException e)
			{ System.out.println(e.getMessage()); }
			pArea.paintMe(horizOffset, vertOffset);
			return true;
		}
		return super.handleEvent(evt);
	}

	public boolean keyDown(Event evt, int key)
	/* to handle keyboard events */
	{
		if (clickStatus == 0)
		/* only handle event if not waiting for a mouse click */
		{
			if (key == ENTER)
			{
				if ((dataEntryState == 0) || (dataEntryState == 1))
				/* if reading some initial data from user */
				{
					if (((Button)functs.getComponent(0)).getLabel().equals("Accept"))
					{
						if (dataEntryState == 0)
						/* if reading assumptions */
						{
							/* add the assumption the user has entered */
							addAssumption();
						}
						else if (dataEntryState == 1)
						/* if reading conclusion */
						{
							/* add the conclusion the user has entered */
							addConclusion();
						}
						return true;
					}
					else 
					{
						return false;
					}
				}
				else
				{
					return false;
				}
			}
			else if ((key == LEFTS) || (key == RIGHTS) || (key == LEFTC)
				    || (key == RIGHTC))
			/* if user has chosen a sub-structure (e.g. in AndE) */
			{
				if (currRule.equals("AndE"))
				/* if and elimination */
				{
					/* call appropriate method */
					andElimDone(clicked1, currLine, key);
					return true;
				}
				else if ((currRule.equals("OrI")) && (!(currLine.isEmpty())))
				/* if or introduction backwards */
				{
					/* call method */
					orIntroBackDone(currLine, key);
					return true;
				}
				else if (currRule.equals("IfAndOnlyIfE"))
				{
					/* call method */
					iffElimDone(clicked1, currLine, key);
					return true;
				}
				else if ((currRule.equals("Eqsub")) &&
						(!(currLine.isEmpty())) &&
						(!(dataEntryState == 5)))
				/* if eqsub backwards */
				{
					/* call method */
					eqsubBackChosenOrientation(key);
					return true;
				}
				else if ((currRule.equals("Eqsub")) &&
						(currLine.isEmpty()) &&
						(!(dataEntryState == 5)))
				/* if eqsub forwards */
				{
					/* call method */
					eqsubForChosenOrientation(key);
					return true;
				}
				else if ((currRule.equals("IfAndOnlyIfEquiv")) &&
					    (!(currLine.isEmpty())))
				/* if iff-equiv backwards */
				{
					/* call method */
					iffEquivBackDone(clicked1, currLine, key);
				}
				else if ((currRule.equals("IfAndOnlyIfEquiv")) &&
						(currLine.isEmpty()))
				/* if iff-equiv forwards */
				{
					/* call method */
					iffEquivForDone(clicked1, clicked2, currLine, key);
				}
			}
			else if ((key == BOTHS) || (key == BOTHC))
			/* for AndE - user has chosen to deduce both conjuncts */
			{
				if (currRule.equals("AndE"))
				{
					/* call appropriate method */
					andElimDone(clicked1, currLine, key);
					return true;
				}
			}
			else if ((key == YESS) || (key == YESC))
			/* if user has confirmed to clear/kill box */
			{
				if (currRule.equals("ClearBox"))
				/* if clear box */
				{
					/* re-enable buttons / menu items */
					returnFromClicked();
					/* call method */
					clearBoxDone();
					return true;
				}
				else if (currRule.equals("KillBox"))
				/* if kill box */
				{
					/* re-enable buttons / menu items */
					returnFromClicked();
					/* call method */
					killBoxDone();
					return true;
				}
				else if ((currRule.equals("ApplyTheorem")) &&
					     (dataEntryState == 9))
				/* if applying theorem */
				{
					theoremDone();
					return true;
				}
			}
			else if ((key == NOS) || (key == NOC))
			/* if user cancelled clearing/killing a box */
			{
				if ((currRule.equals("ClearBox")) ||
				   (currRule.equals("KillBox")) ||
				   ((currRule.equals("ApplyTheorem")) &&
				    (dataEntryState == 9)))
				{
					/* re-enable buttons / menu items */
					returnFromClicked();
					appMsg.setText("Action cancelled.");
					return true;
				}
			}
			return false;
		}
		return false;
	}

	public boolean action(Event evt, Object what)
	/* to handle the button events */
	{
		if (evt.target == btnQuit)
		{
			((Frame)this.getParent()).dispose();
			System.exit(0);
			return true;
		}
		else if (evt.target == btnLoadProof)
		{
			loadProof();
			return true;
		}
		else if (evt.target == btnNewProof)
		{
			newProof();
			return true;
		}
		else if (evt.target == btnAddAssump)
		{
			if (dataEntryState == 0)
			/* if reading assumptions */
			{
				/* check the assumption the user has entered */
				checkAssumption(dataEntry.getText());
			}
			else if (dataEntryState == 1)
			/* if reading conclusion */
			{
				/* check the conclusion the user has entered */
				checkConclusion(dataEntry.getText());
			}
			return true;
		}
		else if (evt.target == btnFinishGiven)
		{
			prepareConclusion();
			return true;
		}
		else if (evt.target == btnAcceptData)
		{	
			if (dataEntryState == 0)
			/* if reading assumptions */
			{
				/* check the assumption the user has entered */
				addAssumption();
			}
			else if (dataEntryState == 1)
			/* if reading conclusion */
			{
				/* check the conclusion the user has entered */
				addConclusion();
			}
			return true;
		}
		else if (evt.target == btnCancelData)
		{
			functs.remove(btnAcceptData);
			functs.remove(btnCancelData);
			functs.add(btnAddAssump);
			if (dataEntryState == 0)
			/* if reading assumptions */
			{
				functs.add(btnFinishGiven);
			}
			validate();
			GlobalTables.initTempLists();
			appMsg.setText("Entry cancelled. Please re-enter ...");
			dataEntry.enable();
			dataEntry.requestFocus();
			return true;
		}
		else if (evt.target == dataEntry)
		{	
			if (dataEntryState == 0)
			/* if reading assumptions */
			{
				/* check the assumption the user has entered */
				checkAssumption((String)what);
			}
			else if (dataEntryState == 1)
			/* if reading conclusion */
			{
				/* check the conclusion the user has entered */
				checkConclusion((String)what);
			}
			else if (dataEntryState == 2)
			/* if reading data for OrI/BottomE/Lemma */
			{
				/* check the given information */
				if (currRule.equals("OrI"))
				{
					orIntroForDone(clicked1, currLine, (String)what);
				}
				else if (currRule.equals("BottomE"))
				{
					bottomElimForDone(clicked1, currLine, (String)what);
				}
				else if (currRule.equals("Lemma"))
				{
					lemmaDone(currLine, (String)what);
				}
			}
			else if (dataEntryState == 3)
			/* if adding new givens */
			{
				/* check the given information */
				addGivenDone((String)what);
			}
			else if (dataEntryState == 4)
			/* if selecting a term for "ForAllE"/"ThereExistsI"/"Reflex" */
			{
				if (currRule.equals("ForAllE"))
				{
					forAllElimDone(clicked1, currLine, (String)what);
				}
				else if (currRule.equals("ThereExistsI"))
				{
					thereExistsIntroDone(currLine, (String)what);
				}
				else if (currRule.equals("Reflex"))
				{
					reflexDone(currLine, (String)what);
				}
			}
			else if (dataEntryState == 5)
			/* if indicating which occurrence to replace in "Eqsub" */
			{
				String input = (String)what;
				if (input.equalsIgnoreCase("all"))
				/* if user has chosen to replace all occurrences */
				{
					/* check whether we are applying the rule 
					   forwards or backwards */
					if (currLine.isEmpty())
					/* forwards */
					{
						eqsubForDone(clicked1, clicked2, currLine,
							         tempLeftOrRight, 0);
					}
					else
					{
						eqsubBackDone(clicked1, currLine, 
									  tempLeftOrRight, 0);
					}
				}
				else
				/* otherwise, must be a valid occurrence */
				{
					Integer value = null;
					try
					{
						value = Integer.valueOf(input);
					}
					catch (NumberFormatException e)
					/* if no valid integer - report error */
					{
						appMsg.setText("Invalid input. Please re-type...");
						dataEntry.requestFocus();
						return true;
					}
					int val = value.intValue();
					if ((val < 1) || (val > occurrences))
					/* if invalid occurrence */
					{
						appMsg.setText("Invalid occurrence. Please re-type...");
						dataEntry.requestFocus();
						return true;
					}
					else
					/* occurrence ok */
					{
						/* check whether are applying rule forwards
						   or backwards */
						if (currLine.isEmpty())
						/* forwards */
						{
							eqsubForDone(clicked1, clicked2, currLine,
								         tempLeftOrRight, val);
						}
						else
						{
							eqsubBackDone(clicked1, currLine,
							              tempLeftOrRight, val);
						}
					}	
				}
			}
			else if (dataEntryState == 6)
			/* if reading a mapping (for theorems) */
			{
				String input = (String)what;
				/* call the appropriate method */
				chosenMap(input);
			}
			else if (dataEntryState == 7)
			/* if reading the number of free variables (theorems) */
			{
				String input = (String)what;
				Integer value = null;
				try
				{
					value = Integer.valueOf(input);
				}
				catch (NumberFormatException e)
				/* if no valid integer - report error */
				{
					appMsg.setText("Invalid input. Please re-type...");
					dataEntry.requestFocus();
					return true;
				}
				int val = value.intValue();
				if (val < 0)
				/* if invalid */
				{
					appMsg.setText("Invalid input. Please re-type...");
					dataEntry.requestFocus();
					return true;
				}
				else if (val == 0)
				/* if no free vars */
				{
					/* go straight to obtaining the mappings */
					numFreeVars = 0;
					getMappings();
				}
				else
				{
					numFreeVars = val;
					currFreeVar = 1;
					dataEntryState = 8; /* indicate reading the free
										   variables */
					readNextFreeVar();
				}
			}
			else if (dataEntryState == 8)
			/* if reading free variables for theorems */
			{
				String var = (String)what;
				nextFreeVarDone(var);
			}
			return true;
		}
		else if (evt.target == intro)
		{
			if (((Boolean)what).booleanValue() == true)
			/* if user selected to show introduction rules */
			{
				applyRule.removeAll();
				applyRule.addItem("And Introduction");
				applyRule.addItem("Or Introduction");
				applyRule.addItem("Arrow Introduction");
				applyRule.addItem("Not Introduction");
				applyRule.addItem("For-All Introduction");
				applyRule.addItem("There-Exists Introduction");
				applyRule.addItem("If-And-Only-If Introduction");
				applyRule.addItem("For-All Arrow Introduction");
				applyRule.select(0);
			}
			return true;
		}
		else if (evt.target == elim)
		{
			if (((Boolean)what).booleanValue() == true)
			/* if user selected to show elimination rules */
			{
				applyRule.removeAll();
				applyRule.addItem("And Elimination");
				applyRule.addItem("Or Elimination");
				applyRule.addItem("Arrow Elimination");
				applyRule.addItem("Not Elimination");
				applyRule.addItem("For-All Elimination");
				applyRule.addItem("There-Exists Elimination");
				applyRule.addItem("If-And-Only-If Elimination");
				applyRule.addItem("Bottom Elimination");
				applyRule.select(0);
			}
			return true;
		}
		else if (evt.target == others)
		{
			if (((Boolean)what).booleanValue() == true)
			/* if user selected to show the other rules */
			{
				applyRule.removeAll();
				applyRule.addItem("Tick");
				applyRule.addItem("Trust Me!");
				applyRule.addItem("Not-Not (~~)");
				applyRule.addItem("Proof by Contradiction (PC)");
				applyRule.addItem("If-And-Only-If Equiv");
				applyRule.addItem("Lemma");
				applyRule.addItem("Reflex (x = x)");
				applyRule.addItem("Eqsub (Equality substitution)");
				applyRule.select(0);
			}
			return true;
		}
		else if (evt.target == btnApplyRule)
		/* if user clicked the "Apply Rule" button */
		{
			appRule(applyRule.getSelectedItem());
			return true;
		}
		else if (evt.target == btnUndo)
		/* if user clicked the "Undo" button */
		{
			undo();
			return true;
		}
		else if (evt.target == btnCancelRule)
		/* if user clicked the "Cancel" button to cancel rule */
		{
			returnFromClicked();
			appMsg.setText("Cancelled.");
			return true;
		}
		return false;
	}
				
	public ContextTree getContext()
	/* returns the main context of the application */
	{
		return main;
	}

	public boolean standAlone()
	/* returns the value of the boolean isStandAlone */
	{
		return isStandAlone;
	}

	public ProofArea getProofArea()
	/* returns the proof area object of this application */
	{
		return pArea;
	}

	public TextField getDataEntry()
	/* returns the data entry text field */
	{
		return dataEntry;
	}

	public void setLoadOrNewOrQuit(int b)
	/* sets the loadOrNewOrQuit member variable to b.
	   Pre-condition: b must be either 0, 1 or 2 */
	{
		loadOrNewOrQuit = b;
	}

	public int getLoadOrNewOrQuit()
	/* returns the value of the loadOrNewOrQuit member variable */
	{
		return loadOrNewOrQuit;
	}

	public void setHorizOffset(int newOffset)
		throws InvalidOffsetException
	/* sets the horizontal offset. Exception is generated if newOffset
	   is negative */
	{
		if (newOffset >= 0)
		{
			horizOffset = newOffset;
		}
		else
		{
			throw(new InvalidOffsetException("Can't have negative horizontal offset"));
		}
	}

	public void setVertOffset(int newOffset)
		throws InvalidOffsetException
	/* sets the vertical offset. Exception is generated if newOffset
	   is negative */
	{
		if (newOffset >= 0)
		{
			vertOffset = newOffset;
		}
		else
		{
			throw(new InvalidOffsetException("Can't have negative vertical offset"));
		}
	}

	public int getHorizOffset()
	/* returns the current horizontal offset */
	{
		return horizOffset;
	}

	public int getVertOffset()
	/* returns the current vertical offset */
	{
		return vertOffset;
	}

	public void startLoad()
	/* called when the user requests to load a proof from disk. Warns
	   the user that the current proof (if any) will be terminated */
	{
		if (inProgress == true)
		/* if proof is in progress - warn the user */
		{
			ConfirmDlg cd = new ConfirmDlg((Frame)this.getParent(), this);
			if ((dataEntryState == 0) || (dataEntryState == 1))
			/* if in data entry phase - can't save */
			{
				cd.initialiseWithoutSave();
			}
			else
			{
				cd.initialiseWithSave();
			}
			/* position dialog box in the middle of the screen */
			cd.move((int)((screenSize.width / 2) - (cd.size().width / 2)), 
					(int)((screenSize.height / 2) - (cd.size().height / 2)));
			cd.show();
		}
		else
		{
			loadProof();
		}
	}

	public void loadProof()
	/* called when the user wants to load a proof started earlier
	   which is stored on disk */
	{
		/* show platform-dependent file dialog */
		FileDialog fileDlg = new FileDialog((Frame)this.getParent(), "Load proof", FileDialog.LOAD);
		if (currentDir != null)
		{
			fileDlg.setDirectory(currentDir);
		}
		/* use wildcards */
		fileDlg.setFile("*.pan");
		fileDlg.show();

		/* get file name + directory that user has chosen */
		String fileName = fileDlg.getFile();
		String dirName = fileDlg.getDirectory();

		if (fileName != null)
		/* if user did not press cancel */
		{
			File theFile = new File(dirName + fileName);
			try
			{
				/* create the necessary input streams in order to read
				   the data */
				FileInputStream fin = new FileInputStream(theFile);
				ObjectInputStream oin = new ObjectInputStream(fin);
				/* read the application itself from the file */
				NewPandora NP = (NewPandora)oin.readObject();
				/* now read the global hash tables */
				Hashtable constants = (Hashtable)oin.readObject();
				GlobalTables.setConstTable(constants);
				Hashtable predicates = (Hashtable)oin.readObject();
				GlobalTables.setPredTable(predicates);
				Hashtable variables = (Hashtable)oin.readObject();
				GlobalTables.setVarTable(variables);
				Hashtable functors = (Hashtable)oin.readObject();
				GlobalTables.setFunctTable(functors);

				/* close output stream */
				oin.close();

				/* if successful, np is the loaded applet */
				NewPandoraFrame appWindow = (NewPandoraFrame)this.getParent();
				NewPandora oldNP = appWindow.getApp();
				appWindow.remove(oldNP);
				appWindow.add("Center", NP);
				appWindow.setApp(NP);

				/* enable some menu items */
				Vector enable = new Vector();
				enable.addElement("Save Proof");
				enable.addElement("Save Proof As...");
				enable.addElement("Print Proof");
				enable.addElement("Save As Theorem");
				enable.addElement("Global Tables...");
				enable.addElement("Undo");
				enable.addElement("Clear Box");
				enable.addElement("Kill Box");
				enable.addElement("Apply Theorem");
				enable.addElement("Add Given");
				enable.addElement("What Now?");
				NP.menuItems(enable, appWindow, true);

				appWindow.validate();
				
				/* perform some needed operations on loaded 
				   application */
				NP.justLoaded(dirName + fileName + " loaded OK.",
							  dirName + fileName, dirName);
				NP.repaint(); /* update canvas to show state of loaded
								 proof */
			}
			catch (FileNotFoundException e)
			{	
				ErrorDlg ed = new ErrorDlg((Frame)this.getParent(),
				                       "Could not load: Invalid file/path name!");
				ed.initialise();
				/* position dialog box in the middle of the screen */
				ed.move((int)((screenSize.width / 2) - (ed.size().width / 2)), 
						(int)((screenSize.height / 2) - (ed.size().height / 2)));
				ed.show();
				return; /* return */
			}
			catch (Exception e)
			{
				ErrorDlg ed = new ErrorDlg((Frame)this.getParent(),
				                       "Could not load: Incorrect file format!");
				ed.initialise();
				/* position dialog box in the middle of the screen */
				ed.move((int)((screenSize.width / 2) - (ed.size().width / 2)), 
						(int)((screenSize.height / 2) - (ed.size().height / 2)));
				ed.show();
				return; /* return */
			}
		}		
	}

	public void justLoaded(String msg, String fileName, 
						   String currDir)
	/* called when this application object has just been read from a
	   file - updates the user-interface and some member variables */
	{
		appMsg.setText(msg);
		proofStatus.setText(fileName);
		currentFile = fileName;
		currentDir = currDir;
		saveStatus.setText("Saved");
		isSaved = true;
		inProgress = true;
		if (undoStack.empty())
		{
			Vector disable = new Vector();
			disable.addElement("Undo");
			menuItems(disable, (Frame)getParent(), false);
		}
		if (!(main.isProved()))
		{
			Vector disable = new Vector();
			disable.addElement("Save As Theorem");
			menuItems(disable, (Frame)getParent(), false);
		}
	}
		
	public boolean saveProof()
	/* called when user wants to save a proof onto disk. Saves
	   the proof (structure, global tables, state, etc.) to a file
	   chosen by the user.
	   Returns true iff save successful, otherwise return false */
	{
		if (currentFile == null)
		/* if user still hasn't saved this proof */
		{
			/* show platform-dependent file dialog */
			FileDialog fileDlg = new FileDialog((Frame)this.getParent(), 
			                                    "Save proof", FileDialog.SAVE);
			if (currentDir != null)
			{
				fileDlg.setDirectory(currentDir);
			}
			fileDlg.show();

			/* get file name + directory name that user has chosen */
			String fileName = fileDlg.getFile();
			String dirName = fileDlg.getDirectory();
					
			if (fileName == null)
			/* user clicked on "Cancel" */
			{
				return false; /* exit immediately with failure */
			}
			
			File theFile = new File(dirName + fileName);
			boolean success = saveToDisk(theFile);
			if (success)
			{
				isSaved = true; /* indicate proof has now been saved */
				saveStatus.setText("Saved");
				appMsg.setText("Proof saved OK.");
				currentFile = dirName + fileName;
				currentDir = dirName;
				proofStatus.setText(currentFile);
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			File theFile = new File(currentFile);
			boolean success = saveToDisk(theFile);
			if (success)
			{
				isSaved = true; /* indicate proof has now been saved */
				saveStatus.setText("Saved");
				appMsg.setText("Proof saved OK.");
				return true;
			}
			else
			{
				return false;
			}
		}
	}

	public boolean saveProofAs()
	/* saves the proof under a new name */
	{
		/* show platform-dependent file dialog */
		FileDialog fileDlg = new FileDialog((Frame)this.getParent(), 
		                                    "Save proof", FileDialog.SAVE);
		if (currentDir != null)
		{
			fileDlg.setDirectory(currentDir);
		}
		fileDlg.show();

		/* get file name + directory name that user has chosen */
		String fileName = fileDlg.getFile();
		String dirName = fileDlg.getDirectory();
					
		if (fileName == null)
		/* user clicked on "Cancel" */
		{
			return false; /* exit immediately */
		}
			
		File theFile = new File(dirName + fileName);
		boolean success = saveToDisk(theFile);
		if (success)
		/* if saved ok */
		{
			isSaved = true; /* indicate proof has now been saved */
			saveStatus.setText("Saved");
			appMsg.setText("Proof saved OK.");
			currentFile = dirName + fileName;
			currentDir = dirName;
			proofStatus.setText(currentFile);
			return true;
		}
		else
		{
			return false;
		}
	}

	private boolean saveToDisk(File theFile)
	/* saves the current proof to disk under the file given by the
	   parameter. Returns true if no problem encountered, false
	   otherwise */
	{
		try
		{
			FileOutputStream fout = new FileOutputStream(theFile);
			ObjectOutputStream oout = new ObjectOutputStream(fout);
			/* write the application object, storing all the state of
			   the proof, including the user-interface! */
			oout.writeObject(this);
			/* must also store the global tables as they are separate
			   from the application itself */
			oout.writeObject(GlobalTables.constTable());
			oout.writeObject(GlobalTables.predTable());
			oout.writeObject(GlobalTables.varTable());
			oout.writeObject(GlobalTables.functTable());
			/* flush output stream */
			oout.flush();
			oout.close();
			return true; /* success */
		}
		catch (FileNotFoundException e)
		/* a problem with the file name */
		{
			ErrorDlg ed = new ErrorDlg((Frame)this.getParent(),
				                       "Could not save: Invalid file/path name!");
			ed.initialise();
			/* position dialog box in the middle of the screen */
			ed.move((int)((screenSize.width / 2) - (ed.size().width / 2)), 
					(int)((screenSize.height / 2) - (ed.size().height / 2)));
			ed.show();
			return false; /* failure */
		}
		catch (IOException e)
		/* any other exception */
		{
			ErrorDlg ed = new ErrorDlg((Frame)this.getParent(),
										"Could not save: "+ e.getMessage());
			ed.initialise();
			/* position dialog box in the middle of the screen */
			ed.move((int)((screenSize.width / 2) - (ed.size().width / 2)), 
					(int)((screenSize.height / 2) - (ed.size().height / 2)));
			ed.show();
			return false; /* failure */
		}
	}

	public void saveAsTheorem()
	/* called when the user wants to save the current completed proof
	   as a theorem */
	{
		/* need to AND all the assumptions and make that imply the
		   goal */
		Vector mainLines = main.getProofLines();
		ExprTree combinedAssump = null;
		int mainSize = mainLines.size();
		ExprTree conclusion = ((ProofLine)mainLines.elementAt(mainSize - 1)).getExpr();
		ExprTree newTheorem = null;
		int numAssump = currAssump - 1;
		if (numAssump == 0)
		/* if no assumptions at all or one assumptions */
		{
			newTheorem = conclusion;
		}
		else if (numAssump == 1)
		/* if one assumption only */
		{
			ExprTreeValue mainVal = new ExprTreeValue("Op1", ">");
			newTheorem = new ExprTree(mainVal);
			combinedAssump = ((ProofLine)mainLines.elementAt(0)).getExpr();
			newTheorem.setLeftChild(combinedAssump);
			newTheorem.setRightChild(conclusion);
		}
		else
		/* numAssump >= 2 */
		{
			ExprTreeValue mainVal = new ExprTreeValue("Op1", ">");
			newTheorem = new ExprTree(mainVal);
			newTheorem.setRightChild(conclusion);

			/* now need to combine the assumptions */
			ExprTreeValue combine = new ExprTreeValue("Op2", "^");
			combinedAssump = new ExprTree(combine);
			combinedAssump.setLeftChild(((ProofLine)mainLines.elementAt(0)).getExpr());
			combinedAssump.setRightChild(((ProofLine)mainLines.elementAt(1)).getExpr());
			int current = 2;
			
			while (current < numAssump)
			{
				ExprTree tempExpr = new ExprTree(combine);
				tempExpr.setLeftChild(combinedAssump);
				tempExpr.setRightChild(((ProofLine)mainLines.elementAt(current)).getExpr());
				combinedAssump = tempExpr;
				current++;
			}

			newTheorem.setLeftChild(combinedAssump);
		}
			
		/* at this point, newTheorem contains the resulting theorem */
		String theTheorem = newTheorem.strContents();

		/* create the character-streams for writing the text file */
		String currDir = System.getProperty("user.dir");
		String fileSep = System.getProperty("file.separator");

		/* prepare vector to temporarily store all saved theorems */
		Vector theorems = new Vector();

		/* now read all the theorems from the theorems file */
		try
		{
			BufferedReader br = new BufferedReader(new FileReader(currDir + fileSep + "Theorems.txt"));

			String theorem = br.readLine();
			while (theorem != null)
			{
				theorems.addElement(theorem);
				theorem = br.readLine();
			}

			br.close();
		}
		catch (FileNotFoundException e)
		{
			ErrorDlg ed = new ErrorDlg((Frame)this.getParent(),
				                       "Theorem file not found!");
			ed.initialise();
			/* position dialog box in the middle of the screen */
			ed.move((int)((screenSize.width / 2) - (ed.size().width / 2)), 
					(int)((screenSize.height / 2) - (ed.size().height / 2)));
			ed.show();
			return;
		}
		catch (IOException e)
		{
			ErrorDlg ed = new ErrorDlg((Frame)this.getParent(),
				                       "Error: could not save theorem to disk!");
			ed.initialise();
			/* position dialog box in the middle of the screen */
			ed.move((int)((screenSize.width / 2) - (ed.size().width / 2)), 
					(int)((screenSize.height / 2) - (ed.size().height / 2)));
			ed.show();
			return;
		}

		/* append new theorem to theorems vector */
		theorems.addElement(theTheorem);

		try
		{
			PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(currDir + fileSep + "Theorems.txt")));
			/* now write all the theorems again, plus the new one */
			for (int i = 0; i < theorems.size(); i++)
			{
				String s = (String)theorems.elementAt(i);
				out.println(s); /* write theorems to file */
			}
			out.close(); /* close output stream */
		}
		catch (IOException e)
		{
			ErrorDlg ed = new ErrorDlg((Frame)this.getParent(),
				                       "Error: could not save theorem to disk!");
			ed.initialise();
			/* position dialog box in the middle of the screen */
			ed.move((int)((screenSize.width / 2) - (ed.size().width / 2)), 
					(int)((screenSize.height / 2) - (ed.size().height / 2)));
			ed.show();
			return;
		}

		appMsg.setText("A new theorem based on this proof has been added to the theorem database.\n");
		appMsg.appendText("You may now apply the theorem in other proofs by using 'Apply Theorem'");
		appMsg.appendText(" from the 'Action' menu");

		Vector disable = new Vector();
		disable.addElement("Save As Theorem");
		menuItems(disable, (Frame)getParent(), false);
	}

	public void quit()
	/* called when the user wants to quit the application - need to
	   confirm this with the user */
	{
		if (inProgress == true)
		/* if actually working on a proof */
		{
			ConfirmDlg cd = new ConfirmDlg((Frame)this.getParent(), this);
			if ((dataEntryState == 0) || (dataEntryState == 1))
			/* if in data entry phase - can't save */
			{
				cd.initialiseWithoutSave();
			}
			else
			{
				cd.initialiseWithSave();
			}
			/* position dialog box in the middle of the screen */
			cd.move((int)((screenSize.width / 2) - (cd.size().width / 2)), 
					(int)((screenSize.height / 2) - (cd.size().height / 2)));
			cd.show();
		}
		else
		/* can quit straight away */
		{
			((Frame)getParent()).dispose();
			System.exit(0);
		}

	}

	public void printProof()
	/* called when the user wants to output the current proof to a
	   printer */
	{
		/* get a PrintJob object in order to show a platform-dependent
		   Print dialog */
		PrintJob job = t.getPrintJob((Frame)this.getParent(), "Printing a proof",
									 printPrefs);
		if (job != null)
		/* do nothing if user clicked "Cancel" */
		{
			/* get a graphics object */
			Graphics page = job.getGraphics();
			
			/* want to center the output on the page */
			int proofWidth = main.getBox().width;
			int proofHeight = main.getBox().height;
			Dimension pageSize = job.getPageDimension();
			page.translate((pageSize.width - proofWidth) / 2,
						   (pageSize.height - proofHeight) / 2);

			/* must specify a font for the Graphics object */
			page.setFont(new Font("Helvetica", Font.BOLD, 12));
			/* call the actual printing method */
			pArea.print(page);
			/* send the job to the printer */
			page.dispose();
			/* signal end of job */
			job.end();
		}
	}

	public void startProof()
	/* called when user wants to start a new proof. Creates a 
	   confirmation / Option to save proof dialog box */
	{ 
		if (inProgress == true)
		/* if proof is in progress - warn the user */
		{
			ConfirmDlg cd = new ConfirmDlg((Frame)this.getParent(), this);
			if ((dataEntryState == 0) || (dataEntryState == 1) || (!isStandAlone))
			/* if in data entry phase - can't save */
			{
				cd.initialiseWithoutSave();
			}
			else
			{
				cd.initialiseWithSave();
			}
			/* position dialog box in the middle of the screen */
			cd.move((int)((screenSize.width / 2) - (cd.size().width / 2)), 
					(int)((screenSize.height / 2) - (cd.size().height / 2)));
			cd.show();
		}
		else
		{
			newProof();
		}
	}

	public void newProof()
	/* called when a new proof is to start */
	{
		/* initialise some variables */
		currentY = 5;
		currentX = 5;
		horiz.setValue(0);
		vert.setValue(0);
		horizOffset = 0;
		vertOffset = 0;
		appMsg.setText("");
		clickStatus = 0; /* user can't click a line yet */
		currRule = new String(); /* no current rule */
		currLine = null; /* no line currently selected */
		currSkolem = 1; /* next skolem constant will be 'sk1' */
		
		/* now disable some menu items */
		Vector disable = new Vector();
		disable.addElement("Save Proof");
		disable.addElement("Save Proof As...");
		disable.addElement("Print Proof");
		disable.addElement("Save As Theorem");
		disable.addElement("Kill Box");
		disable.addElement("Undo");
		disable.addElement("Clear Box");
		disable.addElement("Add Given");
		disable.addElement("Apply Theorem");
		disable.addElement("What Now?");
		menuItems(disable, (Frame)getParent(), false);

		/* enable some menu items */
		Vector enable = new Vector();
		enable.addElement("Global Tables...");
		menuItems(enable, (Frame)getParent(), true);

		/* create the main new context */
		main = new ContextTree();
		main.setApp(this);
		/* create the parser object */
		datain = new DataInput();
		/* initialise the undo stack */
		undoStack = new Stack();
		/* initialise global tables */
		GlobalTables.initTables();
		GlobalTables.initTempLists();
		/* add built-in predicates */
		GlobalTables.appendToPredTable("eq", new Integer(2));
		GlobalTables.appendToPredTable("false", new Integer(0));
		GlobalTables.appendToPredTable("true", new Integer(0));
		
		inProgress = true; /* indicate proof is in progress */
		isSaved = false; /* indicate proof is not saved yet */
		dataEntryState = 0; /* indicate reading assumptions */
		currAssump = 1;

		horiz.enable();
		vert.enable();

		status.setText("Reading Initial Data");
		proofStatus.setText("<no file>");
		saveStatus.setText("Changes Not Saved");
		currentFile = null;

		topSub.removeAll();
		input.removeAll();
		functs.removeAll();
		
		assump = new Label("Assumption "+currAssump+": ");
		dataEntry = new TextField("<Enter Assumption Here>", 50);
		
		btnAddAssump = new Button("Add");
		btnFinishGiven = new Button("No More Given");
		btnAcceptData = new Button("Accept");
		btnCancelData = new Button("Cancel");
		
		input.add(assump);
		input.add(dataEntry);
		topSub.add("South", input);
		
		functs.add(btnAddAssump);
		functs.add(btnFinishGiven);
		topSub.add("Center", functs);

		validate();

		dataEntry.requestFocus();
		dataEntry.selectAll();
		
		pArea.paintMe(horizOffset, vertOffset);
		
	}

	private void showNewConsts()
	/* informs the user which new constants will be introduced */
	{
		if (!(GlobalTables.tempConstList().isEmpty()))
		{
			appMsg.appendText("\nNew constants : ");
			for (Enumeration e = GlobalTables.tempConstList().keys(); e.hasMoreElements();)
			{
				appMsg.appendText((String)e.nextElement());
				if (e.hasMoreElements())
				{
					appMsg.appendText(", ");
				}
			}
		}
	}

	private void showNewVars()
	/* informs the user which new variables will be introduced */
	{
		if (!(GlobalTables.tempVarList().isEmpty()))
		{
			appMsg.appendText("\nNew variables : ");
			for (Enumeration e = GlobalTables.tempVarList().keys(); e.hasMoreElements();)
			{
				appMsg.appendText((String)e.nextElement());
				if (e.hasMoreElements())
				{
					appMsg.appendText(", ");
				}
			}
		}
	}

	private void showNewFuncts()
	/* informs the user which new functions will be introduced */	
	{
		if (!(GlobalTables.tempFunctList().isEmpty()))
		{
			appMsg.appendText("\nNew function symbols : ");
			for (Enumeration e = GlobalTables.tempFunctList().keys(); e.hasMoreElements();)
			{
				String funct = (String)e.nextElement();
				appMsg.appendText(funct+"\\");
				appMsg.appendText(GlobalTables.tempFunctList().get(funct).toString());
				if (e.hasMoreElements())
				{
					appMsg.appendText(", ");
				}
			}
		}
	}

	private void showNewPreds()
	/* informs the user which new predicates will be introduced */
	{
		if (!(GlobalTables.tempPredList().isEmpty()))
		{
			appMsg.appendText("\nNew predicates : ");
			for (Enumeration e = GlobalTables.tempPredList().keys(); e.hasMoreElements();)
			{
				String funct = (String)e.nextElement();
				appMsg.appendText(funct+"\\");
				appMsg.appendText(GlobalTables.tempPredList().get(funct).toString());
				if (e.hasMoreElements())
				{
					appMsg.appendText(", ");
				}
			}
		}
	}

	private void checkAssumption(String assumption)
	/* called when system needs to check an assumption (data)
	   entered by the user */
	{
		currExp = null;
		try
		{
			currExp = datain.syntaxAnalyse(assumption);
			/* check for any constants beginning with "sk" */
			for (Enumeration e = GlobalTables.tempConstList().keys(); e.hasMoreElements(); )
			{
				String currConst = (String)e.nextElement();
				if (currConst.startsWith("sk"))
				{
					appMsg.setText("Parsing of assumption failed!\n");
					appMsg.setText("Cannot introduce constants starting with 'sk'!\n");
					/* re-initialise temporary global tables */
					GlobalTables.initTempLists();
					dataEntry.requestFocus();
					return;
				}
			}
			appMsg.setText("Assumption "+currAssump+" OK.");
			/* tell user which terms/predicates have been introduced */
			showNewConsts();
			showNewVars();
			showNewFuncts();
			showNewPreds();
			appMsg.appendText("\nClick on the 'Accept' button or Press 'Return' to accept this assumption...");
			functs.remove(btnAddAssump);
			functs.remove(btnFinishGiven);
			functs.add(btnAcceptData);
			functs.add(btnCancelData);
			validate();
			dataEntry.disable();
			this.requestFocus();
		}
		catch (Exception e)
		/* if an error was encountered in input - re-read assumption */
		{
			appMsg.setText("Parsing of assumption failed!\n");
			appMsg.appendText(e.getMessage());
			/* re-initialise temporary global tables */
			GlobalTables.initTempLists();
			dataEntry.requestFocus();
		}
	}

	private void addAssumption()
	/* adds the current assumption to the initial data */
	{
		/* update the global tables */
		GlobalTables.updateTables();
					
		/* now create a proofLine object for the new assumption */
		ProofLine pl = new ProofLine((new Integer(currAssump)).toString(), main, false, currExp);
			
		/* mark line as "Given" */
		pl.assignRef("Given");
		/* create position for line */
		pl.setLinePos(new Point(currentX + 2, currentY + fm.getHeight() + 2));
		
		/* make sure that the Ref field appears right */
		int thisRefPos = pl.getLinePos().x + pl.getNumSpace() + pl.getRefSpace() + 
			             fm.stringWidth(pl.getNum() + ExprTree.formattedContents(currExp.strContents())) +
						 pl.getRefSpace();
		if (thisRefPos > main.getRefPos())
		{
			main.setRefPos(thisRefPos);
			main.updateLineRecs(pArea);
		}

		/* create the bounding box of the line */
		pl.setRectPos(new Point(currentX, currentY));
		pl.setRectWidth(main.getRefPos() - pl.getLinePos().x + fm.stringWidth(pl.getRef()) + 4);
		pl.setRectHeight(fm.getHeight() + 4);
			
		/* update current position for drawing */
		currentY = pl.getRectArea().y + pl.getRectArea().height + 2;
			
		/* add proof line to main context */
		main.addProofLine(pl);

		/* draw new proof line in main proof area */
		pArea.paintMe(horizOffset, vertOffset);

		appMsg.setText("Assumption "+currAssump+" added.");

		/* now prepare for next assumption */
		GlobalTables.initTempLists();
		currAssump++;
		assump.setText("Assumption "+currAssump+":     ");
		dataEntry.setText("");

		functs.remove(btnAcceptData);
		functs.remove(btnCancelData);
		functs.add(btnAddAssump);
		functs.add(btnFinishGiven);
		validate();

		dataEntry.enable();
		dataEntry.requestFocus();
	}

	private void prepareConclusion()
	/* prepares the user-interface for entering the goal */
	{
		functs.remove(btnFinishGiven);
		validate();
		assump.setText("Conclusion:     ");
		appMsg.setText("Please enter the conclusion ...");
		dataEntry.setText("");
		dataEntry.requestFocus();
		dataEntryState = 1; /* indicate reading conclusion */
	}

	private void checkConclusion(String conclusion)
	/* called when system needs to check the conclusion
	   entered by the user */
	{
		try
		{
			currExp = datain.syntaxAnalyse(conclusion);
			/* check for any constants beginning with "sk" */
			for (Enumeration e = GlobalTables.tempConstList().keys(); e.hasMoreElements(); )
			{
				String currConst = (String)e.nextElement();
				if (currConst.startsWith("sk"))
				{
					appMsg.setText("Parsing of conclusion failed!\n");
					appMsg.setText("Cannot introduce constants starting with 'sk'!\n");
					/* re-initialise temporary global tables */
					GlobalTables.initTempLists();
					dataEntry.requestFocus();
					return;
				}
			}
			appMsg.setText("Conclusion OK.");
			/* tell user which terms/predicates have been introduced */
			showNewConsts();
			showNewVars();
			showNewFuncts();
			showNewPreds();
			appMsg.appendText("\nClick on the 'Accept' button to accept the conclusion...");
			functs.remove(btnAddAssump);
			functs.add(btnAcceptData);
			functs.add(btnCancelData);
			validate();
			dataEntry.disable();
			this.requestFocus();
		}	
		catch (Exception e)
		/* if an error was encountered in input - re-read conclusion */
		{
			appMsg.setText("Parsing of conclusion failed!\n");
			appMsg.appendText(e.getMessage());
			/* re-initialise temporary global tables */
			GlobalTables.initTempLists();
			dataEntry.requestFocus();
		} 
	}

	private void addConclusion()
	/* adds the conclusion to the initial data */
	{
		GlobalTables.updateTables();
	
		/* add one empty line below the given data */
		ProofLine emptyLine = createEmptyLine(main, (new Integer(currAssump)).toString());
		emptyLine.setLinePos(new Point(currentX + 2, currentY + fm.getHeight() + 2));
		emptyLine.setRectPos(new Point(currentX, currentY));
		emptyLine.setRectHeight(fm.getHeight() + 4);
		main.addProofLine(emptyLine);
		main.setBottomDerived(emptyLine);
		
		/* now add the conclusion */

		currentY += 200; /* create some space between conclusion and data */

		/* now create a proofLine object for the conclusion */
		ProofLine pl = new ProofLine((new Integer(currAssump + 1)).toString(), main, false, currExp);
		pl.goalStatus(true); /* it is currently the goal */
		pl.currentStatus(true); /* set it to current line */
		currLine = pl;
			
		pl.assignRef("Conclusion");
		/* create position for line */
		pl.setLinePos(new Point(currentX + 2, currentY + fm.getHeight() + 2));
			
		/* make sure that the Ref field appears right */
		int thisRefPos = pl.getLinePos().x + pl.getNumSpace() + pl.getRefSpace() + 
						 fm.stringWidth(pl.getNum() + ExprTree.formattedContents(currExp.strContents())) +
						 pl.getRefSpace();
		if (thisRefPos > main.getRefPos())
		{
			main.setRefPos(thisRefPos);
			main.updateLineRecs(pArea);
		}
		
		emptyLine.setRectWidth(emptyLine.minimumWidth(fm));

		/* create the bounding box of the line */
		pl.setRectPos(new Point(currentX, currentY));
		pl.setRectWidth(main.getRefPos() - pl.getLinePos().x + fm.stringWidth(pl.getRef()) + 4);
		pl.setRectHeight(fm.getHeight() + 4);
		
		/* record the line height for future lines */
		lineBoxHeight = pl.getRectArea().height;
		lineHeight = fm.getHeight();

		/* add proof line to main context */
		main.addProofLine(pl);
		main.setGoal(pl);

		/* create the (invisible) box for the main context */
		int minWidth = main.minWidth(pArea);
		main.setBoxPos(new Point(0,0));
		main.setBoxWidth(minWidth + 200);
		main.setBoxHeight(pl.getRectArea().y + pl.getRectArea().height + 10);

		/* draw new proof line in main proof area */
		pArea.paintMe(horizOffset, vertOffset);

		dataEntryState = 9;
		clickStatus = 2; /* user can now make a line current by 
							clicking on it */

		/* do some updating on the interface */
		updateInterface();

	}

	public void viewConst()
	/* to show the global constants to the user */
	{
		ViewDlg vd = new ViewDlg((Frame)this.getParent(), this,
								 "constants", GlobalTables.constTable());
		showViewDlg(vd);
	}

	public void viewPred()
	/* to show the global predicates to the user */
	{
		ViewDlg vd = new ViewDlg((Frame)this.getParent(), this,
								 "predicates", GlobalTables.predTable());
		showViewDlg(vd);
	}

	public void viewFunct()
	/* to show the global function symbols to the user */
	{
		ViewDlg vd = new ViewDlg((Frame)this.getParent(), this,
								 "function symbols", GlobalTables.functTable());
		showViewDlg(vd);
	}

	public void viewVar()
	/* to show the global variables to the user */
	{
		ViewDlg vd = new ViewDlg((Frame)this.getParent(), this,
								 "variables", GlobalTables.varTable());
		showViewDlg(vd);
	}

	private void showViewDlg(ViewDlg vd)
	/* displays incoming dialog in the middle of the screen */
	{
		vd.initialise();
		vd.printContents();

		/* position dialog box in the middle of the screen */
		vd.move((int)((screenSize.width / 2) - (vd.size().width / 2)), 
				(int)((screenSize.height / 2) - (vd.size().height / 2)));
		vd.show();
	}

	public ProofLine createEmptyLine(ContextTree c, String lineNum)
	/* creates an empty line in context c with line number lineNum */
	{
		ExprTreeValue exprValue = new ExprTreeValue("Empty", "<empty>");
		ExprTree expr = new ExprTree(exprValue);
		ProofLine emptyLine = new ProofLine(lineNum, c, false, expr);
		return emptyLine;
	}
	
	private void updateInterface()
	/* called when all initial data has been read and the user is
	   ready to start the actual proof construction */
	{
		functs.removeAll();
		topSub.remove(input);

		btnApplyRule = new Button("Apply Rule : ");
		btnUndo = new Button("Undo");
		btnCancelRule = new Button("Cancel");

		ruleTypes = new CheckboxGroup(); /* create check-box group */
		intro = new Checkbox("Introduction rules", ruleTypes, true);
		elim = new Checkbox("Elimination rules", ruleTypes, false);
		others = new Checkbox("Others", ruleTypes, false);

		applyRule = new Choice();
		applyRule.addItem("And Introduction");
		applyRule.addItem("Or Introduction");
		applyRule.addItem("Arrow Introduction");
		applyRule.addItem("Not Introduction");
		applyRule.addItem("For-All Introduction");
		applyRule.addItem("There-Exists Introduction");
		applyRule.addItem("If-And-Only-If Introduction");
		applyRule.addItem("For-All Arrow Introduction");
		applyRule.select(0);

		functs.add(btnApplyRule);
		functs.add(applyRule);
		functs.add(intro);
		functs.add(elim);
		functs.add(others);
		functs.add(btnUndo);
		btnUndo.disable();
		
		/* enable some menu items */
		Vector enable = new Vector();
		if (isStandAlone)
		/* only disable file options if running stand-alone */
		{
			enable.addElement("Save Proof");
			enable.addElement("Save Proof As...");
			enable.addElement("Print Proof");
			enable.addElement("Apply Theorem");
		}

		enable.addElement("Clear Box");
		enable.addElement("Kill Box");
		enable.addElement("Add Given");
		enable.addElement("What Now?");
		menuItems(enable, (Frame)getParent(), true);

		validate();
		
		status.setText("Constructing proof");
		appMsg.setText("You can now start to construct the proof.\n");
		appMsg.appendText("Clicking the 'Help Me' button will tell you which");
		appMsg.appendText(" rule can be applied to the currently selected line.");
		appMsg.appendText("\n\nLine "+currLine.getNum()+" (the goal) is");
		appMsg.appendText(" currently selected.");
	}

	public ProofLine getCurrentLine()
	/* returns the currently selected line */
	{
		return currLine;
	}

	public void setCurrentLine(ProofLine pl)
	/* sets the currLine memebr variable line to pl */
	{
		currLine = pl;
	}

	public boolean couldApplyRuleToLine()
	/* returns true if the application is waiting for the user to
	   select a line to apply a rule to; false otherwise */
	{
		return (clickStatus == 1);
	}

	public boolean couldMakeLineCurrent()
	/* returns true if user can make a line current by clicking on
	   it; false otherwise */
	{
		return (clickStatus == 2);
	}

	public void clickedProofArea(int actualX, int actualY)
	/* called by ProofArea object when user has clicked on the proof
	   area; actualX and actualY are actual co-ordinates that have been
	   clicked */
	{
		if (couldMakeLineCurrent())
		/* if user has simply selected this line to be current */
		{
			/* record line number of current line */
			ProofLine pl = currLine;
			
			/* make selected line current */
			boolean success = main.makeLineCurrent(actualX, actualY);
			/* at this point, the currLine must have been updated */
			
			/* repaint the proof area if necessary */
			if (success == true)
			{
				if ((pl != null) 
				   && ((!(currLine.getNum().equals(pl.getNum())))))
				{
					main.cancelCurrentLine(pl);
				}
				pArea.paintMe(horizOffset, vertOffset);
				appMsg.setText("Line "+currLine.getNum()+" selected.");
			}
		}
		else if (couldApplyRuleToLine())
		/* if waited for the user to click a line for a specific rule */
		{
			currClick++;
			if (currClick == 1)
			/* if first one clicked */
			{
				clicked1 = main.returnLine(actualX, actualY);
				if (clicked1 == null)
				/* no line actually selected */
				{
					/* wait for another click */
					currClick--;
				}
				else 
				{
					if (!(currRule.equals("AndI")))
					{
						if (currRule.equals("AndE"))
						/* if and elimination - call appropriate method */
						{
							andElimChosenLine();
						}
						else if (currRule.equals("OrE"))
						/* if or elimination */
						{
							orElimChosenLine(clicked1, currLine);
						}
						else if (currRule.equals("ThereExistsE"))
						/* if there-exists elimination */
						{
							thereExistsElimChosenLine(clicked1, currLine);
						}
						else if (currRule.equals("OrI"))
						/* if or introduction */
						{
							orIntroForChosenLine();
						}
						else if (currRule.equals("BottomE"))
						/* if bottom elimination */
						{
							bottomElimForChosenLine();
						}
						else if (currRule.equals("NotNot"))
						/* if not-not */
						{
							notNotChosenLine(clicked1, currLine);
						}
						else if (currRule.equals("IfAndOnlyIfE"))
						/* if iff elimination */
						{
							iffElimChosenLine();
						}
						else if ((currRule.equals("IfAndOnlyIfEquiv"))
							    && (!(currLine.isEmpty())))
						/* if iff-equiv backwards */
						{
							iffEquivBackChosenLine();
						}
						else if ((currRule.equals("IfAndOnlyIfEquiv"))
							    && (currLine.isEmpty()))
						/* if iff-equiv forwards */
						{
							appMsg.setText("Now click the second line (which must be an equivalence)...");
						}
						else if (currRule.equals("Tick"))
						/* if 'Tick' */
						{
							tickChosenLine(clicked1, currLine);
						}
						else if (currRule.equals("ForAllE"))
						/* if for-all elimination */
						{
							forAllElimChosenLine();
						}
						else if ((currRule.equals("ArrowE")) 
							    && (!(currLine.isEmpty())))
						/* if arrow elimination backwards */
						{
							arrowElimBackChosenLine(clicked1, currLine);
						}
						else if ((currRule.equals("ArrowE"))
							    && (currLine.isEmpty()))
						/* if arrow elimination forwards */
						{
							appMsg.setText("Now click the second line...");						
						}
						else if ((currRule.equals("Eqsub"))
							    && (!(currLine.isEmpty())))
						/* if eqsub backwards */
						{
							eqsubBackChosenLine();
						}
						else if ((currRule.equals("Eqsub"))
							    && (currLine.isEmpty()))
						/* if eqsub forwards */
						{
							appMsg.setText("Now click the second line (which must be an equality)...");
						}
						else if ((currRule.equals("NotE"))
							    && (!(currLine.isEmpty())))
						/* if not elimination backwards */
						{
							notElimBackChosenLine(clicked1, currLine);
						}
						else if ((currRule.equals("NotE"))
							    && (currLine.isEmpty()))
						/* if not elimination forwards */
						{
							appMsg.setText("Now click the second line...");
						}
					}
					else
					{
						appMsg.setText("Now click the second line...");
					}
				}
			}
			else if (currClick == 2)
			/* if second line clicked */
			{
				clicked2 = main.returnLine(actualX, actualY);
				if (clicked2 == null)
				{
					currClick--;
				}
				else if (currRule.equals("AndI"))
				/* if and introduction forwards */
				{
					andIntroForDone(clicked1, clicked2, currLine);
				}
				else if (currRule.equals("ArrowE"))
				/* if arrow elimination forwards */
				{
					arrowElimForChosenLine(clicked1, clicked2, currLine);
				}
				else if (currRule.equals("Eqsub"))
				/* if eqsub forwards */
				{
					eqsubForChosenLine(clicked1, clicked2, currLine);
				}
				else if (currRule.equals("NotE"))
				/* if not elimination forwards */
				{
					notElimForChosenLine(clicked1, clicked2, currLine);
				}
				else if (currRule.equals("IfAndOnlyIfEquiv"))
				/* if iff equiv */
				{
					iffEquivForChosenLine();
				}
			}
		}
	}

	public void undo()
	/* this method is called whenever the user wishes to undo the
	   lastest rule application */
	{
		if (!(undoStack.empty()))
		/* if undo stack not empty */
		{
			currRule = "Undo";
			/* take the first UndoObject from the stack */
			UndoObject undo = (UndoObject)undoStack.pop();
			/* disable undo button if stack is now empty */
			if (undoStack.empty())
			{
				btnUndo.disable();
				Vector disable = new Vector();
				disable.addElement("Undo");
				menuItems(disable, (Frame)getParent(), false);
			}
			/* process according to the rule applied */
			String ruleName = undo.getRuleName();
			if (((ruleName.equals("AndI")) && (undo.isBackwards()))
			   || (ruleName.equals("OrE")) 
			   || (ruleName.equals("ForAllI"))
			   || (ruleName.equals("ArrowI")) 
			   || (ruleName.equals("IfAndOnlyIfI"))
			   || (ruleName.equals("ThereExistsE"))
			   || (ruleName.equals("Lemma"))
			   || (ruleName.equals("NotI"))
			   || (ruleName.equals("PC"))
			   || (ruleName.equals("ForAllArrowI")))
			/* if rule involved creating a new box - use killBox */
			{
				Vector subs = undo.getBoxes();
				ContextTree c = (ContextTree)subs.elementAt(0);
				ProofLine pl = null;
				if ((ruleName.equals("ForAllI")) ||
					(ruleName.equals("ThereExistsE")) ||
					(ruleName.equals("ForAllArrowI")))
				{	
					pl = (ProofLine)c.getProofLines().elementAt(1);
				}
				else
				{
					pl = (ProofLine)c.getProofLines().elementAt(0);
				}
				clickedProofArea(pl.getRectArea().x + 1,
								 pl.getRectArea().y + 1);
				killBoxDone(); /* will delete both boxes plus
							      make proof goal the current
								  goal */
				/* inform the user action has been undone */
				appMsg.setText("Rule application undone.");
				return; /* skip processing at end of method (done it
						   already in killBoxDone() */
			}
			else if (((ruleName.equals("AndI")) && (!(undo.isBackwards())))
				    || (ruleName.equals("IfAndOnlyIfE"))
					|| ((ruleName.equals("OrI")) && (!(undo.isBackwards())))
					|| ((ruleName.equals("AndE")) && (!(undo.getOtherParam().equals("B"))))
					|| ((ruleName.equals("ArrowE")) && (!(undo.isBackwards())))
					|| ((ruleName.equals("NotE")) && (!(undo.isBackwards())))
					|| ((ruleName.equals("BottomE")) && (!(undo.isBackwards())))
					|| (ruleName.equals("ForAllE"))
					|| (ruleName.equals("NotNot"))
					|| (ruleName.equals("Reflex"))
					|| ((ruleName.equals("Eqsub")) && (!(undo.isBackwards())))
					|| ((ruleName.equals("IfAndOnlyIfEquiv")) && (!(undo.isBackwards()))))
			/* if action simply involved creating a new line forwards
			   from the previously current line */
			{
				/* get the associated line - need to delete this
				   and move the empty line up to fill its gap */
				ProofLine line = undo.getLine();
				ContextTree c = line.getContext();
				int index = c.getProofLines().indexOf(line);
				ProofLine empty = (ProofLine)c.getProofLines().elementAt(index + 1);
				clickedProofArea(empty.getRectArea().x + 1,
								 empty.getRectArea().y + 1);
				/* delete the line */
				c.removeProofLine(line);
				/* translate empty line */
				empty.setRectPos(new Point(line.getRectArea().x,
										   line.getRectArea().y));
				empty.setLinePos(new Point(line.getLinePos().x,
										   line.getLinePos().y));
			}
			else if (((ruleName.equals("AndE")) && (undo.getOtherParam().equals("B"))) 
				    || (ruleName.equals("Theorem")))
			/* if "AndE" and user has generated both conjuncts */
			{
				ProofLine line = undo.getLine();
				ProofLine otherLine = undo.getOtherLine();
				ContextTree c = line.getContext();
				int index = c.getProofLines().indexOf(line);
				ProofLine empty = (ProofLine)c.getProofLines().elementAt(index + 2);
				clickedProofArea(empty.getRectArea().x + 1,
								 empty.getRectArea().y + 1);
				
				/* delete the lines */
				c.removeProofLine(line);
				c.removeProofLine(otherLine);
				/* translate the empty line */
				empty.setRectPos(new Point(line.getRectArea().x,
										   line.getRectArea().y));
				empty.setLinePos(new Point(line.getLinePos().x,
										   line.getLinePos().y));
			}
			else if (((ruleName.equals("OrI")) && (undo.isBackwards()))
				    || ((ruleName.equals("BottomE")) && (undo.isBackwards()))
				    || (ruleName.equals("ThereExistsI"))
					|| ((ruleName.equals("ArrowE")) && (undo.isBackwards()))
				    || ((ruleName.equals("NotE")) && (undo.isBackwards()))
					|| ((ruleName.equals("IfAndOnlyIfEquiv")) && (undo.isBackwards()))
					|| ((ruleName.equals("Eqsub")) && (undo.isBackwards())))
			/* the rules which generate one line above the previous
			   goal */
			{
				/* need to delete the line that has been generated and
				   reset the line below it to be the current goal of 
				   its context */
				ProofLine line = undo.getLine();
				ContextTree c = line.getContext();
				int index = c.getProofLines().indexOf(line);
				ProofLine previousGoal = (ProofLine)c.getProofLines().elementAt(index + 1);
				clickedProofArea(previousGoal.getRectArea().x + 1,
								 previousGoal.getRectArea().y + 1);
				/* delete line */
				c.removeProofLine(line);
				previousGoal.assignRef("");
				previousGoal.setRuleAppliedTo("");
				previousGoal.goalStatus(true);
				c.setGoal(previousGoal);
			}
			/* now renumber all the lines in the proof */
			main.reLabel();
			/* update references to reflect new line numbers */
			main.updateReferences();
			/* repaint canvas to reflect changes */
			pArea.paintMe(horizOffset, vertOffset);
			/* record proof is now not saved */
			isSaved = false; 
			saveStatus.setText("Changes Not Saved");
			/* inform the user */
			appMsg.setText("Rule/Theorem application undone.");
		}
	}

	public void clearBox()
	/* this method is called when the user has chosen the option of
	   clearing the box in which the currently selected line resides */
	{
		/* indicate clearing current box - obviously not a rule,
		   purely used for implementation purposes (need confirmation
		   from the user - see the 'keyDown' method of this class */
		currRule = "ClearBox";

		/* get context of current line */
		ContextTree currCont = currLine.getContext();

		if (currCont.isProved())
		/* cannot clear a context which is already proved */
		{
			appMsg.setText("Cannot clear a box which has been proven already!");
		}
		else
		{
			/* record number of user-defined lines in current context */
			int userDefined = currCont.countUserDefined();
			if ((currCont.numChildren() == 0) &&
				(userDefined == 0))
			{
				appMsg.setText("Box of currently selected line already clear!");
			}
			else
			{
				/* lines/boxes to clear: warn user and ask for confirmation */
				appMsg.setText("****** WARNING ****** ");
				appMsg.appendText("\nThis will delete all user-derived");
				appMsg.appendText(" lines in the box of the currently");
				appMsg.appendText(" selected line and all the sub-boxes");
				appMsg.appendText(" (if any) of this box!!!.");
				appMsg.appendText("\nPress 'Y' to proceed or 'N' to cancel.");
				waitForClick();
				clickStatus = 0; /* make sure clicking on proof area does nothing */
			}
		}
	}

	public void clearBoxDone()
	/* called if and when the user has given confirmation that the
	   box of the currently selected line should be cleared */
	{
		/* record whether the currently selected line is user-defined
		   or not (to be used below) */
		boolean userDefined = currLine.isUserDefined();

		/* get current context */
		ContextTree thisCont = currLine.getContext();

		/* delete all sub-contexts */
		thisCont.deleteAllChildren();
		
		/* delete all user-defined lines in context */
		thisCont.deleteAllUserDefined();

		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();

		Vector pls = thisCont.getProofLines();
		ProofLine boxGoal = (ProofLine)pls.elementAt(pls.size() - 1);
		/* cancel all rule applications to box goal */
		boxGoal.assignRef("");
		boxGoal.setRuleAppliedTo("");
		boxGoal.goalStatus(true);
		thisCont.setGoal(boxGoal);

		/* need to update the position of the empty line in the 
		   cleared box. This depends on the context type */
		ProofLine emptyLine = thisCont.getBottomDerived();
		/* the x-position of the line does not change */
		int xPos = emptyLine.getRectArea().x;
		int yPos = 0; /* initialise yPos */
		if (thisCont.getType().equals("Main"))
		{
			/* emptyLine must be just below the last assumption, 
			   unless there are no assumptions! */
			if (currAssump == 1)
			/* no assumptions */
			{
				yPos = 5;
			}
			else
			{
				ProofLine lastGiven = (ProofLine)main.getProofLines().elementAt(currAssump - 2);
				yPos = lastGiven.getRectArea().y + lineBoxHeight + 2;
			}
		}
		else if ((thisCont.getType().equals("AndI")) ||
			     (thisCont.getType().equals("IfAndOnlyIfI")))
		{
			yPos = thisCont.getBox().y + 5;
		}
		else if ((thisCont.getType().equals("ArrowI")) ||
			    (thisCont.getType().equals("PC")) ||
				(thisCont.getType().equals("NotI")) ||
				(thisCont.getType().equals("ForAllI")) ||
				(thisCont.getType().equals("OrE")))
		{
			ProofLine first = (ProofLine)thisCont.getProofLines().elementAt(0);
			yPos = first.getRectArea().y + lineBoxHeight + 2;
		}
		else if ((thisCont.getType().equals("ExistE"))
			    || (thisCont.getType().equals("ForAllArrowI")))
		{
			ProofLine second = (ProofLine)thisCont.getProofLines().elementAt(1);
			yPos = second.getRectArea().y + lineBoxHeight + 2;
		}
		else if (thisCont.getType().equals("Lemma"))
		{
			/* here it depends which box of the lemma we are in */
			Vector siblings = thisCont.getParent().getChildren();
			int index = siblings.indexOf(thisCont);
			if (index == 0)
			/* if left box of lemma */
			{
				yPos = thisCont.getBox().y + 5;
			}
			else if (index == 1)
			/* if right box of lemma */
			{
				ProofLine first = (ProofLine)thisCont.getProofLines().elementAt(0);
				yPos = first.getRectArea().y + lineBoxHeight + 2;
			}
		}
			
		/* set new position */
		emptyLine.setRectPos(new Point(xPos, yPos));
		emptyLine.setLinePos(new Point(xPos + 2, yPos + lineHeight + 2));

		if (userDefined)
		/* if current line has now disappeared */
		{
			currLine = null; 
			pls = main.getProofLines();
			ProofLine proofGoal = (ProofLine)pls.elementAt(pls.size() - 1);
			clickedProofArea(proofGoal.getRectArea().x + 1,
							 proofGoal.getRectArea().y + 1);
			appMsg.setText("Box cleared.");
			appMsg.appendText("\nCurrently selected line is the");
			appMsg.appendText(" main goal of the proof.");
		}
		else
		{
			appMsg.setText("Box cleared.");
		}

		/* repaint canvas to reflect changes */
		pArea.paintMe(horizOffset, vertOffset);

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* cannot undo clear box */
		undoStack = new Stack();
		btnUndo.disable();
		Vector disable = new Vector();
		disable.addElement("Undo");
		menuItems(disable, (Frame)getParent(), false);
	}

	public void killBox()
	/* this method is called when the user has chosen the option of
	   killing the box in which the currently selected line resides */
	{
		/* indicate clearing current box - obviously not a rule,
		   purely used for implementation purposes (need confirmation
		   from the user - see the 'keyDown' method of this class */
		currRule = "KillBox";

		ContextTree currCont = currLine.getContext();

		if (currCont == main)
		/* cannot simply kill the outermost box! */
		{
			appMsg.setText("Cannot delete the outermost context!");
		}
		else if (currCont.isProved())
		/* cannot kill a context which is already proved */
		{
			appMsg.setText("Cannot kill a box which has been proven already!");
		}
		else
		{
			/* lines/boxes to kill: warn user and ask for confirmation */
			appMsg.setText("****** WARNING ****** ");
			appMsg.appendText("\nThis will delete the box of the currently");
			appMsg.appendText(" selected line, including any sub-boxes!");
			/* also warn the user that if this box has a sibling as in
			   andI, the sibling will be deleted too in order to maintain
			   consistency */
			if ((currCont.getType().equals("AndI")) ||
				(currCont.getType().equals("OrE")) ||
				(currCont.getType().equals("IfAndOnlyIfI")) ||
				(currCont.getType().equals("Lemma")))
			{
				appMsg.appendText("\nAlso, since this box has an adjacent box, that ");
				appMsg.appendText("box will be deleted, too, in order to maintain ");
				appMsg.appendText("consistency.");
			}

			appMsg.appendText("\nPress 'Y' to proceed or 'N' to cancel.");
			waitForClick();
			clickStatus = 0; /* make sure clicking on proof area does nothing */
		}
	}

	public void killBoxDone()
	/* called if and when the user has given confirmation that the
	   box of the currently selected line should be killed */
	{
		/* get the parent context */
		ContextTree theParent = currLine.getContext().getParent();

		/* delete context simply by deleting all children of the
		   parent */
		theParent.deleteAllChildren();

		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();

		/* re-initialise the current goal of the parent context */
		ProofLine parentCurrentGoal = theParent.getGoal();
		parentCurrentGoal.assignRef("");
		parentCurrentGoal.setRuleAppliedTo("");

		currLine = null; 
		Vector pls = main.getProofLines();
		ProofLine proofGoal = (ProofLine)pls.elementAt(pls.size() - 1);
		clickedProofArea(proofGoal.getRectArea().x + 1,
						 proofGoal.getRectArea().y + 1);
		appMsg.setText("Box killed.");
		appMsg.appendText("\nCurrently selected line is the");
		appMsg.appendText(" main goal of the proof.");

		/* repaint canvas to reflect changes */
		pArea.paintMe(horizOffset, vertOffset);

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		if (currRule.equals("KillBox"))
		/* 'killBoxDone' may be called from undo() in which case the 
		   code below should not be executed! */
		{
			/* cannot undo kill box */
			undoStack = new Stack();
			btnUndo.disable();
			Vector disable = new Vector();
			disable.addElement("Undo");
			menuItems(disable, (Frame)getParent(), false);
		}
	}

	public void applyTheorem()
	/* adds a theorem from the theorem database.
	   NOTE: it is assumed that the theorem file is in the current
		     directory */
	{
		if (!(currLine.isEmpty()))
		{
			appMsg.setText("To apply a theorem, the current line must be empty!");
			return;
		}

		currRule = "ApplyTheorem";

		/* create the character-streams for reading text file */
		String currDir = System.getProperty("user.dir");
		String fileSep = System.getProperty("file.separator");

		/* prepare vector to temporarily store all saved theorems */
		Vector theorems = new Vector();

		/* now read all the theorems from the theorems file */
		try
		{
			BufferedReader br = new BufferedReader(new FileReader(currDir + fileSep + "Theorems.txt"));

			String theorem = br.readLine();
			while (theorem != null)
			{
				theorems.addElement(theorem);
				theorem = br.readLine();
			}

			br.close(); /* close stream */
		}
		catch (FileNotFoundException e)
		{
			ErrorDlg ed = new ErrorDlg((Frame)this.getParent(),
				                       "Theorem file not found!");
			ed.initialise();
			/* position dialog box in the middle of the screen */
			ed.move((int)((screenSize.width / 2) - (ed.size().width / 2)), 
					(int)((screenSize.height / 2) - (ed.size().height / 2)));
			ed.show();
			return;
		}
		catch (IOException e)
		{
			ErrorDlg ed = new ErrorDlg((Frame)this.getParent(),
				                       "Error: could not load theorems!");
			ed.initialise();
			/* position dialog box in the middle of the screen */
			ed.move((int)((screenSize.width / 2) - (ed.size().width / 2)), 
					(int)((screenSize.height / 2) - (ed.size().height / 2)));
			ed.show();
			return;
		}
		
		if (theorems.isEmpty())
		/* if no theorems stored at all */
		{
			ErrorDlg ed = new ErrorDlg((Frame)this.getParent(),
				                       "Theorem file empty!");
			ed.initialise();
			/* position dialog box in the middle of the screen */
			ed.move((int)((screenSize.width / 2) - (ed.size().width / 2)), 
					(int)((screenSize.height / 2) - (ed.size().height / 2)));
			ed.show();
			return;
		}

		/* now show the dialog box */
		TheoremDlg td = new TheoremDlg((Frame)this.getParent(), this);
		td.initialise(theorems);
		/* position dialog box in the middle of the screen */
		td.move((int)((screenSize.width / 2) - (td.size().width / 2)), 
					(int)((screenSize.height / 2) - (td.size().height / 2)));
		td.show();
	}

	public void selectedTheorem(String theorem)
	/* called when the user has selected which theorem to apply to the
	   proof */
	{
		/* NOTE: 
		   1) the stored theorems is a schema - need to obtain the
		      correct instance,
		   2) this assumes theorems will NOT cause parsing errors.
		      Any error immediately causes this method to report an
			  error and exit */

		/* store chosen theorem for later */
		currTheorem = theorem;
		/* obtain the signature of the schema by parsing the
		   theorem */
		
		Hashtable storedPredicates = GlobalTables.predTable();
		Hashtable storedFunctors = GlobalTables.functTable();
		Hashtable storedConstants = GlobalTables.constTable();
		Hashtable storedVariables = GlobalTables.varTable();
		GlobalTables.initTables(); /* initialise tables to parse
									  theorem */
		GlobalTables.appendToPredTable("eq", new Integer(2));
		GlobalTables.appendToPredTable("false", new Integer(0));
		GlobalTables.appendToPredTable("true", new Integer(0));
		GlobalTables.initTempLists();
		try
		{
			/* parse theorem */
			currTheoremTree = datain.syntaxAnalyse(currTheorem);
		}
		catch (Exception e)
		/* exit immediately if theorem does not parse correctly */
		{
			ErrorDlg ed = new ErrorDlg((Frame)this.getParent(),
				                       "Theorem cannot be parsed correctly!");
			ed.initialise();
			/* position dialog box in the middle of the screen */
			ed.move((int)((screenSize.width / 2) - (ed.size().width / 2)), 
					(int)((screenSize.height / 2) - (ed.size().height / 2)));
			ed.show();
			/* recover old global tables */
			GlobalTables.setPredTable(storedPredicates);
			GlobalTables.setConstTable(storedConstants);
			GlobalTables.setVarTable(storedVariables);
			GlobalTables.setFunctTable(storedFunctors);
			return;
		}

		/* recover old global tables */
		GlobalTables.setPredTable(storedPredicates);
		GlobalTables.setConstTable(storedConstants);
		GlobalTables.setVarTable(storedVariables);
		GlobalTables.setFunctTable(storedFunctors);
		
		/* read number of and actual free variables */
		appMsg.setText("You have chosen the theorem:  " + theorem + "\n\n");
		appMsg.appendText("New Pandora needs to know the instance of the theorem");
		appMsg.appendText(" you wish to use.\n");
		appMsg.appendText("Firstly, in the text box above enter the number of free variables you");
		appMsg.appendText(" will be using in your instance.");

		freeVars = new Vector(); /* initialise free vars vector */

		waitForClick();
		clickStatus = 0; /* make sure clicking on proof area does nothing */
		dataEntryState = 7; /* indicate reading number of free vars */
		assump.setText("No. of free vars : ");
		dataEntry.setText("");
		dataEntry.enable();
		topSub.add("South", input);
		validate();
		dataEntry.requestFocus();
	}

	public void readNextFreeVar()
	/* called to prompt the user to enter the next free variable for applying
	   a theorem */
	{
		appMsg.setText("In the text box provided, type in free variable " + currFreeVar + ".");
		assump.setText("Free var " + currFreeVar + ": ");
		dataEntry.setText("");
		dataEntry.requestFocus();
	}

	public void nextFreeVarDone(String var)
	/* called when the user has entered the next free variable */
	{
		/* record free variables */
		freeVars.addElement(var);
		currFreeVar++;
		if (currFreeVar == numFreeVars + 1)
		/* if read all free vars */
		{
			getMappings();
		}
		else
		/* more to read */
		{
			readNextFreeVar();
		}
	}

	public void getMappings()
	/* called to ask the user how he/she would map the theorem to
	   the current proof */
	{
		/* now need to ask user for mappings */
		mappings = new Hashtable();
		mapKeys = new Vector();

		Hashtable sigVar = GlobalTables.tempVarList();
		for (Enumeration e = sigVar.keys(); e.hasMoreElements(); )
		{
			String s = (String)e.nextElement();
			mapKeys.addElement(s);
		}

		/* need to extract all atoms from theorem */
		Vector atoms = currTheoremTree.getAllAtoms();
		for (int i = 0; i < atoms.size(); i++)
		{
			String s = (String)atoms.elementAt(i);
			mapKeys.addElement(s);
		}

		topSub.remove(input);
		validate();

		/* at this point, mappings contain all the necessary keys, now
		   we need the values */
		appMsg.setText("Theorem:  " + currTheorem + "\n\n");
		appMsg.appendText("Now, please enter the mappings as requested in the text box provided above.\n");
		appMsg.appendText("When asked for the mapping for an atom, you must type another atom.\n");
		appMsg.appendText("IMPORTANT: it is your responsibility to make sure that the resultant");
		appMsg.appendText(" instance is valid!");
		dataEntryState = 6; /* indicate reading data for theorems */
		assump.setText((String)mapKeys.elementAt(0) + " = ");
		currMap = 0;
		dataEntry.setText("");
		dataEntry.enable();
		topSub.add("South", input);
		validate();
		dataEntry.requestFocus();
	}

	private void chosenMap(String value)
	/* called when entered the next mapping for theorem application */
	{
		String mapKey = (String)mapKeys.elementAt(currMap);
		String mapValue = value;
		/* store mapping */
		mappings.put(mapKey, mapValue);

		if (currMap == mapKeys.size() - 1)
		/* if no more mappings to ask for */
		{
			/* process the mappings from the user */
			checkMappings();
		}
		else
		{
			currMap++;
			topSub.remove(input);
			validate();
			assump.setText((String)mapKeys.elementAt(currMap) + " = ");
			dataEntry.setText("");
			dataEntry.enable();
			topSub.add("South", input);
			validate();
			dataEntry.requestFocus();
		}
	}

	private void checkMappings()
	/* called when the user has finished giving all the mappings needed
	   for applying the chosen theorem */
	{
		dataEntryState = 9; /* no input currently read */

		topSub.remove(input); /* no more data entry */
		validate();

		/* make a copy of the theorem expression tree - need it 
		   later for adding a special line for the theorem schema */
		ExprTree currTheoremTreeCopy = null;
		try
		{
			currTheoremTreeCopy = (ExprTree)currTheoremTree.clone();
		}
		catch (CloneNotSupportedException e)
		{
			/* should never happen */
			System.out.println(e.getMessage());
		}

		/* need to apply the mappings - i.e. make all the 
		   substitutions */
		Hashtable sigVar = GlobalTables.tempVarList();
		for (Enumeration e = mappings.keys(); e.hasMoreElements(); )
		{
			/* get key */
			String key = (String)e.nextElement();
			/* get value */
			String value = (String)mappings.get(key);
			/* substitute all occurrences of key in value in theorem;
			   do variables and atoms separately */
			if (sigVar.containsKey(key))
			/* if variable */
			{
				currTheoremTreeCopy.substituteVarDecl(key, value);
			}
			else
			/* if atom */
			{
				currTheoremTreeCopy.substituteAtom(key, value);
			}
		}
			
		/* Now to add the free variables as universal quantifiers */
		for (int i = 0; i < freeVars.size(); i++)
		{
			ExprTreeValue v = new ExprTreeValue("Quant", "A", (String)freeVars.elementAt(i));
			ExprTree newT = new ExprTree(v);
			newT.setRightChild(currTheoremTreeCopy);
			currTheoremTreeCopy = newT;
		}

		/* get the resulting instance */
		String instance = currTheoremTreeCopy.strContents();
				
		/* now need to properly parse the instance */
		
		GlobalTables.initTempLists();
		ExprTree instanceExpr = null;
		try
		{
			instanceExpr = datain.syntaxAnalyse(instance);
			/* if got to this point - parser succeeded */

			ContextTree thisCont = currLine.getContext();

			/* cannot use any constants beginning with 'sk' unless they
			   already local to this context */
			for (Enumeration e = GlobalTables.tempConstList().keys(); e.hasMoreElements(); )
			{
				String currConst = (String)e.nextElement();
				if (currConst.startsWith("sk"))
				{
					if (thisCont.searchConstInParents(currConst) == false)
					{
						appMsg.setText("Failed to apply theorem:\n\n");
						appMsg.appendText("Cannot introduce constants starting with 'sk'!");
						/* re-enable buttons and menu-items */
						returnFromClicked();
						return;
					}
					else
					{
						GlobalTables.tempConstList().remove(currConst);
					}
				}
			}
			
			/* now need to strip off the universal quantifiers for
			   the free variables again */
			for (int i = 0; i < freeVars.size(); i++)
			{
				instanceExpr = (ExprTree)instanceExpr.getRightChild();
			}

			currInstanceExpr = instanceExpr; /* record instance
											    expression */
			instance = instanceExpr.strContents();

			appMsg.setText("Theorem " + currTheorem + " applied.\n");
			appMsg.appendText("Instance used is: " + instance + "\n\n");
			appMsg.appendText("Check now to make sure this instance is valid.\n");
			appMsg.appendText("If you think the instance is ok, press 'Y'. To cancel, press 'N'.");
		}
		catch (Exception e)
		/* if an error was encountered in input - re-read new disjunct */
		{
			appMsg.setText("Failed to apply theorem:\n\n");
			appMsg.appendText("Parsing of your input has failed!\n");
			appMsg.appendText(e.getMessage());
			/* re-enable buttons and menu-items */
			returnFromClicked();
		}
	}

	public void theoremDone()
	/* called when the user has confirmed the generation of the
	   theorem instance */
	{
		/* re-enable buttons and menu-items */
		returnFromClicked();

		/* update the global tables */
		GlobalTables.updateTables();

		ContextTree thisCont = currLine.getContext();
		
		/* check if there is enough height */
		int reqHeight = 2 * lineBoxHeight + 6;
		int availHeight = thisCont.minBelowLine(currLine) - (currLine.getRectArea().y
						  + currLine.getRectArea().height);
		if (reqHeight > availHeight)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
								   currLine.getRectArea().y + currLine.getRectArea().height);
		}
		
		/* first line added is the theorem schema */
		currLine.userDefinedStatus(true);
		currLine.assignExpr(currTheoremTree);
		currLine.assignRef("Theorem");
		currLine.setRuleAppliedTo("Theorem");
		currLine.setNum("***"); /* temporarily */
		currLine.setTheorem(true); /* it is a theorem and is not 
									  usable as a schema */

		/* record position of current line */			
		int index = thisCont.getProofLines().indexOf(currLine);
		/* add the theorem instance */
		ProofLine extraLine = new ProofLine("***", thisCont, true, currInstanceExpr);
		extraLine.assignRef("Instance");
		extraLine.setRuleAppliedTo("Theorem");
		extraLine.setTheoremInst(true);
		extraLine.setRectHeight(lineBoxHeight);
		extraLine.setRectPos(new Point(currLine.getRectArea().x, currLine.getRectArea().y +
									   currLine.getRectArea().height + 2));
		extraLine.setLinePos(new Point(extraLine.getRectArea().x + 2,
									   extraLine.getRectArea().y + lineHeight + 2));
		/* add instance below schema */
		thisCont.addProofLineAt(extraLine, index + 1);

		/* create a new empty proof line */
		ProofLine emptyLine = createEmptyLine(thisCont, "***");
		emptyLine.setRectHeight(lineBoxHeight);
		emptyLine.setRectPos(new Point(currLine.getRectArea().x, currLine.getRectArea().y + lineBoxHeight + 2
			                           + lineBoxHeight + 2));
		emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y +
									   lineHeight + 2));
		/* add new empty line below the theorem instance */
		thisCont.addProofLineAt(emptyLine, index + 2);
		thisCont.setBottomDerived(emptyLine);

		/* now check whether the refPos can still stay the same */
		int minRefPos;
		
		int refPos1 = currLine.getLinePos().x + fm.stringWidth(currLine.getNum()) +
			          currLine.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(currLine.getExpr().strContents())) +
					  currLine.getRefSpace();
		int refPos2 = extraLine.getLinePos().x + fm.stringWidth(extraLine.getNum()) +
			          extraLine.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(extraLine.getExpr().strContents())) +
					  extraLine.getRefSpace();
		if (refPos1 > refPos2)
		{
			minRefPos = refPos1;
		}
		else
		{
			minRefPos = refPos2;
		}
					
		if (thisCont.getRefPos() < minRefPos)
		/* if need to move refPos */
		{
			thisCont.setRefPos(minRefPos);
			thisCont.updateLineRecs(pArea);
		}

		currLine.setRectWidth(thisCont.getRefPos() + fm.stringWidth(currLine.getRef()) + 2
			                 - currLine.getRectArea().x);
		extraLine.setRectWidth(thisCont.getRefPos() + fm.stringWidth(extraLine.getRef()) + 2
			                 - extraLine.getRectArea().x);
		emptyLine.setRectWidth(emptyLine.minimumWidth(fm));

		/* now check if need to increase the width of the context */
		int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
		int availWidth = thisCont.getBox().width;

		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = thisCont.getBox().width; 
		}
					
		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		UndoObject undo = new UndoObject("Theorem", false, currLine, new Vector());
		undo.setOtherLine(extraLine);
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);

		/* make sure that the theorem is not selected */
		clickedProofArea(emptyLine.getRectArea().x + 1,
						 emptyLine.getRectArea().y + 1);

		appMsg.setText("Theorem applied OK.");
		/* tell user which terms/predicates would be introduced */
		showNewConsts();
		showNewVars();
		showNewFuncts();
		showNewPreds();

		/* repaint canvas to reflect changes */
		pArea.paintMe(horizOffset, vertOffset);

	}
			
	public void whatNow()
	/* this method is called when the user requests some immediate help.
	   NOTE: this method is rather simple and in the future much more
	         help could be given to the user by doing some more 
			 processing on the current proof structure */
	{
		if (main.isProved())
		/* if proof complete already */
		{
			appMsg.setText("You have already completed the proof!");
		}
		else
		{
			ContextTree thisCont = currLine.getContext();
			if (thisCont.isProved())
			/* if current context already proven */
			{
				appMsg.setText("The box of the current line is already done!");
			}
			else
			{
				ProofLine thisGoal = thisCont.getGoal();
				if (thisGoal.getRuleAppliedTo().equals(""))
				/* if can still do something with the goal of the current
				   context */
				{
					if (thisGoal.canAnd())
					{
						appMsg.setText("How about And Introduction backwards");
						appMsg.appendText(" from line "+thisGoal.getNum()+"?");
						return;
					}
					if (thisGoal.canIff())
					{
						appMsg.setText("How about Iff Introduction backwards");
						appMsg.appendText(" from line "+thisGoal.getNum()+"?");
						return;
					}
					if (thisGoal.canNot())
					{
						appMsg.setText("How about Not Introduction backwards");
						appMsg.appendText(" from line "+thisGoal.getNum()+"?");
						return;
					}
					if (thisGoal.canArrow())
					{
						appMsg.setText("How about Arrow Introduction backwards");
						appMsg.appendText(" from line "+thisGoal.getNum()+"?");
						return;
					}
					if (thisGoal.canForAll())
					{
						appMsg.setText("How about For All Introduction backwards");
						appMsg.appendText(" from line "+thisGoal.getNum()+"?");
						return;
					}
					if (thisGoal.canOr())
					{
						appMsg.setText("How about Or Introduction backwards");
						appMsg.appendText(" from line "+thisGoal.getNum()+"?");
						return;
					}
					if (thisGoal.canExists())
					{
						if ((!(GlobalTables.constTable().isEmpty())) ||
						   (thisCont.localConstsAvail()))
						{
							appMsg.setText("How about Existential Introduction backwards");
							appMsg.appendText(" from line "+thisGoal.getNum()+"?");
							return;
						}
					}
					/* if got to this point, then none of the above
					   were applicable */
					appMsg.setText("If the current goal is not already proven earlier in the proof,");
					appMsg.appendText(" then consider one of the following for line "+thisGoal.getNum()+":\n");
					appMsg.appendText("(you may need to scroll this text area to see all the suggestions...)");
					appMsg.appendText("\n*** Can this goal be derived (forwards) from an existing sentence using a simple elimination?");
					if (thisGoal.getExpr().strContents().equals("false"))
					{
						appMsg.appendText("\n*** If there is any negative sentence above it, why not try Not Elimination");
						appMsg.appendText(" backwards?");
					}
					appMsg.appendText("\n*** Is there any implication which could be used for Arrow Elimination");
					appMsg.appendText(" backwards?");
					appMsg.appendText("\n*** Is there any disjunction which could be used for Or Elimination?");
					appMsg.appendText("\n*** Is there any existential sentence for Existential Elimination?");
					appMsg.appendText("\n*** Think of a possible lemma");
					if (!(thisGoal.getExpr().strContents().equals("false")))
					{
						appMsg.appendText("\n*** Is there any equivalence available for rewriting line ");
						appMsg.appendText(thisGoal.getNum()+" to a better form?");
					}
					appMsg.appendText("\n*** Will any of the stored theorems help?");
					appMsg.appendText("\n*** Try adding a tautology as a new given and then use Or Elimination");
					if (!(thisGoal.getExpr().strContents().equals("false")))
					{
						appMsg.appendText("\n*** If all else fails, try Proof by Contradiction (PC)");
					}
					appMsg.select(0, 0);
				}
				else
				{
					appMsg.setText("You have already applied a rule to the goal of the current context.\n");
				}
			}
		}
	}

	public void characters()
	/* called when the user wishes to see what the characters 
	   mapping is */
	{
		appMsg.setText("The characters used in New Pandora are:\n\n");
		appMsg.appendText("And:  ^  ,  Or:  |  ,  Implies:  >  ,  Iff:  #  ,  Not:  ~  ,  ");
		appMsg.appendText("For-All:  A  ,  There-Exists:  E  ,  Bottom:  false  ,  Truth:  true.\n");
		appMsg.appendText("Equality should be typed in with the predicate eq, i.e. eq(X,Y)");
	}

	public void userGuide()
	/* called when the user wishes to see the user-guide. Only
	   applicable on PC having WinWord installed */
	{
		String os = System.getProperty("os.name");
		if (os.startsWith("Windows"))
		/* if Windows operating system */
		{
			/* create the character-streams for reading text file */
			String currDir = System.getProperty("user.dir");
			String fileSep = System.getProperty("file.separator");

			String wordConfig = null;

			/* now read INI file */
			try
			{
				BufferedReader br = new BufferedReader(new FileReader(currDir + fileSep + "Config.ini"));

				/* first line in file contains path to WinWord */
				wordConfig = br.readLine();
				
				br.close(); /* close stream */
			}
			catch (FileNotFoundException e)
			{
				ErrorDlg ed = new ErrorDlg((Frame)this.getParent(),
				                       "File Config.ini not found!");
				ed.initialise();
				/* position dialog box in the middle of the screen */
				ed.move((int)((screenSize.width / 2) - (ed.size().width / 2)), 
						(int)((screenSize.height / 2) - (ed.size().height / 2)));
				ed.show();
				return;
			}
			catch (IOException e)
			{
				ErrorDlg ed = new ErrorDlg((Frame)this.getParent(),
							               "Error occurred when trying to read Config.ini!");
				ed.initialise();
				/* position dialog box in the middle of the screen */
				ed.move((int)((screenSize.width / 2) - (ed.size().width / 2)), 
						(int)((screenSize.height / 2) - (ed.size().height / 2)));
				ed.show();
				return;
			}

			try
			{
				Runtime rt = Runtime.getRuntime();
				rt.exec(wordConfig + " UserGu~1.doc");
			}
			catch (IOException e)
			{
				ErrorDlg ed = new ErrorDlg((Frame)this.getParent(),
							               "Could not start the User Guide!");
				ed.initialise();
				/* position dialog box in the middle of the screen */
				ed.move((int)((screenSize.width / 2) - (ed.size().width / 2)), 
						(int)((screenSize.height / 2) - (ed.size().height / 2)));
				ed.show();
				return;

			}		
		}
	}

	public void andIntroBack(ProofLine pl)
	/* applies the and introduction rule backwards to the given
	   ProofLine */
	{

		ContextTree cont = pl.getContext();	

		ContextTree sub1 = null;
		ContextTree sub2 = null;
		/* create new sub-contexts */
		try
		{
			sub1 = new ContextTree("AndI");
			sub2 = new ContextTree("AndI");
		}
		catch (InvalidContextException e) 
		{ System.out.println(e.getMessage()); }

		cont.addChildTree(sub1);
		cont.addChildTree(sub2);
		sub1.setParent(cont);
		sub1.setApp(this);
		sub2.setParent(cont);
		sub2.setApp(this);
		
		/* now check whether boxes have enough space */

		/* we know we will have at least two lines ... */
		int reqHeight = 2 * lineBoxHeight + 2 + 10;
		int availHeight = (pl.getRectArea().y - 5) - (cont.getBottomDerived().getRectArea().y +
			              cont.getBottomDerived().getRectArea().height + 5);
		if (reqHeight > availHeight)
		/* if not enough space - extend context and parents ... */
		{
			cont.extendHeight(reqHeight - availHeight + lineBoxHeight + 2, pl);
			availHeight = (pl.getRectArea().y - 5) - (cont.getBottomDerived().getRectArea().y +
			              cont.getBottomDerived().getRectArea().height + 5);	
		}
	
		/* create the proof lines now */
		ExprTree expr = pl.getExpr();
		ProofLine pl1 = new ProofLine("***", sub1, false, (ExprTree)expr.getLeftChild());
		pl1.assignRef("***************"); /* only temporarily for graphical reasons */
		pl1.goalStatus(true);
		sub1.addProofLine(pl1);
		sub1.setGoal(pl1);
		ProofLine pl2 = new ProofLine("***", sub2, false, (ExprTree)expr.getRightChild());
		pl2.assignRef("***************"); /* only temporarily for graphical reasons */
		pl2.goalStatus(true);
		sub2.addProofLine(pl2);
		sub2.setGoal(pl2);
		ProofLine emptyLine1 = createEmptyLine(sub1, "***");
		sub1.addProofLineAt(emptyLine1, 0);
		sub1.setBottomDerived(emptyLine1);
		ProofLine emptyLine2 = createEmptyLine(sub2, "***");
		sub2.addProofLineAt(emptyLine2, 0);
		sub2.setBottomDerived(emptyLine2);

		/* now check if we are wide enough */
		int widthSub1 = sub1.minWidth(pArea);
		int widthSub2 = sub2.minWidth(pArea);
		int reqWidth = widthSub1 + widthSub2;
		int availWidth = cont.getBox().width - 2 * subDist - siblingDist;
		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */
		{
			cont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = cont.getBox().width - 2 * subDist - siblingDist; 
		}

		/* now we know we have enough space to put boxes */

		/* layout the boxes and lines on the proof area : */
		sub1.setBoxPos(new Point(cont.getBox().x + subDist, cont.getBottomDerived().getRectArea().y +
			           cont.getBottomDerived().getRectArea().height + 5));
		sub1.setBoxWidth(widthSub1 + ((availWidth - reqWidth) / 2));
		sub1.setBoxHeight(pl.getRectArea().y - sub1.getBox().y - 5);
		
		sub2.setBoxPos(new Point(sub1.getBox().x + sub1.getBox().width + siblingDist,
								 sub1.getBox().y));
		sub2.setBoxWidth(widthSub2 + ((availWidth - reqWidth) / 2));
		sub2.setBoxHeight(sub1.getBox().height);
		
		pl1.setRectPos(new Point(sub1.getBox().x + 5, sub1.getBox().y + sub1.getBox().height - lineBoxHeight - 5));
		pl1.setRectHeight(lineBoxHeight);
		pl1.setRectWidth(sub1.getBox().width - 10);
		pl1.setLinePos(new Point(pl1.getRectArea().x + 2, pl1.getRectArea().y + lineHeight + 2));

		pl2.setRectPos(new Point(sub2.getBox().x + 5, sub2.getBox().y + sub2.getBox().height - lineBoxHeight - 5));
		pl2.setRectHeight(lineBoxHeight);
		pl2.setRectWidth(sub2.getBox().width - 10);
		pl2.setLinePos(new Point(pl2.getRectArea().x + 2, pl2.getRectArea().y + lineHeight + 2));
		
		emptyLine1.setRectPos(new Point(pl1.getRectArea().x, sub1.getBox().y + 5));
		emptyLine1.setRectHeight(lineBoxHeight);
		emptyLine1.setRectWidth(sub1.getBox().width - 10);
		emptyLine1.setLinePos(new Point(emptyLine1.getRectArea().x + 2, emptyLine1.getRectArea().y + lineHeight + 2));

		emptyLine2.setRectPos(new Point(pl2.getRectArea().x, sub2.getBox().y + 5));
		emptyLine2.setRectHeight(lineBoxHeight);
		emptyLine2.setRectWidth(sub2.getBox().width - 10);
		emptyLine2.setLinePos(new Point(emptyLine2.getRectArea().x + 2, emptyLine2.getRectArea().y + lineHeight + 2));
		
		/* update reference position for new contexts */
		sub1.setRefPos(pl1.getRectArea().x + pl1.getRectArea().width
			           - 2 - fm.stringWidth(pl1.getRef()));
		sub2.setRefPos(pl2.getRectArea().x + pl2.getRectArea().width
					   - 2 - fm.stringWidth(pl2.getRef()));
	
		pl1.assignRef("");
		pl2.assignRef("");

		/* mark that a rule has been applied to this line */
		pl.setRuleAppliedTo("AndI");

		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();
		
		pl.assignRef("^I");
		cont.updateLineRecs(pArea);

		pArea.paintMe(horizOffset, vertOffset);
		appMsg.setText("Rule applied OK.");

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		Vector subs = new Vector();
		subs.addElement(sub1);
		subs.addElement(sub2);
		UndoObject undo = new UndoObject("AndI", true, pl, subs);
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);
	}
	
	public void andIntroFor(ProofLine pl)
	/* applies the and introduction rule forwards */
	{
		/* indicate that now waiting for the user to click the
		   the first proof line */
		appMsg.setText("Please click the two proof lines for And Introduction...");
		/* now need to wait for the proof lines to be clicked */
		currRule = "AndI";
		waitForClick();									
	}

	public void andIntroForDone(ProofLine pl1, ProofLine pl2,
								ProofLine current)
	/* called when the user has chosen the two proof lines for
	   and introduction forwards */
	{
		/* re-enable buttons and menu-items */
		returnFromClicked();
		
		/* get context of current line */
		ContextTree thisCont = current.getContext();
		/* must check that both conjuncts are accessible within this
		   context */
		ContextTree cont1 = pl1.getContext();
		ContextTree cont2 = pl2.getContext();
		if (((thisCont == cont1) || (cont1.isParentOf(thisCont)))
			&& ((thisCont == cont2) || (cont2.isParentOf(thisCont)))
			&& (pl1.getRectArea().y < current.getRectArea().y)
			&& (pl2.getRectArea().y < current.getRectArea().y)
			&& (!(pl1.isEmpty())) && (!(pl2.isEmpty())))
		/* if valid context relation and line positions */
		{		
			/* check if there is enough height */
			int reqHeight = lineBoxHeight + 4;
			int availHeight = thisCont.minBelowLine(current) - (current.getRectArea().y
				              + current.getRectArea().height);
									
			if (reqHeight > availHeight)
			/* if not enough space - extend context and parents ... */
			{
				thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
									   current.getRectArea().y + current.getRectArea().height);
			}

			current.userDefinedStatus(true);

			/* record position of current line */			
			int index = thisCont.getProofLines().indexOf(current);
			/* create a new empty proof line */
			ProofLine emptyLine = createEmptyLine(thisCont, "***");
			emptyLine.setRectHeight(lineBoxHeight);
			emptyLine.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y +
				                           current.getRectArea().height + 2));
			emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y +
										   lineHeight + 2));
			/* add new empty line just below the current line */
			thisCont.addProofLineAt(emptyLine, index + 1);
			thisCont.setBottomDerived(emptyLine);

			/* create conjunction */
			ExprTree left = pl1.getExpr();
			ExprTree right = pl2.getExpr();
			ExprTreeValue exprValue = new ExprTreeValue("Op2", "^");
			ExprTree newExpr = new ExprTree(exprValue);
			newExpr.setLeftChild(left);
			newExpr.setRightChild(right);
			current.assignExpr(newExpr);
			current.assignRef("^I("+pl1.getNum()+","+pl2.getNum()+")");
			current.setNum("***"); /* temporarily */
			
			/* now check whether the refPos can still stay the same */
			int minRefPos = current.getLinePos().x + fm.stringWidth(current.getNum()) +
				            current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
							current.getRefSpace();
			
			if (thisCont.getRefPos() < minRefPos)
			/* if need to move refPos */
			{
				thisCont.setRefPos(minRefPos);
				thisCont.updateLineRecs(pArea);
			}

			current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
				                 - current.getRectArea().x);
			emptyLine.setRectWidth(emptyLine.minimumWidth(fm));

			/* now check if need to increase the width of the context */
			int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
			int availWidth = thisCont.getBox().width;

			if (reqWidth > availWidth)
			/* if not enough space - extend context and parents ... */
			{
				thisCont.extendWidth(reqWidth - availWidth + 15);
				/* re-calculate the available width */
				availWidth = thisCont.getBox().width; 
			}
						
			current.setRuleAppliedTo("AndI");

			/* now renumber all the lines in the proof */
			main.reLabel();
			/* update references to reflect new line numbers */
			main.updateReferences();
			
			/* repaint canvas to reflect changes */
			pArea.paintMe(horizOffset, vertOffset);
			appMsg.setText("Rule applied OK.");

			/* record proof is now not saved */
			isSaved = false; 
			saveStatus.setText("Changes Not Saved");

			/* record action for undo purposes */
			UndoObject undo = new UndoObject("AndI", false, current, new Vector());
			undoStack.push(undo);
			btnUndo.enable();
			Vector enable = new Vector();
			enable.addElement("Undo");
			menuItems(enable, (Frame)getParent(), true);
		}
		else
		{
			appMsg.setText("Could not apply rule: at least one of the lines ");
			appMsg.appendText("you clicked is not accessible");
		}
	}

	public void andElim(ProofLine pl)
	/* applies the and elimination rule (always forwards) */
	{
		/* indicate that now waiting for the user to click the
		   the relevant proof line */
		appMsg.setText("Please click the line to use for And Elimination...");
		/* now need to wait for the proof line to be clicked */
		currRule = "AndE";
		waitForClick();									
	}

	public void andElimChosenLine()
	/* called when the user has chosen the line to which to apply 
	   and elimination */
	{
		/* get context of current line */
		ContextTree thisCont = currLine.getContext();
		/* must check that chosen line is accessible within this
		   context */
		ContextTree contChosen = clicked1.getContext();

		if (((thisCont == contChosen) || (contChosen.isParentOf(thisCont)))
			&& (clicked1.getRectArea().y < currLine.getRectArea().y)
			&& (!(clicked1.isEmpty())))
		/* if valid context relation and line positions */
		{
			if (!(clicked1.canAnd()))
			/* chosen line must be a conjunction */
			{
				appMsg.setText("Could not apply rule: selected line is not a conjunction.");
				/* re-enable buttons / menu items */
				returnFromClicked();
			}
			else 
			{
				/* now ask the user whether to get the left or right subtree
				   of the And expression */
				appMsg.setText("Line " + clicked1.getNum() + " chosen.\nPress 'L' to ");
				appMsg.appendText(" to deduce the left conjunct, 'R' to deduce the ");
				appMsg.appendText("right conjunct, or 'B' to deduce both.");
				/* make sure mouse clicking does nothing */
				clickStatus = 0;
			}
		}
		else
		{
			appMsg.setText("Could not apply rule: the line you selected is not accessible");
			/* re-enable buttons / menu items */
			returnFromClicked();
		}
	}

	public void andElimDone(ProofLine chosen, ProofLine current,
							int leftOrRight)
	/* called when all parameters for and elimination have been
	   collected.
	   Pre-condition: leftOrRight must be one of LEFTS, RIGHTS,
	                  LEFTC and RIGHTC */
	{
		/* re-enable buttons / menu items */
		returnFromClicked();	
		/* get context of current line */
		ContextTree thisCont = current.getContext();

		int reqHeight;
		/* check if there is enough height */
		if ((leftOrRight == BOTHS) || (leftOrRight == BOTHC))
		{
			reqHeight = 2 * lineBoxHeight + 6;
		}
		else
		{
			reqHeight = lineBoxHeight + 4;
		}

		int availHeight = thisCont.minBelowLine(current) - (current.getRectArea().y
			              + current.getRectArea().height);
									
		if (reqHeight > availHeight)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
								   current.getRectArea().y + current.getRectArea().height);
		}
			
		current.userDefinedStatus(true);

		/* create a new empty proof line */
		ProofLine emptyLine = createEmptyLine(thisCont, "***");
		emptyLine.setRectHeight(lineBoxHeight);
		if ((leftOrRight == BOTHS) || (leftOrRight == BOTHC))
		/* position of empty line depends on user input */
		{
			emptyLine.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y +
										   lineBoxHeight + 2 + lineBoxHeight + 2));

		}
		else
		{
			emptyLine.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y +
										   current.getRectArea().height + 2));
		}
		
		emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y +
									   lineHeight + 2));
		
		/* record position of current line */			
		int index = thisCont.getProofLines().indexOf(current);

		ExprTree newExpr, newExpr2;
		ProofLine extraLine = null;

		if ((leftOrRight == BOTHS) || (leftOrRight == BOTHC))
		{
			newExpr = (ExprTree)chosen.getExpr().getLeftChild();
			newExpr2 = (ExprTree)chosen.getExpr().getRightChild();

			/* create an additional new line */
			extraLine = new ProofLine("***", thisCont, true, newExpr2);
			thisCont.addProofLineAt(extraLine, index + 1);
			extraLine.assignRef("^E("+chosen.getNum()+")");
			extraLine.setRuleAppliedTo("AndE");
			extraLine.setRectHeight(lineBoxHeight);
			extraLine.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y +
										   current.getRectArea().height + 2));
			extraLine.setLinePos(new Point(extraLine.getRectArea().x + 2,
										   extraLine.getRectArea().y + lineHeight + 2));

			/* add new empty line just below the current line */
			thisCont.addProofLineAt(emptyLine, index + 2);
		}
		else
		{						
			/* create line(s) for conjunct(s) - content depends on which
			   conjunct the user wanted */
			if ((leftOrRight == LEFTC) || (leftOrRight == LEFTS))
			/* if left conjunct */
			{
				newExpr = (ExprTree)chosen.getExpr().getLeftChild();
			}
			else
			{
				newExpr = (ExprTree)chosen.getExpr().getRightChild();
			}

			/* add new empty line just below the current line */
			thisCont.addProofLineAt(emptyLine, index + 1);
		}

		thisCont.setBottomDerived(emptyLine);

		current.assignExpr(newExpr);
		current.assignRef("^E("+chosen.getNum()+")");
		current.setNum("***"); /* temporarily */

		/* now check whether the refPos can still stay the same */
		int minRefPos;
		
		if ((leftOrRight == BOTHS) || (leftOrRight == BOTHC))
		{
			int refPos1 = current.getLinePos().x + fm.stringWidth(current.getNum()) +
			          current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
					  current.getRefSpace();
			int refPos2 = extraLine.getLinePos().x + fm.stringWidth(extraLine.getNum()) +
			          extraLine.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(extraLine.getExpr().strContents())) +
					  extraLine.getRefSpace();
			if (refPos1 > refPos2)
			{
				minRefPos = refPos1;
			}
			else
			{
				minRefPos = refPos2;
			}
		}
		else
		{
			minRefPos = current.getLinePos().x + fm.stringWidth(current.getNum()) +
			            current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
						current.getRefSpace();
		}

		if (thisCont.getRefPos() < minRefPos)
		/* if need to move refPos */
		{
			thisCont.setRefPos(minRefPos);
			thisCont.updateLineRecs(pArea);
		}

		current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
			                 - current.getRectArea().x);
		emptyLine.setRectWidth(emptyLine.minimumWidth(fm));
		if ((leftOrRight == BOTHS) || (leftOrRight == BOTHC))
		{
			extraLine.setRectWidth(thisCont.getRefPos() + fm.stringWidth(extraLine.getRef()) + 2
			                 - extraLine.getRectArea().x);
		}

		/* now check if need to increase the width of the context */
		int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
		int availWidth = thisCont.getBox().width;

		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = thisCont.getBox().width; 
		}
				
		/* mark rule has been applied to the current line */
		current.setRuleAppliedTo("AndE");

		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();
			
		/* repaint canvas to reflect changes */
		pArea.paintMe(horizOffset, vertOffset);
		appMsg.setText("Rule applied OK.");

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		UndoObject undo = new UndoObject("AndE", false, current, new Vector());
		if ((leftOrRight == BOTHS) || (leftOrRight == BOTHC))
		{
			undo.setOtherParam("B"); /* only one conjunct (L or R) */
			undo.setOtherLine(extraLine); /* record second line */
		}
		else
		{
			undo.setOtherParam(""); /* both conjuncts (B) */
		}
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);
	}

	public void arrowElimBack(ProofLine pl)
	/* applies the arrow elimination rule backwards from the given proof
	   line */
	{
		/* need to know which proof line to use for the 
		   elimination */
		appMsg.setText("Please click the line to use for Arrow Elimination...");
		/* now need to wait for the proof line to be clicked */
		currRule = "ArrowE";
		waitForClick();									
	}

	public void arrowElimBackChosenLine(ProofLine chosen, 
										ProofLine current)
	/* called when the user has selected which line to apply the
	   arrow elimination to (besides the current line) */
	{
		/* re-enable buttons / menu items */
		returnFromClicked();
		/* get context of current line */
		ContextTree thisCont = current.getContext();
		/* must check that chosen line is accessible within this
		   context */
		ContextTree contChosen = chosen.getContext();

		if (((thisCont == contChosen) || (contChosen.isParentOf(thisCont)))
			&& (chosen.getRectArea().y < current.getRectArea().y)
			&& (!(chosen.isEmpty())))
		/* if valid context relation and line positions */
		{
			/* check if RHS of chosen line matches with current line */
			if ((chosen.canArrow())
			   && ((((ExprTree)chosen.getExpr().getRightChild()).strContents().equals(current.getExpr().strContents()))
			   || (((ExprTree)chosen.getExpr().getRightChild()).commutesWith(current.getExpr()))))
			{
				/* check if there is enough height */
				int reqHeight = lineBoxHeight + 4;
				int availHeight = current.getRectArea().y - (thisCont.getBottomDerived().getRectArea().y
								  + thisCont.getBottomDerived().getRectArea().height);
				if (reqHeight > availHeight)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
										   current.getRectArea().y - 1);
				}
							
				/* now create new proof line */
				ExprTree newExpr = (ExprTree)chosen.getExpr().getLeftChild();
				ProofLine newGoal = new ProofLine("***", thisCont, true, newExpr);
				newGoal.setRectHeight(lineBoxHeight);
				newGoal.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y -
				                            (newGoal.getRectArea().height + 2)));
				newGoal.setLinePos(new Point(newGoal.getRectArea().x + 2, newGoal.getRectArea().y +
										     lineHeight + 2));

				/* record position of current line */			
				int index = thisCont.getProofLines().indexOf(current);
				/* add new goal before current line */
				thisCont.addProofLineAt(newGoal, index);
				thisCont.setGoal(newGoal);
				newGoal.goalStatus(true);
				current.goalStatus(false);
				/* mark rule has been applied to the current line */
				current.setRuleAppliedTo("ArrowE");
				current.assignRef("***************"); /* temporarily */
				newGoal.assignRef("***************"); /* temporarily */

				/* now check whether the refPos can still stay the same */
				int minRefPos1 = current.getLinePos().x + fm.stringWidth(current.getNum()) +
					            current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
								current.getRefSpace();
				int minRefPos2 = newGoal.getLinePos().x + fm.stringWidth(newGoal.getNum()) +
					            newGoal.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(newGoal.getExpr().strContents())) +
								newGoal.getRefSpace();
				int minRefPos;
				if (minRefPos1 > minRefPos2)
				{
					minRefPos = minRefPos1;
				}
				else
				{
					minRefPos = minRefPos2;
				}
			
				if (thisCont.getRefPos() < minRefPos)
				/* if need to move refPos */
				{
					thisCont.setRefPos(minRefPos);
					thisCont.updateLineRecs(pArea);
				}

				current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
					                 - current.getRectArea().x);
				newGoal.setRectWidth(newGoal.minimumWidth(fm));
				
				/* now check if need to increase the width of the context */
				int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
				int availWidth = thisCont.getBox().width;

				if (reqWidth > availWidth)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.extendWidth(reqWidth - availWidth + 15);
					/* re-calculate the available width */
					availWidth = thisCont.getBox().width; 
				}
			
				/* now renumber all the lines in the proof */
				main.reLabel();
				/* update references to reflect new line numbers */
				main.updateReferences();
			
				/* assign reference to current line */
				current.assignRef(">E("+chosen.getNum()+","+newGoal.getNum()+")");
				newGoal.assignRef("");
				
				/* repaint canvas to reflect changes */
				pArea.paintMe(horizOffset, vertOffset);
				appMsg.setText("Rule applied OK.");

				/* record proof is now not saved */
				isSaved = false; 
				saveStatus.setText("Changes Not Saved");

				/* record action for undo purposes */
				UndoObject undo = new UndoObject("ArrowE", true, newGoal, new Vector());
				undoStack.push(undo);
				btnUndo.enable();
				Vector enable = new Vector();
				enable.addElement("Undo");
				menuItems(enable, (Frame)getParent(), true);
			}
			else if (!(chosen.canArrow()))
			{
				appMsg.setText("The line you have chosen is not applicable for Arrow Elimination!");
			}
			else
			{	
				appMsg.setText("Could not apply rule: mismatch between current line and RHS of chosen line!");
			}
		}
		else
		{
			appMsg.setText("Could not apply rule: the line you clicked is not accessible");
		}
	}

	public void arrowElimFor(ProofLine pl)
	/* applies the arrow elimination rule forwards for the given proof
	   line */
	{
		/* need to know which proof lines to use for the 
		   elimination */
		appMsg.setText("Please click the two lines to use for Arrow Elimination...");
		/* now need to wait for the proof lines to be clicked */
		currRule = "ArrowE";
		waitForClick();									
	}

	public void arrowElimForChosenLine(ProofLine chosen1,
									   ProofLine chosen2,
									   ProofLine current)
	/* called when the user has selected the two lines to which
	   to apply the arrow elimination rule (forwards) */
	{
		/* re-enable buttons / menu items */
		returnFromClicked();
		/* get context of current line */
		ContextTree thisCont = current.getContext();
		/* must check that both lines are accessible within this
		   context */
		ContextTree cont1 = chosen1.getContext();
		ContextTree cont2 = chosen2.getContext();
		if (((thisCont == cont1) || (cont1.isParentOf(thisCont)))
			&& ((thisCont == cont2) || (cont2.isParentOf(thisCont)))
			&& (chosen1.getRectArea().y < current.getRectArea().y)
			&& (chosen2.getRectArea().y < current.getRectArea().y)
			&& (!(chosen1.isEmpty())) && (!(chosen2.isEmpty())))
		/* if valid context relation and line positions */
		{
			if (((chosen1.canArrow()) &&
			   ((((ExprTree)chosen1.getExpr().getLeftChild()).strContents().equals(chosen2.getExpr().strContents())) ||
			   (((ExprTree)chosen1.getExpr().getLeftChild()).commutesWith(chosen2.getExpr()))))
			   || 
			   ((chosen2.canArrow()) &&
			   ((((ExprTree)chosen2.getExpr().getLeftChild()).strContents().equals(chosen1.getExpr().strContents())) ||
			   (((ExprTree)chosen2.getExpr().getLeftChild()).commutesWith(chosen1.getExpr())))))
			{
				/* check if there is enough height */
				int reqHeight = lineBoxHeight + 4;
				int availHeight = thisCont.minBelowLine(current) - (current.getRectArea().y
								  + current.getRectArea().height);
				if (reqHeight > availHeight)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
										   current.getRectArea().y + current.getRectArea().height);
				}
				
				current.userDefinedStatus(true);

				/* record position of current line */			
				int index = thisCont.getProofLines().indexOf(current);
				/* create a new empty proof line */
				ProofLine emptyLine = createEmptyLine(thisCont, "***");
				emptyLine.setRectHeight(lineBoxHeight);
				emptyLine.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y +
					                           current.getRectArea().height + 2));
				emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y +
											   lineHeight + 2));
				/* add new empty line just below the current line */
				thisCont.addProofLineAt(emptyLine, index + 1);
				thisCont.setBottomDerived(emptyLine);
				/* create new proof line */
				ExprTree RHS;
				if ((chosen1.canArrow()) &&
				   ((((ExprTree)chosen1.getExpr().getLeftChild()).strContents().equals(chosen2.getExpr().strContents())) ||
				   (((ExprTree)chosen1.getExpr().getLeftChild()).commutesWith(chosen2.getExpr()))))
				{
					RHS = (ExprTree)chosen1.getExpr().getRightChild();
				}
				else 
				{
					RHS = (ExprTree)chosen2.getExpr().getRightChild();
				}
				current.assignExpr(RHS);
				current.assignRef(">E("+chosen1.getNum()+","+chosen2.getNum()+")");
				current.setNum("***"); /* temporarily */
			
				/* now check whether the refPos can still stay the same */
				int minRefPos = current.getLinePos().x + fm.stringWidth(current.getNum()) +
								current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
								current.getRefSpace();
			
				if (thisCont.getRefPos() < minRefPos)
				/* if need to move refPos */
				{
					thisCont.setRefPos(minRefPos);
					thisCont.updateLineRecs(pArea);
				}

				current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
					                 - current.getRectArea().x);
				emptyLine.setRectWidth(emptyLine.minimumWidth(fm));

				/* now check if need to increase the width of the context */
				int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
				int availWidth = thisCont.getBox().width;

				if (reqWidth > availWidth)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.extendWidth(reqWidth - availWidth + 15);
					/* re-calculate the available width */
					availWidth = thisCont.getBox().width; 
				}
			
				current.setRuleAppliedTo("ArrowE");

				/* now renumber all the lines in the proof */
				main.reLabel();
				/* update references to reflect new line numbers */
				main.updateReferences();
			
				/* repaint canvas to reflect changes */
				pArea.paintMe(horizOffset, vertOffset);
				appMsg.setText("Rule applied OK.");

				/* record proof is now not saved */
				isSaved = false; 
				saveStatus.setText("Changes Not Saved");

				/* record action for undo purposes */
				UndoObject undo = new UndoObject("ArrowE", false, current, new Vector());
				undoStack.push(undo);
				btnUndo.enable();
				Vector enable = new Vector();
				enable.addElement("Undo");
				menuItems(enable, (Frame)getParent(), true);
			}
			else
			{
				appMsg.setText("Could not apply rule: the two lines do not properly match for");
				appMsg.appendText(" Arrow Elimination!");
			}
		}
		else
		{
			appMsg.setText("Could not apply rule: at least one of the lines ");
			appMsg.appendText("you clicked is not accessible");
		}

	}
	 
	public void notElimBack(ProofLine pl)
	/* applies the not elimination rule backwards from the given proof
	   line */
	{
		if (pl.getExpr().strContents().equals("false"))
		/* must have bottom at the current line */
		{
			/* need to know which proof line to use for the 
			elimination */
			appMsg.setText("Please click the line to use for Not Elimination...");
			/* now need to wait for the proof line to be clicked */
			currRule = "NotE";
			waitForClick();								
		}
		else
		{
			appMsg.setText("Current line must contain 'false' for Not Elimination");
		}
	}

	public void notElimBackChosenLine(ProofLine chosen, 
										ProofLine current)
	/* called when the user has selected which line to apply the
	   not elimination to (besides the current line) */
	{
		/* re-enable buttons / menu items */
		returnFromClicked();
		/* get context of current line */
		ContextTree thisCont = current.getContext();
		/* must check that chosen line is accessible within this
		   context */
		ContextTree contChosen = chosen.getContext();
		if (((thisCont == contChosen) || (contChosen.isParentOf(thisCont)))
			&& (chosen.getRectArea().y < current.getRectArea().y)
			&& (!(chosen.isEmpty())))
		/* if valid context relation and line positions */
		{
			if (chosen.canNot())
			{
				/* check if there is enough height */
				int reqHeight = lineBoxHeight + 4;
				int availHeight = current.getRectArea().y - (thisCont.getBottomDerived().getRectArea().y
								  + thisCont.getBottomDerived().getRectArea().height);
				if (reqHeight > availHeight)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
										   current.getRectArea().y - 1);
				}
				
				/* now create new proof line */
				ExprTree newExpr = (ExprTree)chosen.getExpr().getRightChild();
				ProofLine newGoal = new ProofLine("***", thisCont, true, newExpr);
				newGoal.setRectHeight(lineBoxHeight);
				newGoal.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y -
				                            (newGoal.getRectArea().height + 2)));
				newGoal.setLinePos(new Point(newGoal.getRectArea().x + 2, newGoal.getRectArea().y +
										     lineHeight + 2));

				/* record position of current line */			
				int index = thisCont.getProofLines().indexOf(current);
				/* add new goal before current line */
				thisCont.addProofLineAt(newGoal, index);
				thisCont.setGoal(newGoal);
				newGoal.goalStatus(true);
				current.goalStatus(false);
				/* mark rule has been applied to the current line */
				current.setRuleAppliedTo("NotE");
				current.assignRef("***************"); /* temporarily */
				newGoal.assignRef("***************"); /* temporarily */

				/* now check whether the refPos can still stay the same */
				int minRefPos1 = current.getLinePos().x + fm.stringWidth(current.getNum()) +
					            current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
								current.getRefSpace();
				int minRefPos2 = newGoal.getLinePos().x + fm.stringWidth(newGoal.getNum()) +
					            newGoal.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(newGoal.getExpr().strContents())) +
								newGoal.getRefSpace();
				int minRefPos;
				if (minRefPos1 > minRefPos2)
				{
					minRefPos = minRefPos1;
				}
				else
				{
					minRefPos = minRefPos2;
				}
			
				if (thisCont.getRefPos() < minRefPos)
				/* if need to move refPos */
				{
					thisCont.setRefPos(minRefPos);
					thisCont.updateLineRecs(pArea);
				}

				current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
					                 - current.getRectArea().x);
				newGoal.setRectWidth(newGoal.minimumWidth(fm));
				
				/* now check if need to increase the width of the context */
				int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
				int availWidth = thisCont.getBox().width;

				if (reqWidth > availWidth)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.extendWidth(reqWidth - availWidth + 15);
					/* re-calculate the available width */
					availWidth = thisCont.getBox().width; 
				}
			
				/* now renumber all the lines in the proof */
				main.reLabel();
				/* update references to reflect new line numbers */
				main.updateReferences();
			
				/* assign reference to current line */
				current.assignRef("~E("+chosen.getNum()+","+newGoal.getNum()+")");
				newGoal.assignRef("");
				
				/* repaint canvas to reflect changes */
				pArea.paintMe(horizOffset, vertOffset);
				appMsg.setText("Rule applied OK.");

				/* record proof is now not saved */
				isSaved = false; 
				saveStatus.setText("Changes Not Saved");

				/* record action for undo purposes */
				UndoObject undo = new UndoObject("NotE", true, newGoal, new Vector());
				undoStack.push(undo);
				btnUndo.enable();
				Vector enable = new Vector();
				enable.addElement("Undo");
				menuItems(enable, (Frame)getParent(), true);
			}
			else
			{
				appMsg.setText("The line you have chosen is not applicable for Not Elimination!");
			}
		}
		else
		{
			appMsg.setText("Could not apply rule: the line you clicked is not accessible");
		}
	}

	public void notElimFor(ProofLine pl)
	/* applies the not elimination rule forwards for the given proof
	   line */
	{
		/* need to know which proof lines to use for the 
		   elimination */
		appMsg.setText("Please click the two lines to use for Not Elimination...");
		/* now need to wait for the proof lines to be clicked */
		currRule = "NotE";
		waitForClick();									
	}

	public void notElimForChosenLine(ProofLine chosen1,
				  				     ProofLine chosen2,
									 ProofLine current)
	/* called when the user has selected the two lines to which
	   to apply the not elimination rule (forwards) */
	{
		/* re-enable buttons / menu items */
		returnFromClicked();
		/* get context of current line */
		ContextTree thisCont = current.getContext();
		/* must check that both lines are accessible within this
		   context */
		ContextTree cont1 = chosen1.getContext();
		ContextTree cont2 = chosen2.getContext();
		if (((thisCont == cont1) || (cont1.isParentOf(thisCont)))
			&& ((thisCont == cont2) || (cont2.isParentOf(thisCont)))
			&& (chosen1.getRectArea().y < current.getRectArea().y)
			&& (chosen2.getRectArea().y < current.getRectArea().y)
			&& (!(chosen1.isEmpty())) && (!(chosen2.isEmpty())))
		/* if valid context relation and line positions */
		{
			if (((chosen1.canNot()) &&
			   ((((ExprTree)chosen1.getExpr().getRightChild()).strContents().equals(chosen2.getExpr().strContents())) ||
			   (((ExprTree)chosen1.getExpr().getRightChild()).commutesWith(chosen2.getExpr()))))
			   || 
			   ((chosen2.canNot()) &&
			   ((((ExprTree)chosen2.getExpr().getRightChild()).strContents().equals(chosen1.getExpr().strContents())) ||
			   (((ExprTree)chosen2.getExpr().getRightChild()).commutesWith(chosen1.getExpr())))))
			{
				/* check if there is enough height */
				int reqHeight = lineBoxHeight + 4;
				int availHeight = thisCont.minBelowLine(current) - (current.getRectArea().y
								  + current.getRectArea().height);
				if (reqHeight > availHeight)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
										   current.getRectArea().y + current.getRectArea().height);
				}
				
				current.userDefinedStatus(true);

				/* record position of current line */			
				int index = thisCont.getProofLines().indexOf(current);
				/* create a new empty proof line */
				ProofLine emptyLine = createEmptyLine(thisCont, "***");
				emptyLine.setRectHeight(lineBoxHeight);
				emptyLine.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y +
					                           current.getRectArea().height + 2));
				emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y +
											   lineHeight + 2));
				/* add new empty line just below the current line */
				thisCont.addProofLineAt(emptyLine, index + 1);
				thisCont.setBottomDerived(emptyLine);
				/* create new proof line */
				ExprTreeValue exprValue = new ExprTreeValue("Atom", "false");
				ExprTree newExpr = new ExprTree(exprValue);
				current.assignExpr(newExpr);
				current.assignRef("~E("+chosen1.getNum()+","+chosen2.getNum()+")");
				current.setNum("***"); /* temporarily */
			
				/* now check whether the refPos can still stay the same */
				int minRefPos = current.getLinePos().x + fm.stringWidth(current.getNum()) +
								current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
								current.getRefSpace();
			
				if (thisCont.getRefPos() < minRefPos)
				/* if need to move refPos */
				{
					thisCont.setRefPos(minRefPos);
					thisCont.updateLineRecs(pArea);
				}

				current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
					                 - current.getRectArea().x);
				emptyLine.setRectWidth(emptyLine.minimumWidth(fm));

				/* now check if need to increase the width of the context */
				int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
				int availWidth = thisCont.getBox().width;

				if (reqWidth > availWidth)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.extendWidth(reqWidth - availWidth + 15);
					/* re-calculate the available width */
					availWidth = thisCont.getBox().width; 
				}
			
				/* mark rule has been applied to the current line */
				current.setRuleAppliedTo("NotE");

				/* now renumber all the lines in the proof */
				main.reLabel();
				/* update references to reflect new line numbers */
				main.updateReferences();
			
				/* repaint canvas to reflect changes */
				pArea.paintMe(horizOffset, vertOffset);
				appMsg.setText("Rule applied OK.");

				/* record proof is now not saved */
				isSaved = false; 
				saveStatus.setText("Changes Not Saved");

				/* record action for undo purposes */
				UndoObject undo = new UndoObject("NotE", false, current, new Vector());
				undoStack.push(undo);
				btnUndo.enable();
				Vector enable = new Vector();
				enable.addElement("Undo");
				menuItems(enable, (Frame)getParent(), true);
			}
			else
			{
				appMsg.setText("Could not apply rule: the two lines do not properly match for");
				appMsg.appendText(" Not Elimination!");
			}
		}
		else
		{
			appMsg.setText("Could not apply rule: at least one of the lines ");
			appMsg.appendText("you clicked is not accessible");
		}
	}

	public void arrowIntro(ProofLine pl)
	/* applies the arrow introduction rule to the given proof
	   line */
	{
		ContextTree cont = pl.getContext();	

		ContextTree sub = null;
		/* create new sub-context */
		try
		{
			sub = new ContextTree("ArrowI");
		}

		catch (InvalidContextException e) 
		{ System.out.println(e.getMessage()); }

		cont.addChildTree(sub);
		sub.setParent(cont);
		sub.setApp(this);
				
		/* now check whether the new box has enough space */

		/* we know we will have at least three lines ... */
		int reqHeight = 3 * lineBoxHeight + 4 + 10;
		int availHeight = (pl.getRectArea().y - 5) - (cont.getBottomDerived().getRectArea().y +
			              cont.getBottomDerived().getRectArea().height + 5);
		if (reqHeight > availHeight)
		/* if not enough space - extend context and parents ... */
		{
			cont.extendHeight(reqHeight - availHeight + lineBoxHeight + 2, pl);
			availHeight = (pl.getRectArea().y - 5) - (cont.getBottomDerived().getRectArea().y +
			              cont.getBottomDerived().getRectArea().height + 5);	
		}
		
		/* create the proof lines now */
		ExprTree expr = pl.getExpr();
		ProofLine pl1 = new ProofLine("***", sub, false, (ExprTree)expr.getLeftChild());
		pl1.setRuleAppliedTo("ArrowI");
		sub.addProofLine(pl1);

		ProofLine emptyLine = createEmptyLine(sub, "***");
		sub.addProofLine(emptyLine);
		sub.setBottomDerived(emptyLine);

		ProofLine pl2 = new ProofLine("***", sub, false, (ExprTree)expr.getRightChild());
		pl2.assignRef("***************"); /* temporarily for graphical reasons */
		pl2.goalStatus(true);
		sub.addProofLine(pl2);
		sub.setGoal(pl2);
		
		/* now check if we are wide enough */
		int reqWidth = sub.minWidth(pArea);
		int availWidth = cont.getBox().width - 2 * subDist;
		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */
		{
			cont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = cont.getBox().width - 2 * subDist; 
		}
				
		/* now we know we have enough space to put box */

		/* layout the box and its lines on the proof area : */
		sub.setBoxPos(new Point(cont.getBox().x + subDist, cont.getBottomDerived().getRectArea().y +
			           cont.getBottomDerived().getRectArea().height + 5));
		sub.setBoxWidth(availWidth);
		sub.setBoxHeight(pl.getRectArea().y - sub.getBox().y - 5);
				
		pl1.setRectPos(new Point(sub.getBox().x + 5, sub.getBox().y + 5));
		pl1.setRectHeight(lineBoxHeight);
		pl1.setRectWidth(sub.getBox().width - 10);
		pl1.setLinePos(new Point(pl1.getRectArea().x + 2, pl1.getRectArea().y + lineHeight + 2));

		pl2.setRectPos(new Point(sub.getBox().x + 5, sub.getBox().y + sub.getBox().height - lineBoxHeight - 5));
		pl2.setRectHeight(lineBoxHeight);
		pl2.setRectWidth(sub.getBox().width - 10);
		pl2.setLinePos(new Point(pl2.getRectArea().x + 2, pl2.getRectArea().y + lineHeight + 2));
		
		emptyLine.setRectPos(new Point(pl1.getRectArea().x, pl1.getRectArea().y + lineBoxHeight + 2));
		emptyLine.setRectHeight(lineBoxHeight);
		emptyLine.setRectWidth(sub.getBox().width - 10);
		emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y + lineHeight + 2));
		
		/* update reference position for new context */
		sub.setRefPos(pl2.getRectArea().x + pl2.getRectArea().width - 2
				      - fm.stringWidth(pl2.getRef()));
		
		/* mark that a rule has been applied to this line */
		pl.setRuleAppliedTo("ArrowI");

		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();

		pl2.assignRef("");
		pl.assignRef(">I(" + pl1.getNum() + "," + pl2.getNum() + ")");
		cont.updateLineRecs(pArea);

		appMsg.setText("Rule applied OK.");

		pArea.paintMe(horizOffset, vertOffset);

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		Vector subs = new Vector();
		subs.addElement(sub);
		UndoObject undo = new UndoObject("ArrowI", true, pl,
										 subs);
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);
	}

	public void notIntro(ProofLine pl)
	/* applies the not introduction rule to the given proof
	   line */
	{
		ContextTree cont = pl.getContext();	

		ContextTree sub = null;
		/* create new sub-context */
		try
		{
			sub = new ContextTree("NotI");
		}

		catch (InvalidContextException e) 
		{ System.out.println(e.getMessage()); }

		cont.addChildTree(sub);
		sub.setParent(cont);
		sub.setApp(this);
				
		/* now check whether the new box has enough space */

		/* we know we will have at least three lines ... */
		int reqHeight = 3 * lineBoxHeight + 4 + 10;
		int availHeight = (pl.getRectArea().y - 5) - (cont.getBottomDerived().getRectArea().y +
			              cont.getBottomDerived().getRectArea().height + 5);
		if (reqHeight > availHeight)
		/* if not enough space - extend context and parents ... */
		{
			cont.extendHeight(reqHeight - availHeight + lineBoxHeight + 2, pl);
			availHeight = (pl.getRectArea().y - 5) - (cont.getBottomDerived().getRectArea().y +
			              cont.getBottomDerived().getRectArea().height + 5);	
		}

		/* create the proof lines now */
		ExprTree expr = pl.getExpr();
		ProofLine pl1 = new ProofLine("***", sub, false, (ExprTree)expr.getRightChild());
		pl1.setRuleAppliedTo("NotI");
		sub.addProofLine(pl1);

		ProofLine emptyLine = createEmptyLine(sub, "***");
		sub.addProofLine(emptyLine);
		sub.setBottomDerived(emptyLine);

		ExprTree bottom = new ExprTree(new ExprTreeValue("Atom", "false"));
		ProofLine pl2 = new ProofLine("***", sub, false, bottom);
		pl2.assignRef("***************"); /* temporarily for graphical reasons */
		pl2.goalStatus(true);
		sub.addProofLine(pl2);
		sub.setGoal(pl2);
		
		/* now check if we are wide enough */
		int reqWidth = sub.minWidth(pArea);
		int availWidth = cont.getBox().width - 2 * subDist;
		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */		
		{
			cont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = cont.getBox().width - 2 * subDist; 
		}
		
		/* now we know we have enough space to put box */

		/* layout the box and its lines on the proof area : */
		sub.setBoxPos(new Point(cont.getBox().x + subDist, cont.getBottomDerived().getRectArea().y +
			           cont.getBottomDerived().getRectArea().height + 5));
		sub.setBoxWidth(availWidth);
		sub.setBoxHeight(pl.getRectArea().y - sub.getBox().y - 5);
				
		pl1.setRectPos(new Point(sub.getBox().x + 5, sub.getBox().y + 5));
		pl1.setRectHeight(lineBoxHeight);
		pl1.setRectWidth(sub.getBox().width - 10);
		pl1.setLinePos(new Point(pl1.getRectArea().x + 2, pl1.getRectArea().y + lineHeight + 2));

		pl2.setRectPos(new Point(sub.getBox().x + 5, sub.getBox().y + sub.getBox().height - lineBoxHeight - 5));
		pl2.setRectHeight(lineBoxHeight);
		pl2.setRectWidth(sub.getBox().width - 10);
		pl2.setLinePos(new Point(pl2.getRectArea().x + 2, pl2.getRectArea().y + lineHeight + 2));
		
		emptyLine.setRectPos(new Point(pl1.getRectArea().x, pl1.getRectArea().y + lineBoxHeight + 2));
		emptyLine.setRectHeight(lineBoxHeight);
		emptyLine.setRectWidth(sub.getBox().width - 10);
		emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y + lineHeight + 2));
		
		/* update reference position for new context */
		sub.setRefPos(pl2.getRectArea().x + pl2.getRectArea().width - 2
				      - fm.stringWidth(pl2.getRef()));
		
		/* mark that a rule has been applied to this line */
		pl.setRuleAppliedTo("NotI");

		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();

		pl2.assignRef("");
		pl.assignRef("~I(" + pl1.getNum() + "," + pl2.getNum() + ")");
		cont.updateLineRecs(pArea);

		appMsg.setText("Rule applied OK.");

		pArea.paintMe(horizOffset, vertOffset);

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		Vector subs = new Vector();
		subs.addElement(sub);
		UndoObject undo = new UndoObject("NotI", true, pl,
										 subs);
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);
	}

	public void orElim(ProofLine pl)
	/* applies the or elimination rule forwards from the given
	   proof line */
	{
		/* indicate that now waiting for the user to click the
		   the relevant proof line */
		appMsg.setText("Please click the line to use for Or Elimination...");
		/* now need to wait for the proof line to be clicked */
		currRule = "OrE";
		waitForClick();									
	}

	public void orElimChosenLine(ProofLine chosen, ProofLine current)
	/* called when user has selected the line used for or elimination */
	{
		/* re-enable buttons / menu items */
		returnFromClicked();
		/* get context of current line */
		ContextTree thisCont = current.getContext();
		/* must check that line is accessible within this
		   context */
		ContextTree cont = chosen.getContext();
		if (((thisCont == cont) || (cont.isParentOf(thisCont)))
			&& (chosen.getRectArea().y < current.getRectArea().y)
			&& (!(chosen.isEmpty())))
		/* if valid context relation and line positions */
		{
			if (chosen.canOr())
			/* chosen line must be a disjunction */
			{
				ContextTree sub1 = null;
				ContextTree sub2 = null;
				/* create new sub-contexts */
				try
				{
					sub1 = new ContextTree("OrE");
					sub2 = new ContextTree("OrE");
				} 
				catch (InvalidContextException e) 
				{ System.out.println(e.getMessage()); }

				thisCont.addChildTreeAt(sub1, 0);
				thisCont.addChildTreeAt(sub2, 1);
				sub1.setParent(thisCont);
				sub1.setApp(this);
				sub2.setParent(thisCont);
				sub2.setApp(this);

				/* we know we will have at least three lines ... */
				int reqHeight = 3 * lineBoxHeight + 4 + 10;
				int availHeight = thisCont.minBelowLine(current) -
								  (current.getRectArea().y + current.getRectArea().height) - 10;
				if (reqHeight > availHeight)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
										   current.getRectArea().y + current.getRectArea().height);
					availHeight = thisCont.minBelowLine(current) -
								  (current.getRectArea().y + current.getRectArea().height) - 10;
				}
	
				/* create the proof lines now */
				ExprTree expr = chosen.getExpr();
				ProofLine pl11 = new ProofLine("***", sub1, false, (ExprTree)expr.getLeftChild());
				pl11.assignRef("***************"); /* only temporarily for graphical reasons */
				sub1.addProofLine(pl11);
				ProofLine emptyLine1 = createEmptyLine(sub1, "***");
				sub1.addProofLine(emptyLine1);
				sub1.setBottomDerived(emptyLine1);
				ProofLine pl12 = new ProofLine("***", sub1, false, thisCont.getGoal().getExpr());
				pl12.assignRef("***************"); /* only temporarily for graphical reasons */
				pl12.goalStatus(true);
				sub1.addProofLine(pl12);
				sub1.setGoal(pl12);
		
				ProofLine pl21 = new ProofLine("***", sub2, false, (ExprTree)expr.getRightChild());
				pl21.assignRef("***************"); /* only temporarily for graphical reasons */
				sub2.addProofLine(pl21);
				ProofLine emptyLine2 = createEmptyLine(sub2, "***");
				sub2.addProofLine(emptyLine2);
				sub2.setBottomDerived(emptyLine2);
				ProofLine pl22 = new ProofLine("***", sub2, false, thisCont.getGoal().getExpr());
				pl22.assignRef("***************"); /* only temporarily for graphical reasons */
				pl22.goalStatus(true);
				sub2.addProofLine(pl22);
				sub2.setGoal(pl22);

				/* now check if we are wide enough */
				int widthSub1 = sub1.minWidth(pArea);
				int widthSub2 = sub2.minWidth(pArea);
				int reqWidth = widthSub1 + widthSub2;
				int availWidth = thisCont.getBox().width - 2 * subDist;
				if (reqWidth > availWidth)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.extendWidth(reqWidth - availWidth + 15);
					/* re-calculate the available width */
					availWidth = thisCont.getBox().width - 2 * subDist; 
				}

				/* now we know we have enough space to put boxes */

				/* layout the boxes and lines on the proof area : */
				sub1.setBoxHeight(thisCont.minBelowLine(current) - (current.getRectArea().y +
					              current.getRectArea().height) - 10);
				sub1.setBoxPos(new Point(thisCont.getBox().x + subDist, current.getRectArea().y 
									     + current.getRectArea().height + 5));
				sub1.setBoxWidth(widthSub1 + ((availWidth - reqWidth) / 2));
						
				sub2.setBoxPos(new Point(sub1.getBox().x + sub1.getBox().width,
										 sub1.getBox().y));
				sub2.setBoxWidth(widthSub2 + ((availWidth - reqWidth) / 2));
				sub2.setBoxHeight(sub1.getBox().height);
		
				pl11.setRectPos(new Point(sub1.getBox().x + 5, sub1.getBox().y + 5));
				pl11.setRectHeight(lineBoxHeight);
				pl11.setRectWidth(sub1.getBox().width - 10);
				pl11.setLinePos(new Point(pl11.getRectArea().x + 2, pl11.getRectArea().y + lineHeight + 2));

				emptyLine1.setRectPos(new Point(pl11.getRectArea().x, pl11.getRectArea().y + 
											    pl11.getRectArea().height + 2));
				emptyLine1.setRectHeight(lineBoxHeight);
				emptyLine1.setRectWidth(sub1.getBox().width - 10);
				emptyLine1.setLinePos(new Point(emptyLine1.getRectArea().x + 2, emptyLine1.getRectArea().y + lineHeight + 2));

				pl12.setRectPos(new Point(pl11.getRectArea().x, sub1.getBox().y + sub1.getBox().height - lineBoxHeight - 5));
				pl12.setRectHeight(lineBoxHeight);
				pl12.setRectWidth(sub1.getBox().width - 10);
				pl12.setLinePos(new Point(pl12.getRectArea().x + 2, pl12.getRectArea().y + lineHeight + 2));

				pl21.setRectPos(new Point(sub2.getBox().x + 5, sub2.getBox().y + 5));
				pl21.setRectHeight(lineBoxHeight);
				pl21.setRectWidth(sub2.getBox().width - 10);
				pl21.setLinePos(new Point(pl21.getRectArea().x + 2, pl21.getRectArea().y + lineHeight + 2));
				
				emptyLine2.setRectPos(new Point(pl21.getRectArea().x, pl21.getRectArea().y
					                            + pl21.getRectArea().height + 2));
				emptyLine2.setRectHeight(lineBoxHeight);
				emptyLine2.setRectWidth(sub2.getBox().width - 10);
				emptyLine2.setLinePos(new Point(emptyLine2.getRectArea().x + 2, emptyLine2.getRectArea().y + lineHeight + 2));

				pl22.setRectPos(new Point(pl21.getRectArea().x, sub2.getBox().y + sub2.getBox().height - lineBoxHeight - 5));
				pl22.setRectHeight(lineBoxHeight);
				pl22.setRectWidth(sub2.getBox().width - 10);
				pl22.setLinePos(new Point(pl22.getRectArea().x + 2, pl22.getRectArea().y + lineHeight + 2));
								
				/* update reference position for new contexts */
				sub1.setRefPos(pl11.getRectArea().x + pl11.getRectArea().width
						       - 2 - fm.stringWidth(pl11.getRef()));
				sub2.setRefPos(pl21.getRectArea().x + pl21.getRectArea().width
							   - 2 - fm.stringWidth(pl21.getRef()));

				pl11.assignRef("");
				pl12.assignRef("");
				pl21.assignRef("");
				pl22.assignRef("");

				/* mark that a rule has been applied to these lines */
				pl11.setRuleAppliedTo("OrE");
				pl21.setRuleAppliedTo("OrE");
				thisCont.getGoal().setRuleAppliedTo("OrE");

				/* now renumber all the lines in the proof */
				main.reLabel();
				/* update references to reflect new line numbers */
				main.updateReferences();
		
				thisCont.getGoal().assignRef("OrE("+chosen.getNum()+")");
				thisCont.updateLineRecs(pArea);

				pArea.paintMe(horizOffset, vertOffset);
				appMsg.setText("Rule applied OK.");

				/* record proof is now not saved */
				isSaved = false;
				saveStatus.setText("Changes Not Saved");

				/* record action for undo purposes */
				Vector subs = new Vector();
				subs.addElement(sub1);
				subs.addElement(sub2);
				UndoObject undo = new UndoObject("OrE", false, thisCont.getGoal(),
												 subs);
				undoStack.push(undo);
				btnUndo.enable();
				Vector enable = new Vector();
				enable.addElement("Undo");
				menuItems(enable, (Frame)getParent(), true);
			}
			else
			{
				appMsg.setText("Could not apply rule: the line you have chosen is not applicable for Or Elimination!");
			}
		}
		else
		{
			appMsg.setText("Could not apply rule: the line you have chosen is not accessible");
		}
	}

	public void orIntroBack(ProofLine pl)
	/* applies the or introduction rule backwards from the given
	   proof line */
	{
		/* only need to know if user wants to get LHS or RHS */
		appMsg.setText("Press 'L' to select the left disjunct, or 'R' to select");
		appMsg.appendText(" the right disjunct");
		currRule = "OrI";
		waitForClick();
		clickStatus = 0; /* make sure clicking does nothing */
	}

	public void orIntroBackDone(ProofLine current, int leftOrRight)
	/* called when the user has selected the left or right disjunct 
	   for or introduction (backwards).
	   Pre-condition: leftOrRight must be one of LEFTS, RIGHTS,
	                  LEFTC and RIGHTC */
	{
		/* re-enable buttons / menu items */
		returnFromClicked();

		ContextTree thisCont = current.getContext();

		/* check if there is enough height */
		int reqHeight = lineBoxHeight + 4;
		int availHeight = current.getRectArea().y - (thisCont.getBottomDerived().getRectArea().y
								  + thisCont.getBottomDerived().getRectArea().height);
		if (reqHeight > availHeight)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
								   current.getRectArea().y - 1);
		}
		
		/* now create new proof line */
		ExprTree newExpr;
		if ((leftOrRight == LEFTC) || (leftOrRight == LEFTS))
		/* if left disjunct */
		{
			newExpr = (ExprTree)current.getExpr().getLeftChild();
		}
		else
		{
			newExpr = (ExprTree)current.getExpr().getRightChild();
		}

		ProofLine newGoal = new ProofLine("***", thisCont, true, newExpr);
		newGoal.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y -
		                            (lineBoxHeight + 2)));
		newGoal.setRectHeight(lineBoxHeight);
		newGoal.setLinePos(new Point(newGoal.getRectArea().x + 2, newGoal.getRectArea().y +
										     lineHeight + 2));

		/* record position of current line */			
		int index = thisCont.getProofLines().indexOf(current);
		/* add new goal before current line */
		thisCont.addProofLineAt(newGoal, index);
		thisCont.setGoal(newGoal);
		newGoal.goalStatus(true);
		current.goalStatus(false);
		/* mark rule has been applied to the current line */
		current.setRuleAppliedTo("OrI");
		current.assignRef("***************"); /* temporarily */
		newGoal.assignRef("***************"); /* temporarily */
		/* now check whether the refPos can still stay the same */
		int minRefPos1 = current.getLinePos().x + fm.stringWidth(current.getNum()) +
			            current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
						current.getRefSpace();
		int minRefPos2 = newGoal.getLinePos().x + fm.stringWidth(newGoal.getNum()) +
			            newGoal.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(newGoal.getExpr().strContents())) +
						newGoal.getRefSpace();
		int minRefPos;
		if (minRefPos1 > minRefPos2)
		{
			minRefPos = minRefPos1;
		}
		else
		{
			minRefPos = minRefPos2;
		}
		if (thisCont.getRefPos() < minRefPos)
		/* if need to move refPos */
		{
			thisCont.setRefPos(minRefPos);
			thisCont.updateLineRecs(pArea);
		}

		current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
			                 - current.getRectArea().x);
		newGoal.setRectWidth(newGoal.minimumWidth(fm));
		/* now check if need to increase the width of the context */
		int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
		int availWidth = thisCont.getBox().width;

		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = thisCont.getBox().width; 
		}
			
		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();
			
		/* assign reference to current line */
		current.assignRef("OrI("+newGoal.getNum()+")");
		newGoal.assignRef("");
				
		/* repaint canvas to reflect changes */
		pArea.paintMe(horizOffset, vertOffset);
		appMsg.setText("Rule applied OK.");

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		UndoObject undo = new UndoObject("OrI", true, newGoal, new Vector());
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);
	}

	public void orIntroFor(ProofLine pl)
	/* applies the or introduction rule forwards for the given
	   proof line */
	{
		/* indicate that now waiting for the user to click the
		   the relevant proof line */
		appMsg.setText("Please click the line to use for Or Introduction...");
		/* now need to wait for the proof line to be clicked */
		currRule = "OrI";
		waitForClick();									
	}

	public void orIntroForChosenLine()
	/* called when the user has selected the line to which to apply 
	   the or introduction (forwards) */
	{
		ContextTree thisCont = currLine.getContext();
		ContextTree cont = clicked1.getContext();
		/* check if line is valid */
		if (((thisCont == cont) || (cont.isParentOf(thisCont)))
			&& (clicked1.getRectArea().y < currLine.getRectArea().y)
			&& (!(clicked1.isEmpty())))
		{
			/* here we need to input from the user the right disjunct */
			appMsg.setText("In the text box provided above, enter the new disjunct followed by RETURN.");
			clickStatus = 0; /* make sure clicking on proof area does nothing */
			dataEntryState = 2; /* indicate reading data for "OrI" */
			GlobalTables.initTempLists();
			assump.setText("New Disjunct : ");
			dataEntry.setText("");
			dataEntry.enable();
			topSub.add("South", input);
			validate();
			dataEntry.requestFocus();
		}
		else
		{
			appMsg.setText("Could not apply rule: selected line is not accessible!");
			/* re-enable buttons / menu items */
			returnFromClicked();
		}

	}

	public void orIntroForDone(ProofLine chosen, ProofLine current,
							   String newDisjunct)
	/* called when the user has typed in the new disjunct for or
	   introduction forwards */
	{
		
		/* must syntax analyse the new disjunct */
		ExprTree disjunct = null;
		try
		{
			disjunct = datain.syntaxAnalyse(newDisjunct);
			/* if got to this point - parser succeeded */

			ContextTree thisCont = current.getContext();

			/* cannot use any constants beginning with 'sk' unless they
			   already local to this context */
			for (Enumeration e = GlobalTables.tempConstList().keys(); e.hasMoreElements(); )
			{
				String currConst = (String)e.nextElement();
				if (currConst.startsWith("sk"))
				{
					if (thisCont.searchConstInParents(currConst) == false)
					{
						appMsg.setText("Cannot introduce constants starting with 'sk'!");
						appMsg.appendText("\nPlease re-type...");
						/* re-initialise temporary global tables */
						GlobalTables.initTempLists();
						dataEntry.requestFocus();
						return;
					}
					else
					{
						GlobalTables.tempConstList().remove(currConst);
					}
				}
			}
				
			appMsg.setText("Rule applied OK.");	
			/* tell user which terms/predicates have been introduced */
			showNewConsts();
			showNewVars();
			showNewFuncts();
			showNewPreds();
			/* update the global tables */
			GlobalTables.updateTables();
			topSub.remove(input);
			validate();

			returnFromClicked();
			dataEntryState = 9; /* indicate no input currently read */
			
			/* now need to add new line to context : */
			/* check if there is enough height */
			int reqHeight = lineBoxHeight + 4;
			int availHeight = thisCont.minBelowLine(current) - (current.getRectArea().y
							  + current.getRectArea().height);
			if (reqHeight > availHeight)
			/* if not enough space - extend context and parents ... */
			{
				thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
									   current.getRectArea().y + current.getRectArea().height);
			}
			
			current.userDefinedStatus(true);

			/* record position of current line */			
			int index = thisCont.getProofLines().indexOf(current);
			/* create a new empty proof line */
			ProofLine emptyLine = createEmptyLine(thisCont, "***");
			emptyLine.setRectHeight(lineBoxHeight);
			emptyLine.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y +
				                           current.getRectArea().height + 2));
			emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y +
										   lineHeight + 2));
			/* add new empty line just below the current line */
			thisCont.addProofLineAt(emptyLine, index + 1);
			thisCont.setBottomDerived(emptyLine);
			/* create new proof line */
			ExprTree left = chosen.getExpr();
			ExprTree right = disjunct;
			ExprTreeValue exprValue = new ExprTreeValue("Op2", "|");
			ExprTree newExpr = new ExprTree(exprValue);
			newExpr.setLeftChild(left);
			newExpr.setRightChild(right);
			current.assignExpr(newExpr);
			current.assignRef("OrI("+chosen.getNum()+")");
			current.setNum("***"); /* temporarily */
			
			/* now check whether the refPos can still stay the same */
			int minRefPos = current.getLinePos().x + fm.stringWidth(current.getNum()) +
				            current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
							current.getRefSpace();
			
			if (thisCont.getRefPos() < minRefPos)
			/* if need to move refPos */
			{
				thisCont.setRefPos(minRefPos);
				thisCont.updateLineRecs(pArea);
			}

			current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
				                 - current.getRectArea().x);
			emptyLine.setRectWidth(emptyLine.minimumWidth(fm));

			/* now check if need to increase the width of the context */
			int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
			int availWidth = thisCont.getBox().width;

			if (reqWidth > availWidth)
			/* if not enough space - extend context and parents ... */
			{
				thisCont.extendWidth(reqWidth - availWidth + 15);
				/* re-calculate the available width */
				availWidth = thisCont.getBox().width; 
			}
			
			current.setRuleAppliedTo("OrI");

			/* now renumber all the lines in the proof */
			main.reLabel();
			/* update references to reflect new line numbers */
			main.updateReferences();
			
			/* repaint canvas to reflect changes */
			pArea.paintMe(horizOffset, vertOffset);

			/* record proof is now not saved */
			isSaved = false; 
			saveStatus.setText("Changes Not Saved");

			/* record action for undo purposes */
			UndoObject undo = new UndoObject("OrI", false, current, new Vector());
			undoStack.push(undo);
			btnUndo.enable();
			Vector enable = new Vector();
			enable.addElement("Undo");
			menuItems(enable, (Frame)getParent(), true);
		}
		catch (Exception e)
		/* if an error was encountered in input - re-read new disjunct */
		{
			appMsg.setText("Parsing of your input has failed!\n");
			appMsg.appendText(e.getMessage());
			appMsg.appendText("\nPlease re-type...");
			/* re-initialise temporary global tables */
			GlobalTables.initTempLists();
			dataEntry.requestFocus();
		}
	}

	public void notNot(ProofLine current)
	/* applies the not not rule forwards for the given
	   proof line */
	{
		/* indicate that now waiting for the user to click the
		   the relevant proof line */
		appMsg.setText("Please click the line to use for Not-Not...");
		/* now need to wait for the proof line to be clicked */
		currRule = "NotNot";
		waitForClick();									
	}

	public void notNotChosenLine(ProofLine chosen, ProofLine current)
	/* called when the user has selected the proof line to which to
	   apply the not-not rule (forwards) */
	{
		/* re-enable buttons / menu items */
		returnFromClicked();
	
		/* get context of current line */
		ContextTree thisCont = current.getContext();
		/* must check that chosen line is accessible within this
		   context */
		ContextTree contChosen = chosen.getContext();
		if (((thisCont == contChosen) || (contChosen.isParentOf(thisCont)))
			&& (chosen.getRectArea().y < current.getRectArea().y)
			&& (!(chosen.isEmpty())))
		/* if valid context relation and line positions */
		{
			if ((chosen.canNot()) && 
				(((ExprTreeValue)chosen.getExpr().getRightChild().getValue()).getContents().equals("~")))
			/* check if chosen has a double negation */
			{
				
				/* check if there is enough height */
				int reqHeight = lineBoxHeight + 4;
				int availHeight = thisCont.minBelowLine(current) - (current.getRectArea().y
								  + current.getRectArea().height);
									
				if (reqHeight > availHeight)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
										   current.getRectArea().y + current.getRectArea().height);
				}
				
				current.userDefinedStatus(true);

				/* record position of current line */			
				int index = thisCont.getProofLines().indexOf(current);
				/* create a new empty proof line */
				ProofLine emptyLine = createEmptyLine(thisCont, "***");
				emptyLine.setRectHeight(lineBoxHeight);
				emptyLine.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y +
					                           current.getRectArea().height + 2));
				emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y +
											   lineHeight + 2));
				/* add new empty line just below the current line */
				thisCont.addProofLineAt(emptyLine, index + 1);
				thisCont.setBottomDerived(emptyLine);

				current.assignExpr((ExprTree)chosen.getExpr().getRightChild().getRightChild());
				current.assignRef("~~("+chosen.getNum()+")");
				current.setNum("***"); /* temporarily */

				/* now check whether the refPos can still stay the same */
				int minRefPos = current.getLinePos().x + fm.stringWidth(current.getNum()) +
					            current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
								current.getRefSpace();
			
				if (thisCont.getRefPos() < minRefPos)
				/* if need to move refPos */
				{
					thisCont.setRefPos(minRefPos);
					thisCont.updateLineRecs(pArea);
				}

				current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
					                 - current.getRectArea().x);
				emptyLine.setRectWidth(emptyLine.minimumWidth(fm));

				/* now check if need to increase the width of the context */
				int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
				int availWidth = thisCont.getBox().width;

				if (reqWidth > availWidth)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.extendWidth(reqWidth - availWidth + 15);
					/* re-calculate the available width */
					availWidth = thisCont.getBox().width; 
				}
			
				/* mark rule has been applied to the current line */
				current.setRuleAppliedTo("NotNot");

				/* now renumber all the lines in the proof */
				main.reLabel();
				/* update references to reflect new line numbers */
				main.updateReferences();
			
				/* repaint canvas to reflect changes */
				pArea.paintMe(horizOffset, vertOffset);
				
				appMsg.setText("Rule applied OK.");

				/* record proof is now not saved */
				isSaved = false; 
				saveStatus.setText("Changes Not Saved");

				/* record action for undo purposes */
				UndoObject undo = new UndoObject("NotNot", false, current, new Vector());
				undoStack.push(undo);
				btnUndo.enable();
				Vector enable = new Vector();
				enable.addElement("Undo");
				menuItems(enable, (Frame)getParent(), true);
			}
			else
			{
				appMsg.setText("Could not apply rule: the line you clicked does not have");
				appMsg.appendText(" a double negation!");
			}
		}
		else
		{
			appMsg.setText("Could not apply rule: the line you clicked is not accessible");
		}
	}

	public void iffIntro(ProofLine pl)
	/* applies the if-and-only-if introduction rule (backwards) to
	   the given proof line */
	{
		ContextTree cont = pl.getContext();	

		ContextTree sub1 = null;
		ContextTree sub2 = null;
		/* create new sub-contexts */
		try
		{
			sub1 = new ContextTree("IfAndOnlyIfI");
			sub2 = new ContextTree("IfAndOnlyIfI");
		} 
		catch (InvalidContextException e) 
		{ System.out.println(e.getMessage()); }

		cont.addChildTree(sub1);
		cont.addChildTree(sub2);
		sub1.setParent(cont);
		sub1.setApp(this);
		sub2.setParent(cont);
		sub2.setApp(this);
		
		/* now check whether boxes have enough space */

		/* we know we will have at least two lines ... */
		int reqHeight = 2 * lineBoxHeight + 2 + 10;
		int availHeight = (pl.getRectArea().y - 5) - (cont.getBottomDerived().getRectArea().y +
			              cont.getBottomDerived().getRectArea().height + 5);
		if (reqHeight > availHeight)
		/* if not enough space - extend context and parents ... */
		{
			cont.extendHeight(reqHeight - availHeight + lineBoxHeight + 2, pl);
			availHeight = (pl.getRectArea().y - 5) - (cont.getBottomDerived().getRectArea().y +
			              cont.getBottomDerived().getRectArea().height + 5);	
		}
	
		/* create the proof lines now */
		ExprTree expr = pl.getExpr();
		ExprTreeValue newValue = new ExprTreeValue("Op1", ">");
		ExprTree left = (ExprTree)expr.getLeftChild();
		ExprTree right = (ExprTree)expr.getRightChild();
		ExprTree newExpr1 = new ExprTree(newValue);
		ExprTree newExpr2 = new ExprTree(newValue);
		newExpr1.setLeftChild(left);
		newExpr1.setRightChild(right);
		newExpr2.setLeftChild(right);
		newExpr2.setRightChild(left);
		ProofLine pl1 = new ProofLine("***", sub1, false, newExpr1);
		pl1.assignRef("***************"); /* only temporarily for graphical reasons */
		pl1.goalStatus(true);
		sub1.addProofLine(pl1);
		sub1.setGoal(pl1);
		ProofLine pl2 = new ProofLine("***", sub2, false, newExpr2);
		pl2.assignRef("***************"); /* only temporarily for graphical reasons */
		pl2.goalStatus(true);
		sub2.addProofLine(pl2);
		sub2.setGoal(pl2);
		ProofLine emptyLine1 = createEmptyLine(sub1, "***");
		sub1.addProofLineAt(emptyLine1, 0);
		sub1.setBottomDerived(emptyLine1);
		ProofLine emptyLine2 = createEmptyLine(sub2, "***");
		sub2.addProofLineAt(emptyLine2, 0);
		sub2.setBottomDerived(emptyLine2);

		/* now check if we are wide enough */
		int widthSub1 = sub1.minWidth(pArea);
		int widthSub2 = sub2.minWidth(pArea);
		int reqWidth = widthSub1 + widthSub2;
		int availWidth = cont.getBox().width - 2 * subDist - siblingDist;
		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */
		{
			cont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = cont.getBox().width - 2 * subDist - siblingDist; 
		}

		/* now we know we have enough space to put boxes */

		/* layout the boxes and lines on the proof area : */
		sub1.setBoxPos(new Point(cont.getBox().x + subDist, cont.getBottomDerived().getRectArea().y +
			           cont.getBottomDerived().getRectArea().height + 5));
		sub1.setBoxWidth(widthSub1 + ((availWidth - reqWidth) / 2));
		sub1.setBoxHeight(pl.getRectArea().y - sub1.getBox().y - 5);
		
		sub2.setBoxPos(new Point(sub1.getBox().x + sub1.getBox().width + siblingDist,
								 sub1.getBox().y));
		sub2.setBoxWidth(widthSub2 + ((availWidth - reqWidth) / 2));
		sub2.setBoxHeight(sub1.getBox().height);
		
		pl1.setRectPos(new Point(sub1.getBox().x + 5, sub1.getBox().y + sub1.getBox().height - lineBoxHeight - 5));
		pl1.setRectHeight(lineBoxHeight);
		pl1.setRectWidth(sub1.getBox().width - 10);
		pl1.setLinePos(new Point(pl1.getRectArea().x + 2, pl1.getRectArea().y + lineHeight + 2));

		pl2.setRectPos(new Point(sub2.getBox().x + 5, sub2.getBox().y + sub2.getBox().height - lineBoxHeight - 5));
		pl2.setRectHeight(lineBoxHeight);
		pl2.setRectWidth(sub2.getBox().width - 10);
		pl2.setLinePos(new Point(pl2.getRectArea().x + 2, pl2.getRectArea().y + lineHeight + 2));
		
		emptyLine1.setRectPos(new Point(pl1.getRectArea().x, sub1.getBox().y + 5));
		emptyLine1.setRectHeight(lineBoxHeight);
		emptyLine1.setRectWidth(sub1.getBox().width - 10);
		emptyLine1.setLinePos(new Point(emptyLine1.getRectArea().x + 2, emptyLine1.getRectArea().y + lineHeight + 2));

		emptyLine2.setRectPos(new Point(pl2.getRectArea().x, sub2.getBox().y + 5));
		emptyLine2.setRectHeight(lineBoxHeight);
		emptyLine2.setRectWidth(sub2.getBox().width - 10);
		emptyLine2.setLinePos(new Point(emptyLine2.getRectArea().x + 2, emptyLine2.getRectArea().y + lineHeight + 2));
		
		/* update reference position for new contexts */
		sub1.setRefPos(pl1.getRectArea().x + pl1.getRectArea().width
			           - 2 - fm.stringWidth(pl1.getRef()));
		sub2.setRefPos(pl2.getRectArea().x + pl2.getRectArea().width
					   - 2 - fm.stringWidth(pl2.getRef()));
	
		pl1.assignRef("");
		pl2.assignRef("");

		/* mark that a rule has been applied to this line */
		pl.setRuleAppliedTo("IfAndOnlyIfI");

		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();
		
		pl.assignRef("#I");
		cont.updateLineRecs(pArea);

		pArea.paintMe(horizOffset, vertOffset);
		appMsg.setText("Rule applied OK.");

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		Vector subs = new Vector();
		subs.addElement(sub1);
		subs.addElement(sub2);
		UndoObject undo = new UndoObject("IfAndOnlyIfI", true, pl,
										 subs);
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);
	}

	public void iffElim(ProofLine pl)
	/* applies the if-and-only-if elimination rule (forwards) */
	{
		/* indicate that now waiting for the user to click the
		   the relevant proof line */
		appMsg.setText("Please click the line to use for If-And-Only-If Elimination...");
		/* now need to wait for the proof line to be clicked */
		currRule = "IfAndOnlyIfE";
		waitForClick();									
	}

	public void iffElimChosenLine()
	/* called when the user has chosen the line to which to apply 
	   if-and-only-if elimination */
	{
		/* get context of current line */
		ContextTree thisCont = currLine.getContext();
		/* must check that chosen line is accessible within this
		   context */
		ContextTree contChosen = clicked1.getContext();

		if (((thisCont == contChosen) || (contChosen.isParentOf(thisCont)))
			&& (clicked1.getRectArea().y < currLine.getRectArea().y)
			&& (!(clicked1.isEmpty())))
		/* if valid context relation and line positions */
		{
			if (!(clicked1.canIff()))
			/* chosen line must be an iff statement */
			{
				appMsg.setText("Could not apply rule: selected line is not an iff sentence.");
				/* re-enable buttons / menu items */
				returnFromClicked();
			}
			else 
			{
				/* now ask the user whether to get the left or right subtree
				   of the iff expression */
				appMsg.setText("Line " + clicked1.getNum() + " chosen.\nPress 'L' to ");
				appMsg.appendText(" to deduce the 'only if' (>) implication, or 'R' to deduce the ");
				appMsg.appendText("'if' (<) implication.");
				/* make sure mouse clicking does nothing */
				clickStatus = 0;
			}
		}
		else
		{
			appMsg.setText("Could not apply rule: the line you selected is not accessible");
			/* re-enable buttons / menu items */
			returnFromClicked();
		}
	}

	public void iffElimDone(ProofLine chosen, ProofLine current,
							int leftOrRight)
	/* called when all parameters for iff elimination have been
	   collected.
	   Pre-condition: leftOrRight must be one of LEFTS, RIGHTS,
	                  LEFTC and RIGHTC */
	{
		/* re-enable buttons / menu items */
		returnFromClicked();
	
		/* get context of current line */
		ContextTree thisCont = current.getContext();

		/* check if there is enough height */
		int reqHeight = lineBoxHeight + 4;
		int availHeight = thisCont.minBelowLine(current) - (current.getRectArea().y
			              + current.getRectArea().height);
									
		if (reqHeight > availHeight)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
								   current.getRectArea().y + current.getRectArea().height);
		}
			
		current.userDefinedStatus(true);

		/* record position of current line */			
		int index = thisCont.getProofLines().indexOf(current);
		/* create a new empty proof line */
		ProofLine emptyLine = createEmptyLine(thisCont, "***");
		emptyLine.setRectHeight(lineBoxHeight);
		emptyLine.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y +
			                           current.getRectArea().height + 2));
		emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y +
									   lineHeight + 2));
		/* add new empty line just below the current line */
		thisCont.addProofLineAt(emptyLine, index + 1);
		thisCont.setBottomDerived(emptyLine);
		/* create line for conjunct - content depends on which
		   conjunct the user wanted */
		ExprTree chosenExpr = (ExprTree)chosen.getExpr();
		ExprTree left = (ExprTree)chosenExpr.getLeftChild();
		ExprTree right = (ExprTree)chosenExpr.getRightChild();
		ExprTreeValue newValue = new ExprTreeValue("Op1", ">");
		ExprTree newExpr = new ExprTree(newValue);
		if ((leftOrRight == LEFTC) || (leftOrRight == LEFTS))
		/* if left conjunct */
		{
			newExpr.setLeftChild(left);
			newExpr.setRightChild(right);
		}
		else
		{
			newExpr.setLeftChild(right);
			newExpr.setRightChild(left);
		}
		
		current.assignExpr(newExpr);
		current.assignRef("#E("+chosen.getNum()+")");
		current.setNum("***"); /* temporarily */

		/* now check whether the refPos can still stay the same */
		int minRefPos = current.getLinePos().x + fm.stringWidth(current.getNum()) +
			            current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
						current.getRefSpace();
		
		if (thisCont.getRefPos() < minRefPos)
		/* if need to move refPos */
		{
			thisCont.setRefPos(minRefPos);
			thisCont.updateLineRecs(pArea);
		}

		current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
			                 - current.getRectArea().x);
		emptyLine.setRectWidth(emptyLine.minimumWidth(fm));

		/* now check if need to increase the width of the context */
		int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
		int availWidth = thisCont.getBox().width;

		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = thisCont.getBox().width; 
		}
			
		/* mark rule has been applied to the current line */
		current.setRuleAppliedTo("IfAndOnlyIfE");

		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();
			
		/* repaint canvas to reflect changes */
		pArea.paintMe(horizOffset, vertOffset);
		appMsg.setText("Rule applied OK.");

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		UndoObject undo = new UndoObject("IfAndOnlyIfE", false, current, new Vector());
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);
	}

	public void iffEquivBack(ProofLine pl)
	/* applies the iff equiv rule backwards from the given proof
	   line */
	{
		/* need to know which proof line to use for the rule */
		appMsg.setText("Please click the line to use for this rule (must be an equivalence)...");
		/* now need to wait for the proof line to be clicked */
		currRule = "IfAndOnlyIfEquiv";
		waitForClick();									
	}

	public void iffEquivBackChosenLine()
	/* called when the user has selected which line to apply the
	   iff-equiv rule to (besides the current line) */
	{
		/* get context of current line */
		ContextTree thisCont = currLine.getContext();
		/* must check that chosen line is accessible within this
		   context */
		ContextTree contChosen = clicked1.getContext();

		if (((thisCont == contChosen) || (contChosen.isParentOf(thisCont)))
			&& (clicked1.getRectArea().y < currLine.getRectArea().y)
			&& (!(clicked1.isEmpty())))
		/* if valid context relation and line positions */
		{
			/* check if the LHS/RHS of chosen line is a sub-expression 
			   of the current line */
			if ((clicked1.canIff())
			   && ((currLine.getExpr().subTree((ExprTree)clicked1.getExpr().getLeftChild()))
			   || (currLine.getExpr().subTree((ExprTree)clicked1.getExpr().getRightChild()))))
			{
				if (!(currLine.getExpr().subTree((ExprTree)clicked1.getExpr().getLeftChild())))
				/* if left hand side is not a subtree of the current
				   line, then no need to ask for any more input */
				{
					iffEquivBackDone(clicked1, currLine, RIGHTS);
				}
				else if (!(currLine.getExpr().subTree((ExprTree)clicked1.getExpr().getRightChild())))
				/* similarly for left hand side */
				{
					iffEquivBackDone(clicked1, currLine, LEFTS);
				}
				else
				/* otherwise, need to ask the user */
				{
					appMsg.setText("Line " + clicked1.getNum() + " chosen.\nPress 'L'");
					appMsg.appendText(" to use the equivalence from left to right, or 'R' to ");
					appMsg.appendText("use the equivalence from right to left.");
					/* make sure mouse clicking does nothing */
					clickStatus = 0;
				}
			}
			else if (!(clicked1.canIff()))
			{
				appMsg.setText("Could not apply rule: the line you chose is not an equivalence!");
				/* re-enable buttons / menu items */
				returnFromClicked();
			}
			else
			{	
				appMsg.setText("Could not apply rule: mismatch between the current line and the chosen line!");
				/* re-enable buttons / menu items */
				returnFromClicked();
			}
		}
		else
		{
			appMsg.setText("Could not apply rule: the line you clicked is not accessible");
			/* re-enable buttons / menu items */
			returnFromClicked();
		}
	}

	public void iffEquivBackDone(ProofLine chosen, ProofLine current,
								 int leftOrRight)
	/* called when the user has given all the necessary input for
	   iff Equiv.
	   Pre-condition: leftOrRight must be one of LEFTS, RIGHTS,
	                  LEFTC and RIGHTC */
	{
		/* re-enable buttons / menu items */
		returnFromClicked();
	
		/* get context of current line */
		ContextTree thisCont = current.getContext();

		/* check if there is enough height */
		int reqHeight = lineBoxHeight + 4;
		int availHeight = current.getRectArea().y - (thisCont.getBottomDerived().getRectArea().y
						  + thisCont.getBottomDerived().getRectArea().height);
		if (reqHeight > availHeight)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
								   current.getRectArea().y - 1);
		}
					
		/* now create the new proof line */

		ExprTree newExpr = null;
		try
		{
			newExpr = (ExprTree)current.getExpr().clone();
		}
		catch (CloneNotSupportedException e)
		{
			/* should never happen */
			System.out.println(e.getMessage());
		}

		/* now we have a copy of the current line to do the
		   substitution on */

		ExprTree chosenLeft = (ExprTree)chosen.getExpr().getLeftChild();
		ExprTree chosenRight = (ExprTree)chosen.getExpr().getRightChild();
		if ((leftOrRight == LEFTC) || (leftOrRight == LEFTS))
		/* if applying equivalence from left to right */
		{
			/* do substitution */
			newExpr.replaceSubTree(chosenLeft, chosenRight);
		}
		else
		/* similarly for the other way around */
		{
			newExpr.replaceSubTree(chosenRight, chosenLeft);
		}
			
		ProofLine newGoal = new ProofLine("***", thisCont, true, newExpr);
		newGoal.setRectHeight(lineBoxHeight);
		newGoal.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y -
		                            (newGoal.getRectArea().height + 2)));
		newGoal.setLinePos(new Point(newGoal.getRectArea().x + 2, newGoal.getRectArea().y +
								     lineHeight + 2));

		/* record position of current line */			
		int index = thisCont.getProofLines().indexOf(current);
		/* add new goal before current line */
		thisCont.addProofLineAt(newGoal, index);
		thisCont.setGoal(newGoal);
		newGoal.goalStatus(true);
		current.goalStatus(false);
		/* mark rule has been applied to the current line */
		current.setRuleAppliedTo("IfAndOnlyIfEquiv");
		current.assignRef("***************"); /* temporarily */
		newGoal.assignRef("***************"); /* temporarily */

		/* now check whether the refPos can still stay the same */
		int minRefPos1 = current.getLinePos().x + fm.stringWidth(current.getNum()) +
			             current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
						 current.getRefSpace();
		int minRefPos2 = newGoal.getLinePos().x + fm.stringWidth(newGoal.getNum()) +
			             newGoal.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(newGoal.getExpr().strContents())) +
						 newGoal.getRefSpace();
		int minRefPos;
		if (minRefPos1 > minRefPos2)
		{
			minRefPos = minRefPos1;
		}
		else
		{
			minRefPos = minRefPos2;
		}
			
		if (thisCont.getRefPos() < minRefPos)
		/* if need to move refPos */
		{
			thisCont.setRefPos(minRefPos);
			thisCont.updateLineRecs(pArea);
		}

		current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
			                 - current.getRectArea().x);
		newGoal.setRectWidth(newGoal.minimumWidth(fm));
				
		/* now check if need to increase the width of the context */
		int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
		int availWidth = thisCont.getBox().width;

		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = thisCont.getBox().width; 
		}
			
		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();
			
		/* assign reference to current line */
		current.assignRef("Eqv("+chosen.getNum()+","+newGoal.getNum()+")");
		newGoal.assignRef("");
				
		/* repaint canvas to reflect changes */
		pArea.paintMe(horizOffset, vertOffset);
		appMsg.setText("Rule applied OK.");

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		UndoObject undo = new UndoObject("IfAndOnlyIfEquiv", true, newGoal, new Vector());
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);
	}

	public void iffEquivFor(ProofLine current)
	/* applies the iff equiv rule forwards for the given proof
	   line */
	{
		/* need to know which proof lines to use for the rule */
		appMsg.setText("Please click the two lines to use for this rule...");
		appMsg.appendText("\nNote: the SECOND line you click should be the ");
		appMsg.appendText("equivalence which you wish to use");
		/* now need to wait for the proof lines to be clicked */
		currRule = "IfAndOnlyIfEquiv";
		waitForClick();									
	}

	public void iffEquivForChosenLine()
	/* called when the user has selected the two lines to which
	   to apply the iff equiv rule (forwards) */
	{
		/* get context of current line */
		ContextTree thisCont = currLine.getContext();
		/* must check that both lines are accessible within this
		   context */
		ContextTree cont1 = clicked1.getContext();
		ContextTree cont2 = clicked2.getContext();
		if (((thisCont == cont1) || (cont1.isParentOf(thisCont)))
			&& ((thisCont == cont2) || (cont2.isParentOf(thisCont)))
			&& (clicked1.getRectArea().y < currLine.getRectArea().y)
			&& (clicked2.getRectArea().y < currLine.getRectArea().y)
			&& (!(clicked1.isEmpty())) && (!(clicked2.isEmpty())))
		/* if valid context relation and line positions */
		{
			/* check if the LHS/RHS of the equivalence line is a sub-
			   expression of the other line */
			if ((clicked2.canIff())
			   && ((clicked1.getExpr().subTree((ExprTree)clicked2.getExpr().getLeftChild()))
			   || (clicked1.getExpr().subTree((ExprTree)clicked2.getExpr().getRightChild()))))
			{
				if (!(clicked1.getExpr().subTree((ExprTree)clicked2.getExpr().getLeftChild())))
				/* if left hand side is not a subtree of the other
				   line, then no need to ask for any more input */
				{
					iffEquivForDone(clicked1, clicked2, currLine, RIGHTS);
				}
				else if (!(clicked1.getExpr().subTree((ExprTree)clicked2.getExpr().getRightChild())))
				/* similarly for left hand side */
				{
					iffEquivForDone(clicked1, clicked2, currLine, LEFTS);
				}
				else
				/* otherwise, need to ask the user */
				{
					appMsg.setText("Line " + clicked1.getNum() + " chosen.\nPress 'L'");
					appMsg.appendText(" to use the equivalence from left to right, or 'R' to ");
					appMsg.appendText("use the equivalence from right to left.");
					/* make sure mouse clicking does nothing */
					clickStatus = 0;
				}
			}
			else if (!(clicked2.canIff()))
			{
				appMsg.setText("Could not apply rule: the second line you clicked ");
				appMsg.appendText("is not an equivalence!");
				/* re-enable buttons / menu items */
				returnFromClicked();
			}
			else
			{	
				appMsg.setText("Could not apply rule: mismatch between the two lines!");
				/* re-enable buttons / menu items */
				returnFromClicked();
			}
		}
		else
		{
			appMsg.setText("Could not apply rule: at least one of the lines ");
			appMsg.appendText("you clicked is not accessible");
			/* re-enable buttons / menu items */
			returnFromClicked();
		}
	}

	public void iffEquivForDone(ProofLine chosen1, ProofLine chosen2,
								ProofLine current, int leftOrRight)
	/* called when all the information needed for this rule has been
	   supplied.
	   Pre condition: leftOrRight must be one of LEFTS, RIGHTS,
	                  LEFTC and RIGHTC */
	{
		/* re-enable buttons / menu items */
		returnFromClicked();

		/* get context of current line */
		ContextTree thisCont = current.getContext();

		/* check if there is enough height */
		int reqHeight = lineBoxHeight + 4;
		int availHeight = thisCont.minBelowLine(current) - (current.getRectArea().y
					  + current.getRectArea().height);
		if (reqHeight > availHeight)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
								   current.getRectArea().y + current.getRectArea().height);
		}

		current.userDefinedStatus(true);

		/* record position of current line */			
		int index = thisCont.getProofLines().indexOf(current);
		/* create a new empty proof line */
		ProofLine emptyLine = createEmptyLine(thisCont, "***");
		emptyLine.setRectHeight(lineBoxHeight);
		emptyLine.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y +
			                           current.getRectArea().height + 2));
		emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y +
									   lineHeight + 2));
		/* add new empty line just below the current line */
		thisCont.addProofLineAt(emptyLine, index + 1);
		thisCont.setBottomDerived(emptyLine);
		
		/* now create new proof line */
		ExprTree newExpr = null;
		try
		{
			newExpr = (ExprTree)chosen1.getExpr().clone();
		}
		catch (CloneNotSupportedException e)
		{
			/* should never happen */
			System.out.println(e.getMessage());
		}

		/* now we have a copy of the current line to do the
		   substitution on */

		ExprTree eqvLeft = (ExprTree)chosen2.getExpr().getLeftChild();
		ExprTree eqvRight = (ExprTree)chosen2.getExpr().getRightChild();
		if ((leftOrRight == LEFTC) || (leftOrRight == LEFTS))
		/* if applying equivalence from left to right */
		{
			/* do substitution */
			newExpr.replaceSubTree(eqvLeft, eqvRight);
		}
		else
		/* similarly for the other way around */
		{
			newExpr.replaceSubTree(eqvRight, eqvLeft);
		}

		current.assignExpr(newExpr);
		current.assignRef("Eqv("+chosen1.getNum()+","+chosen2.getNum()+")");
		current.setNum("***"); /* temporarily */
		
		/* now check whether the refPos can still stay the same */
		int minRefPos = current.getLinePos().x + fm.stringWidth(current.getNum()) +
						current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
						current.getRefSpace();
			
		if (thisCont.getRefPos() < minRefPos)
		/* if need to move refPos */
		{
			thisCont.setRefPos(minRefPos);
			thisCont.updateLineRecs(pArea);
		}

		current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
			                 - current.getRectArea().x);
		emptyLine.setRectWidth(emptyLine.minimumWidth(fm));

		/* now check if need to increase the width of the context */
		int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
		int availWidth = thisCont.getBox().width;

		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = thisCont.getBox().width; 
		}
			
		current.setRuleAppliedTo("IfAndOnlyIfEquiv");

		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();
		
		/* repaint canvas to reflect changes */
		pArea.paintMe(horizOffset, vertOffset);
		appMsg.setText("Rule applied OK.");

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		UndoObject undo = new UndoObject("IfAndOnlyIfEquiv", false, current, new Vector());
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);
	}

	public void bottomElimBack(ProofLine current)
	/* applies the bottom elimination rule backwards from the given
	   line */
	{
		ContextTree thisCont = current.getContext();

		/* check if there is enough height */
		int reqHeight = lineBoxHeight + 4;
		int availHeight = current.getRectArea().y - (thisCont.getBottomDerived().getRectArea().y
								  + thisCont.getBottomDerived().getRectArea().height);
		if (reqHeight > availHeight)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
								   current.getRectArea().y - 1);
		}

		/* now create new proof line */
		ExprTreeValue v = new ExprTreeValue("Atom", "false");
		ExprTree newExpr = new ExprTree(v);

		ProofLine newGoal = new ProofLine("***", thisCont, true, newExpr);
		newGoal.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y -
		                            (lineBoxHeight + 2)));
		newGoal.setRectHeight(lineBoxHeight);
		newGoal.setLinePos(new Point(newGoal.getRectArea().x + 2, newGoal.getRectArea().y +
										     lineHeight + 2));

		/* record position of current line */			
		int index = thisCont.getProofLines().indexOf(current);
		/* add new goal before current line */
		thisCont.addProofLineAt(newGoal, index);
		thisCont.setGoal(newGoal);
		newGoal.goalStatus(true);
		current.goalStatus(false);
		/* mark rule has been applied to the current line */
		current.setRuleAppliedTo("BottomE");
		current.assignRef("***************"); /* temporarily */
		newGoal.assignRef("***************"); /* temporarily */
		/* now check whether the refPos can still stay the same */
		int minRefPos1 = current.getLinePos().x + fm.stringWidth(current.getNum()) +
			            current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
						current.getRefSpace();
		int minRefPos2 = newGoal.getLinePos().x + fm.stringWidth(newGoal.getNum()) +
			            newGoal.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(newGoal.getExpr().strContents())) +
						newGoal.getRefSpace();
		int minRefPos;
		if (minRefPos1 > minRefPos2)
		{
			minRefPos = minRefPos1;
		}
		else
		{
			minRefPos = minRefPos2;
		}
		if (thisCont.getRefPos() < minRefPos)
		/* if need to move refPos */
		{
			thisCont.setRefPos(minRefPos);
			thisCont.updateLineRecs(pArea);
		}

		current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
			                 - current.getRectArea().x);
		newGoal.setRectWidth(newGoal.minimumWidth(fm));
		/* now check if need to increase the width of the context */
		int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
		int availWidth = thisCont.getBox().width;

		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = thisCont.getBox().width; 
		}
			
		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();
			
		/* assign reference to current line */
		current.assignRef("botE("+newGoal.getNum()+")");
		newGoal.assignRef("");
				
		/* repaint canvas to reflect changes */
		pArea.paintMe(horizOffset, vertOffset);
		appMsg.setText("Rule applied OK.");

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		UndoObject undo = new UndoObject("BottomE", true, newGoal, new Vector());
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);
	}		

	public void bottomElimFor(ProofLine current)
	/* applies the bottom elimination rule for the given line */
	{
		/* need to know what the user wishes to deduce */
		appMsg.setText("Please click the line containing bottom ('false')...");
		/* now need to wait for the proof line to be clicked */
		currRule = "BottomE";
		waitForClick();									
	}

	public void bottomElimForChosenLine()
	/* called when the user has selected the line to which to apply 
	   the bottom elimination (forwards) */
	{
		ContextTree thisCont = currLine.getContext();
		ContextTree cont = clicked1.getContext();
		/* check if line is valid */
		if (((thisCont == cont) || (cont.isParentOf(thisCont)))
			&& (clicked1.getRectArea().y < currLine.getRectArea().y)
			&& (clicked1.getExpr().strContents().equals("false")))
		{
			/* here we need to input from the user the new sentence */
			appMsg.setText("In the text box provided above, enter the new derived sentence followed by RETURN.");
			clickStatus = 0; /* make sure clicking on proof area does nothing */
			dataEntryState = 2; /* indicate reading data for "BottomE" */
			GlobalTables.initTempLists();
			assump.setText("New Sentence : ");
			dataEntry.setText("");
			dataEntry.enable();
			topSub.add("South", input);
			validate();
			dataEntry.requestFocus();
		}
		else
		{
			if (!(clicked1.getExpr().strContents().equals("false")))
			{
				appMsg.setText("Could not apply rule: selected line does not contain bottom!");
			}
			else
			{
				appMsg.setText("Could not apply rule: selected line is not accessible!");
			}
			/* re-enable buttons / menu items */
			returnFromClicked();
		}
	}

	public void bottomElimForDone(ProofLine chosen, ProofLine current,
							   String newSentence)
	/* called when the user has typed in the new sentence for bottom
	   elimination */
	{
		/* must syntax analyse the new sentence */
		ExprTree sentence = null;
		try
		{
			sentence = datain.syntaxAnalyse(newSentence);
			/* if got to this point - parser succeeded */
		
			ContextTree thisCont = current.getContext();

			/* cannot use any constants beginning with 'sk' unless they
			   already local to this context */
			for (Enumeration e = GlobalTables.tempConstList().keys(); e.hasMoreElements(); )
			{
				String currConst = (String)e.nextElement();
				if (currConst.startsWith("sk"))
				{
					if (thisCont.searchConstInParents(currConst) == false)
					{
						appMsg.setText("Cannot introduce constants starting with 'sk'!");
						appMsg.appendText("\nPlease re-type...");
						/* re-initialise temporary global tables */
						GlobalTables.initTempLists();
						dataEntry.requestFocus();
						return;
					}
					else
					{
						GlobalTables.tempConstList().remove(currConst);
					}
				}
			}

			appMsg.setText("Rule applied OK.");	
			/* tell user which terms/predicates have been introduced */
			showNewConsts();
			showNewVars();
			showNewFuncts();
			showNewPreds();
			/* update the global tables */
			GlobalTables.updateTables();
			topSub.remove(input);
			validate();

			returnFromClicked();
			dataEntryState = 9; /* indicate no input currently read */
			
			/* now need to add new line to context : */
			/* check if there is enough height */
			int reqHeight = lineBoxHeight + 4;
			int availHeight = thisCont.minBelowLine(current) - (current.getRectArea().y
							  + current.getRectArea().height);
			if (reqHeight > availHeight)
			/* if not enough space - extend context and parents ... */
			{
				thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
									   current.getRectArea().y + current.getRectArea().height);
			}
			
			current.userDefinedStatus(true);

			/* record position of current line */			
			int index = thisCont.getProofLines().indexOf(current);
			/* create a new empty proof line */
			ProofLine emptyLine = createEmptyLine(thisCont, "***");
			emptyLine.setRectHeight(lineBoxHeight);
			emptyLine.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y +
				                           current.getRectArea().height + 2));
			emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y +
										   lineHeight + 2));
			/* add new empty line just below the current line */
			thisCont.addProofLineAt(emptyLine, index + 1);
			thisCont.setBottomDerived(emptyLine);
			/* create new proof line */
			current.assignExpr(sentence);
			current.assignRef("botE("+chosen.getNum()+")");
			current.setNum("***"); /* temporarily */
			
			/* now check whether the refPos can still stay the same */
			int minRefPos = current.getLinePos().x + fm.stringWidth(current.getNum()) +
				            current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
							current.getRefSpace();
			
			if (thisCont.getRefPos() < minRefPos)
			/* if need to move refPos */
			{
				thisCont.setRefPos(minRefPos);
				thisCont.updateLineRecs(pArea);
			}

			current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
				                 - current.getRectArea().x);
			emptyLine.setRectWidth(emptyLine.minimumWidth(fm));

			/* now check if need to increase the width of the context */
			int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
			int availWidth = thisCont.getBox().width;

			if (reqWidth > availWidth)
			/* if not enough space - extend context and parents ... */
			{
				thisCont.extendWidth(reqWidth - availWidth + 15);
				/* re-calculate the available width */
				availWidth = thisCont.getBox().width; 
			}
			
			current.setRuleAppliedTo("BottomE");

			/* now renumber all the lines in the proof */
			main.reLabel();
			/* update references to reflect new line numbers */
			main.updateReferences();
			
			/* repaint canvas to reflect changes */
			pArea.paintMe(horizOffset, vertOffset);

			/* record proof is now not saved */
			isSaved = false; 
			saveStatus.setText("Changes Not Saved");

			/* record action for undo purposes */
			UndoObject undo = new UndoObject("BottomE", false, current, new Vector());
			undoStack.push(undo);
			btnUndo.enable();
			Vector enable = new Vector();
			enable.addElement("Undo");
			menuItems(enable, (Frame)getParent(), true);
		}
		catch (Exception e)
		/* if an error was encountered in input - re-read new sentence */
		{
			appMsg.setText("Parsing of your input has failed!\n");
			appMsg.appendText(e.getMessage());
			appMsg.appendText("\nPlease re-type...");
			/* re-initialise temporary global tables */
			GlobalTables.initTempLists();
			dataEntry.requestFocus();
		}
	}
	
	public void addGiven()
	/* adds an assumption to a proof after the construction of the
	   proof has started */
	{
		/* disable menu items / push-buttons */
		waitForClick();
		appMsg.setText("In the text box provided above, enter the new assumption followed by RETURN.");
		clickStatus = 0; /* make sure clicking on proof area does nothing */
		dataEntryState = 3; /* indicate reading data for 'Add Given' */
		currRule = "AddGiven"; /* this is not actually a rule */
		GlobalTables.initTempLists();
		assump.setText("New Sentence : ");
		dataEntry.setText("");
		dataEntry.enable();
		topSub.add("South", input);
		validate();
		dataEntry.requestFocus();
	}

	public void addGivenDone(String newAssump)
	/* called when the user has typed in the new assumption */
	{
		
		/* must syntax analyse the new sentence */
		ExprTree assump = null;
		try
		{
			assump = datain.syntaxAnalyse(newAssump);
			/* if got to this point - parser succeeded */
		
			/* check for any constants beginning with "sk" */
			for (Enumeration e = GlobalTables.tempConstList().keys(); e.hasMoreElements(); )
			{
				String currConst = (String)e.nextElement();
				if (currConst.startsWith("sk"))
				{
					appMsg.setText("Cannot introduce constants starting with 'sk'!");
					appMsg.appendText("\nPlease re-type...");
					/* re-initialise temporary global tables */
					GlobalTables.initTempLists();
					dataEntry.requestFocus();
					return;
				}
			}

			appMsg.setText("Added assumption "+currAssump+".");
			/* tell user which terms/predicates have been introduced */
			showNewConsts();
			showNewVars();
			showNewFuncts();
			showNewPreds();
			/* update the global tables */
			GlobalTables.updateTables();
			topSub.remove(input);
			validate();

			returnFromClicked();
			dataEntryState = 9; /* indicate no input currently read */
			
			/* now need to add new line to context : */
			main.shiftContents(lineBoxHeight + 2,
							   5 + ((currAssump - 2) * (lineBoxHeight + 2))
							   + lineBoxHeight);

			/* find position of new assumption */
			int yPos = 5 + ((currAssump - 1) * (lineBoxHeight + 2));
			int xPos = 5;

			/* create new proof line */
			ProofLine newGiven = new ProofLine("***", main, false, assump);
			newGiven.assignRef("Given");
			newGiven.setRectPos(new Point(xPos, yPos));
			newGiven.setLinePos(new Point(newGiven.getRectArea().x + 2,
										  newGiven.getRectArea().y + lineHeight + 2));
			newGiven.setRectHeight(lineBoxHeight);

			/* add new proof line to main context */
			main.addProofLineAt(newGiven, currAssump - 1);
					
			/* now check whether the refPos can still stay the same */
			int minRefPos = newGiven.getLinePos().x + fm.stringWidth(newGiven.getNum()) +
				            newGiven.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(newGiven.getExpr().strContents())) +
							newGiven.getRefSpace();
			
			if (main.getRefPos() < minRefPos)
			/* if need to move refPos */
			{
				main.setRefPos(minRefPos);
				main.updateLineRecs(pArea);
			}

			newGiven.setRectWidth(main.getRefPos() + fm.stringWidth(newGiven.getRef()) + 2
				                 - newGiven.getRectArea().x);
			
			/* now check if need to increase the width of the context */
			int reqWidth = 5 + main.minWidthLineRecs() + 5;
			int availWidth = main.getBox().width;

			if (reqWidth > availWidth)
			/* if not enough space - extend context and parents ... */
			{
				main.extendWidth(reqWidth - availWidth + 15);
				/* re-calculate the available width */
				availWidth = main.getBox().width; 
			}
			
			/* now renumber all the lines in the proof */
			main.reLabel();
			/* update references to reflect new line numbers */
			main.updateReferences();

			currAssump++; /* be ready for any new assumption */

			/* repaint canvas to reflect changes */
			pArea.paintMe(horizOffset, vertOffset);

			/* record proof is now not saved */
			isSaved = false; 
			saveStatus.setText("Changes Not Saved");
		}
		catch (Exception e)
		/* if an error was encountered in input - re-read new sentence */
		{
			appMsg.setText("Parsing of your input has failed!\n");
			appMsg.appendText(e.getMessage());
			appMsg.appendText("\nPlease re-type...");
			/* re-initialise temporary global tables */
			GlobalTables.initTempLists();
			dataEntry.requestFocus();
		}
	
	}
	
	public void trustMe(ProofLine current)
	/* markes the current line as proved as requested by the user */
	{
		current.assignRef("Trust Me!");
		
		/* now check whether the refPos can still stay the same */
		int minRefPos = current.getLinePos().x + fm.stringWidth(current.getNum()) +
			            current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
						current.getRefSpace();

		ContextTree thisCont = current.getContext();

		if (thisCont.getRefPos() < minRefPos)
		/* if need to move refPos */
		{
			thisCont.setRefPos(minRefPos);
			thisCont.updateLineRecs(pArea);
		}

		/* now check if need to increase the width of the context */
		int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
		int availWidth = thisCont.getBox().width;

		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = thisCont.getBox().width; 
		}
	
		current.setRuleAppliedTo("TrustMe");
		if (current.isCurrentGoal())
		/* should really always be the current goal */
		{
			thisCont.setProved(true);
			thisCont.checkParentProved();
		}

		appMsg.setText("Rule applied OK.");	

		/* re-draw proof area to reflect changes */
		pArea.paintMe(horizOffset, vertOffset);

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* cannot undo trust-me */
		undoStack = new Stack();
		btnUndo.disable();
		Vector disable = new Vector();
		disable.addElement("Undo");
		menuItems(disable, (Frame)getParent(), false);

		if (main.isProved())
		/* if whole proof has been proven */
		{
			appMsg.setText("PROOF  COMPLETE !");
			if (isStandAlone)
			/* can only save as theorem if running stand-alone */
			{
				appMsg.appendText("\n\nYou may now store this as a new thoerem!");
				appMsg.appendText(" (option 'Save As Theorem' in the File menu)");
				/* user may now add a new theorem */
				Vector enable = new Vector();
				enable.addElement("Save As Theorem");
				menuItems(enable, (Frame)getParent(), true);
			}
		}
	}

	public void tick(ProofLine current)
	/* ticks the current line */
	{
		/* need to get from the user the line which matches with 
		   the current line */
		appMsg.setText("Please click the line which matches the current line...");
		/* now need to wait for the proof line to be clicked */
		currRule = "Tick";
		waitForClick();									
	}

	public void tickChosenLine(ProofLine chosen, ProofLine current)
	/* called when the user has selected the line which should match
	   with the current line for 'Tick' to proceed */
	{
		/* re-enable buttons / menu items */
		returnFromClicked();
	
		/* get context of current line */
		ContextTree thisCont = current.getContext();
		/* must check that chosen line is accessible within this
		   context */
		ContextTree contChosen = chosen.getContext();
		if (((thisCont == contChosen) || (contChosen.isParentOf(thisCont)))
			&& (chosen.getRectArea().y < current.getRectArea().y)
			&& (!(chosen.isEmpty())))
		/* if valid context relation and line positions */
		{
			/* check whether the two lines actually match - taking
			   into account commutativity and associativity */
			ExprTree expr1 = current.getExpr();
			ExprTree expr2 = chosen.getExpr();
			if ((expr1.commutesWith(expr2)) ||
			   (expr1.strContents().equals(expr2.strContents())))
			/* if the two proof lines are actually the same */
			{
				current.assignRef("Ok("+chosen.getNum()+")");
				/* now check whether the refPos can still stay the same */
				int minRefPos = current.getLinePos().x + fm.stringWidth(current.getNum()) +
						        current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
								current.getRefSpace();

				if (thisCont.getRefPos() < minRefPos)
				/* if need to move refPos */
				{
					thisCont.setRefPos(minRefPos);
					thisCont.updateLineRecs(pArea);
				}

				current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
							         - current.getRectArea().x);

				/* now check if need to increase the width of the context */
				int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
				int availWidth = thisCont.getBox().width;

				if (reqWidth > availWidth)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.extendWidth(reqWidth - availWidth + 15);
					/* re-calculate the available width */
					availWidth = thisCont.getBox().width; 
				}
	
				current.setRuleAppliedTo("Tick");

				if (current.isCurrentGoal())
				{
					/* may not need the 'chosen' line */
					if (contChosen == thisCont)
					{
						int chosenIndex = thisCont.getProofLines().indexOf(chosen);
						int bottomIndex = thisCont.getProofLines().indexOf(current);
						if ((chosenIndex + 2 == bottomIndex) && (!(chosen.getRef().equals("Given")))
						   && (chosen.isUserDefined()) && (!(chosen.isTheoremInst())))
						/* there's always an empty line between them */
						{
							/* no actual need for the chosen line */
							current.assignRef(chosen.getRef());
							thisCont.removeProofLine(chosen);
							/* renumber all the lines in the proof */
							main.reLabel();
							/* update references to reflect new line numbers */
							main.updateReferences();
						}
					}

					thisCont.setProved(true);
					thisCont.checkParentProved();
				}

				appMsg.setText("Rule applied OK.");	

				/* re-draw proof area to reflect changes */
				pArea.paintMe(horizOffset, vertOffset);

				/* record proof is now not saved */
				isSaved = false; 
				saveStatus.setText("Changes Not Saved");

				/* cannot undo tick */
				undoStack = new Stack();
				btnUndo.disable();
				Vector disable = new Vector();
				disable.addElement("Undo");
				menuItems(disable, (Frame)getParent(), false);

				if (main.isProved())
				/* if whole proof has been proven */
				{
					appMsg.setText("PROOF  COMPLETE !");
					if (isStandAlone)
					/* can only save as theorem if running stand-alone */
					{
						appMsg.appendText("\n\nYou may now store this as a new thoerem!");
						appMsg.appendText(" (option 'Save As Theorem' in the File menu)");
						/* user may now add a new theorem */
						Vector enable = new Vector();
						enable.addElement("Save As Theorem");
						menuItems(enable, (Frame)getParent(), true);
					}
				}
			}
			else
			{
				appMsg.setText("Could not apply rule: the two lines do not match!");
			}	
		}
		else
		{
			appMsg.setText("Could not apply rule: selected line is not accessible!");
		}

	}

	public void forAllIntro(ProofLine pl)
	/* applies the for-all introduction rule backwards from the current
	   line */
	{
		ContextTree cont = pl.getContext();	

		ContextTree sub = null;
		/* create new sub-context */
		try
		{
			sub = new ContextTree("ForAllI");
		}

		catch (InvalidContextException e) 
		{ System.out.println(e.getMessage()); }

		cont.addChildTree(sub);
		sub.setParent(cont);
		sub.setApp(this);

		/* add new local constant */
		String theConst = "sk" + currSkolem;
		sub.addConstants(theConst);
		if (currSkolem == Long.MAX_VALUE)
		{
			currSkolem = 1;
		}
		else
		{
			currSkolem++;
		}
				
		/* now check whether the new box has enough space */

		/* we know we will have at least three lines ... */
		int reqHeight = 3 * lineBoxHeight + 4 + 10;
		int availHeight = (pl.getRectArea().y - 5) - (cont.getBottomDerived().getRectArea().y +
			              cont.getBottomDerived().getRectArea().height + 5);
		if (reqHeight > availHeight)
		/* if not enough height - extend context and parents ... */
		{
			cont.extendHeight(reqHeight - availHeight + lineBoxHeight + 2, pl);
			availHeight = (pl.getRectArea().y - 5) - (cont.getBottomDerived().getRectArea().y +
			              cont.getBottomDerived().getRectArea().height + 5);	
		}
	
		/* create the proof lines now */

		ExprTreeValue v = new ExprTreeValue("Atom", theConst+" (UnvI)");
		ExprTree newConstExpr = new ExprTree(v);
		ProofLine newConst = new ProofLine("***", sub, false, newConstExpr);
		newConst.setLocalDecl(true);
		sub.addProofLine(newConst);
		
		ProofLine emptyLine = createEmptyLine(sub, "***");
		sub.addProofLine(emptyLine);
		sub.setBottomDerived(emptyLine);

		/* get the variable to be replaced */
		String var = ((ExprTreeValue)pl.getExpr().getValue()).getqContents();
		/* get the quantified sub-expression */
		ExprTree theExp = null;
		try
		{
			theExp = (ExprTree)pl.getExpr().getRightChild().clone();
		}
		catch (CloneNotSupportedException e)
		{
			/* should never happen */
			System.out.println(e.getMessage());								
		}
			
		/* now perform the actual substitution */
		theExp.substituteVar(var, theConst);

		ProofLine goalLine = new ProofLine("***", sub, false, theExp);
		goalLine.assignRef("***************"); /* temporarily for graphical reasons */
		goalLine.goalStatus(true);
		sub.addProofLine(goalLine);
		sub.setGoal(goalLine);
				
		/* now check if we are wide enough */
		int reqWidth = sub.minWidth(pArea);
		int availWidth = cont.getBox().width - 2 * subDist;
		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */		
		{
			cont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = cont.getBox().width - 2 * subDist; 
		}
		
		/* now we know we have enough space to put box */

		/* layout the box and its lines on the proof area : */
		sub.setBoxPos(new Point(cont.getBox().x + subDist, cont.getBottomDerived().getRectArea().y +
			           cont.getBottomDerived().getRectArea().height + 5));
		sub.setBoxWidth(availWidth);
		sub.setBoxHeight(pl.getRectArea().y - sub.getBox().y - 5);
				
		newConst.setRectPos(new Point(sub.getBox().x + 5, sub.getBox().y + 5));
		newConst.setRectHeight(lineBoxHeight);
		newConst.setRectWidth(sub.getBox().width - 10);
		newConst.setLinePos(new Point(newConst.getRectArea().x + 2, newConst.getRectArea().y + lineHeight + 2));
		
		emptyLine.setRectPos(new Point(newConst.getRectArea().x, newConst.getRectArea().y + lineBoxHeight + 2));
		emptyLine.setRectHeight(lineBoxHeight);
		emptyLine.setRectWidth(sub.getBox().width - 10);
		emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y + lineHeight + 2));

		goalLine.setRectPos(new Point(sub.getBox().x + 5, sub.getBox().y + sub.getBox().height - lineBoxHeight - 5));
		goalLine.setRectHeight(lineBoxHeight);
		goalLine.setRectWidth(sub.getBox().width - 10);
		goalLine.setLinePos(new Point(goalLine.getRectArea().x + 2, goalLine.getRectArea().y + lineHeight + 2));

		/* update reference position for new context */
		sub.setRefPos(goalLine.getRectArea().x + goalLine.getRectArea().width - 2
				      - fm.stringWidth(goalLine.getRef()));
		
		/* make necessary changes to the current proof line */
		pl.setRuleAppliedTo("ForAllI");

		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();

		goalLine.assignRef("");
		pl.assignRef("UnvI(" + newConst.getNum() + "," + goalLine.getNum() + ")");
		cont.updateLineRecs(pArea);

		appMsg.setText("Rule applied OK.");
		pArea.paintMe(horizOffset, vertOffset);

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		Vector subs = new Vector();
		subs.addElement(sub);
		UndoObject undo = new UndoObject("ForAllI", true, pl,
										 subs);
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);
	}

	public void forAllElim(ProofLine current)
	/* applies the for-all elimination rule forwards for the given
	   line */
	{
		/* need to know what the user wishes to deduce */
		appMsg.setText("Please click the line containing the universal quantifier...");
		/* now need to wait for the proof line to be clicked */
		currRule = "ForAllE";
		waitForClick();									
	}

	public void forAllElimChosenLine()
	/* called when the user has selected the line to which the apply
	   the for-all elimination rule */
	{
		ContextTree thisCont = currLine.getContext();
		ContextTree cont = clicked1.getContext();
		/* check if line is valid */
		if (((thisCont == cont) || (cont.isParentOf(thisCont)))
			&& (clicked1.getRectArea().y < currLine.getRectArea().y)
			&& (clicked1.canForAll()))
		{
			/* here we need to input from the user the right disjunct */
			appMsg.setText("Line "+clicked1.getNum()+" chosen.\n");
			appMsg.appendText("In the text box provided above, enter the term to apply the rule to.");
			clickStatus = 0; /* make sure clicking on proof area does nothing */
			dataEntryState = 4; /* indicate reading data for "ForAllE" */
			GlobalTables.initTempLists();
			assump.setText("Term : ");
			dataEntry.setText("");
			dataEntry.enable();
			topSub.add("South", input);
			validate();
			dataEntry.requestFocus();
		}
		else
		{
			if (!(clicked1.canForAll()))
			{
				appMsg.setText("Could not apply rule: selected line is not universal!");
			}
			else
			{
				appMsg.setText("Could not apply rule: selected line is not accessible!");
			}
			/* re-enable buttons / menu items */
			returnFromClicked();
		}
	}

	public void forAllElimDone(ProofLine chosen, ProofLine current,
							   String term)
	/* called when the user has chosen the term to which to apply
	   the for-all elimination rule */
	{
		/* must syntax analyse the term */
		ExprTree termExpr = null;
		try
		{
			/* attach predicate to the term so could use parser
			   to analyse it as an atom */
			GlobalTables.appendToPredTable("aSpecialPredForThisPurpose", new Integer(1));
			term = "aSpecialPredForThisPurpose("+term+")";
						
			termExpr = datain.syntaxAnalyse(term);
			/* if got to this point - parser succeeded */

			GlobalTables.predTable().remove("aSpecialPredForThisPurpose");

			ContextTree thisCont = current.getContext();
			Hashtable functions = GlobalTables.tempFunctList();
			if (functions.isEmpty())
			/* no functions may be introduced */
			{
				Hashtable constants = GlobalTables.tempConstList();
				if (!(constants.isEmpty()))
				/* if any constant to be introduced - must be local */
				{
					for (Enumeration e = constants.keys(); e.hasMoreElements(); )
					{
						String constant = (String)e.nextElement();
						boolean b = thisCont.searchConstInParents(constant);
						if (b == false)
						{
							appMsg.setText("You cannot introduce new constants!");
							appMsg.appendText("\nPlease re-type....");
							/* re-initialise temporary global tables */
							GlobalTables.initTempLists();
							dataEntry.requestFocus();
							/* exit immediately */
							return;
						}
					}
				}
				/* if got to this point, input is ok */
				int index = term.indexOf("(");
				/* get back to the actual term */
				term = term.substring(index + 1, term.length() - 1);

				appMsg.setText("Input "+term+" OK.\n");

				/* update user interface */
				topSub.remove(input);
				validate();

				/* re-enable menu items / push-buttons */
				returnFromClicked();
				dataEntryState = 9; /* indicate no input currently read */
								
				/* now check if there is enough height */
				int reqHeight = lineBoxHeight + 4;
				int availHeight = thisCont.minBelowLine(current) - (current.getRectArea().y
								  + current.getRectArea().height);
									
				if (reqHeight > availHeight)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
										   current.getRectArea().y + current.getRectArea().height);
				}
				
				current.userDefinedStatus(true);

				/* record position of current line */			
				index = thisCont.getProofLines().indexOf(current);
				/* create a new empty proof line */
				ProofLine emptyLine = createEmptyLine(thisCont, "***");
				emptyLine.setRectHeight(lineBoxHeight);
				emptyLine.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y +
					                           current.getRectArea().height + 2));
				emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y +
											   lineHeight + 2));
				/* add new empty line just below the current line */
				thisCont.addProofLineAt(emptyLine, index + 1);
				thisCont.setBottomDerived(emptyLine);

				/* get the variable to be replaced */
				String var = ((ExprTreeValue)chosen.getExpr().getValue()).getqContents();
				/* get the quantified sub-expression */
				ExprTree theExp = null;
				try
				{
					theExp = (ExprTree)chosen.getExpr().getRightChild().clone();
				}
				catch (CloneNotSupportedException e)
				{
					/* should never happen */
					System.out.println(e.getMessage());
				}

				/* now perform the actual substitution */
				theExp.substituteVar(var, term);

				/* make necessary changes to the current proof line */
				current.assignExpr(theExp);
				current.assignRef("UnvE("+chosen.getNum()+")");
				current.setNum("***"); /* temporarily */

				/* now check whether the refPos can still stay the same */
				int minRefPos = current.getLinePos().x + fm.stringWidth(current.getNum()) +
					            current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
								current.getRefSpace();
			
				if (thisCont.getRefPos() < minRefPos)
				/* if need to move refPos */
				{
					thisCont.setRefPos(minRefPos);
					thisCont.updateLineRecs(pArea);
				}

				current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
					                 - current.getRectArea().x);
				emptyLine.setRectWidth(emptyLine.minimumWidth(fm));

				/* now check if need to increase the width of the context */
				int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
				int availWidth = thisCont.getBox().width;

				if (reqWidth > availWidth)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.extendWidth(reqWidth - availWidth + 15);
					/* re-calculate the available width */
					availWidth = thisCont.getBox().width; 
				}
			
				/* mark rule has been applied to the current line */
				current.setRuleAppliedTo("ForAllE");

				/* now renumber all the lines in the proof */
				main.reLabel();
				/* update references to reflect new line numbers */
				main.updateReferences();
			
				/* repaint canvas to reflect changes */
				pArea.paintMe(horizOffset, vertOffset);
				
				appMsg.appendText("Rule applied OK.");

				/* record proof is now not saved */
				isSaved = false; 
				saveStatus.setText("Changes Not Saved");

				/* record action for undo purposes */
				UndoObject undo = new UndoObject("ForAllE", false, current, new Vector());
				undoStack.push(undo);
				btnUndo.enable();
				Vector enable = new Vector();
				enable.addElement("Undo");
				menuItems(enable, (Frame)getParent(), true);
			}
			else
			{
				appMsg.setText("You cannot introduce new function symbols!\n");
				appMsg.appendText("Please re-type...");
				/* re-initialise temporary global tables */
				GlobalTables.initTempLists();
				dataEntry.requestFocus();
			}	
		}
		catch (LexAnalyserException e)
		/* lexical analyser error */
		{
			appMsg.setText(e.getMessage());
			appMsg.appendText("\nPlease re-type...");
			/* re-initialise temporary global tables */
			GlobalTables.initTempLists();
			dataEntry.requestFocus();
		}
		catch (ParserException e)
		/* parser error */
		{
			appMsg.setText("An error was detected in your input!\n");
			appMsg.appendText("Remember, you should input a term.\n");
			appMsg.appendText("Please re-type...");
			/* re-initialise temporary global tables */
			GlobalTables.initTempLists();
			dataEntry.requestFocus();
		}
		catch (IOException e)
		/* any I/O error */
		{
			appMsg.appendText(e.getMessage());
			appMsg.appendText("\nPlease re-type...");
			/* re-initialise temporary global tables */
			GlobalTables.initTempLists();
			dataEntry.requestFocus();
		}
	}

	public void thereExistsIntro(ProofLine current)
	/* applies the there-exists introduction rule backwards from the
	   given line */
	{
		appMsg.setText("In the text box provided above, enter the term to apply the rule to.");
		waitForClick();	/* disable menu items / push-buttons */								
		clickStatus = 0; /* make sure clicking on proof area does nothing */
		dataEntryState = 4; /* indicate reading data for "ThereExistsI" */
		currRule = "ThereExistsI"; /* record current rule is there-exists-I */
		GlobalTables.initTempLists();
		assump.setText("Term : ");
		dataEntry.setText("");
		dataEntry.enable();
		topSub.add("South", input);
		validate();
		dataEntry.requestFocus();
	}

	public void thereExistsIntroDone(ProofLine current,
									 String term)
	/* called when the user has chosen the term to which to apply
	   the there-exists introduction rule */
	{
		/* must syntax analyse the term */
		ExprTree termExpr = null;
		try
		{
			/* attach predicate to the term so could use parser
			   to analyse it as an atom */
			GlobalTables.appendToPredTable("aSpecialPredForThisPurpose", new Integer(1));
			term = "aSpecialPredForThisPurpose("+term+")";
						
			termExpr = datain.syntaxAnalyse(term);
			/* if got to this point - parser succeeded */

			GlobalTables.predTable().remove("aSpecialPredForThisPurpose");

			ContextTree thisCont = current.getContext();
			Hashtable functions = GlobalTables.tempFunctList();
			if (functions.isEmpty())
			/* no functions may be introduced */
			{
				Hashtable constants = GlobalTables.tempConstList();
				if (!(constants.isEmpty()))
				/* if any constant to be introduced - must be local */
				{
					for (Enumeration e = constants.keys(); e.hasMoreElements(); )
					{
						String constant = (String)e.nextElement();
						boolean b = thisCont.searchConstInParents(constant);
						if (b == false)
						{
							appMsg.setText("You cannot introduce new constants!");
							appMsg.appendText("\nPlease re-type....");
							/* re-initialise temporary global tables */
							GlobalTables.initTempLists();
							dataEntry.requestFocus();
							/* exit immediately */
							return;
						}
					}
				}
				/* if got to this point, input is ok */
				int index = term.indexOf("(");
				/* get back to the actual term */
				term = term.substring(index + 1, term.length() - 1);

				appMsg.setText("Input "+term+" OK.\n");

				/* update user interface */
				topSub.remove(input);
				validate();

				/* re-enable menu items / push-buttons */
				returnFromClicked();
				dataEntryState = 9; /* indicate no input currently read */
								
				/* now check if there is enough height */
				int reqHeight = lineBoxHeight + 4;
				int availHeight = current.getRectArea().y - (thisCont.getBottomDerived().getRectArea().y
								  + thisCont.getBottomDerived().getRectArea().height);

				if (reqHeight > availHeight)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
										   current.getRectArea().y - 1);
				}
				
				/* get the variable to be replaced */
				String var = ((ExprTreeValue)current.getExpr().getValue()).getqContents();
				
				/* get the quantified sub-expression */
				ExprTree theExp = null;
				try
				{
					theExp = (ExprTree)current.getExpr().getRightChild().clone();
				}
				catch (CloneNotSupportedException e)
				{
					/* should never happen */
					System.out.println(e.getMessage());
				}

				/* now perform the actual substitution */
				theExp.substituteVar(var, term);

				ProofLine newGoal = new ProofLine("***", thisCont, true, theExp);
				newGoal.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y -
											(lineBoxHeight + 2)));
				newGoal.setRectHeight(lineBoxHeight);
				newGoal.setLinePos(new Point(newGoal.getRectArea().x + 2, newGoal.getRectArea().y +
											 lineHeight + 2));

				/* record position of current line */			
				int pos = thisCont.getProofLines().indexOf(current);
				/* add new goal before current line */
				thisCont.addProofLineAt(newGoal, pos);
				thisCont.setGoal(newGoal);
				newGoal.goalStatus(true);
				current.goalStatus(false);
				/* mark rule has been applied to the current line */
				current.setRuleAppliedTo("ThereExistsI");
				current.assignRef("***************"); /* temporarily */
				newGoal.assignRef("***************"); /* temporarily */
				/* now check whether the refPos can still stay the same */
				int minRefPos1 = current.getLinePos().x + fm.stringWidth(current.getNum()) +
						         current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
								 current.getRefSpace();
				int minRefPos2 = newGoal.getLinePos().x + fm.stringWidth(newGoal.getNum()) +
								 newGoal.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(newGoal.getExpr().strContents())) +
								 newGoal.getRefSpace();
				int minRefPos;
				if (minRefPos1 > minRefPos2)
				{
					minRefPos = minRefPos1;
				}
				else
				{
					minRefPos = minRefPos2;
				}
				if (thisCont.getRefPos() < minRefPos)
				/* if need to move refPos */
				{
					thisCont.setRefPos(minRefPos);
					thisCont.updateLineRecs(pArea);
				}

				current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
						             - current.getRectArea().x);
				newGoal.setRectWidth(newGoal.minimumWidth(fm));

				/* now check if need to increase the width of the context */
				int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
				int availWidth = thisCont.getBox().width;

				if (reqWidth > availWidth)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.extendWidth(reqWidth - availWidth + 15);
					/* re-calculate the available width */
					availWidth = thisCont.getBox().width; 
				}
							
				/* now renumber all the lines in the proof */
				main.reLabel();
				/* update references to reflect new line numbers */
				main.updateReferences();
			
				/* assign reference to current line */
				current.assignRef("ExstI("+newGoal.getNum()+")");
				newGoal.assignRef("");
				
				/* repaint canvas to reflect changes */
				pArea.paintMe(horizOffset, vertOffset);
				appMsg.setText("Rule applied OK.");

				/* record proof is now not saved */
				isSaved = false; 
				saveStatus.setText("Changes Not Saved");

				/* record action for undo purposes */
				UndoObject undo = new UndoObject("ThereExistsI", true, newGoal, new Vector());
				undoStack.push(undo);
				btnUndo.enable();
				Vector enable = new Vector();
				enable.addElement("Undo");
				menuItems(enable, (Frame)getParent(), true);
			}
			else
			{
				appMsg.setText("You cannot introduce new function symbols!\n");
				appMsg.appendText("Please re-type...");
				/* re-initialise temporary global tables */
				GlobalTables.initTempLists();
				dataEntry.requestFocus();
			}	
		}
		catch (LexAnalyserException e)
		/* lexical analyser error */
		{
			appMsg.setText(e.getMessage());
			appMsg.appendText("\nPlease re-type...");
			/* re-initialise temporary global tables */
			GlobalTables.initTempLists();
			dataEntry.requestFocus();
		}
		catch (ParserException e)
		/* parser error */
		{
			appMsg.setText("An error was detected in your input!\n");
			appMsg.appendText("Remember, you should input a term.\n");
			appMsg.appendText("Please re-type...");
			/* re-initialise temporary global tables */
			GlobalTables.initTempLists();
			dataEntry.requestFocus();
		}
		catch (IOException e)
		/* any I/O error */
		{
			appMsg.appendText(e.getMessage());
			appMsg.appendText("\nPlease re-type...");
			/* re-initialise temporary global tables */
			GlobalTables.initTempLists();
			dataEntry.requestFocus();
		}

	}

	public void thereExistsElim(ProofLine pl)
	/* applies the there-exists elimination rule forwards from the given
	   proof line */
	{
		/* indicate that now waiting for the user to click the
		   the relevant proof line */
		appMsg.setText("Please click the line to use for Existential Elimination...");
		/* now need to wait for the proof line to be clicked */
		currRule = "ThereExistsE";
		waitForClick();									
	}

	public void thereExistsElimChosenLine(ProofLine chosen, ProofLine current)
	/* called when user has selected the line used for existential 
	   elimination */
	{
		/* re-enable buttons / menu items */
		returnFromClicked();
		/* get context of current line */
		ContextTree thisCont = current.getContext();
		/* must check that line is accessible within this
		   context */
		ContextTree cont = chosen.getContext();
		if (((thisCont == cont) || (cont.isParentOf(thisCont)))
			&& (chosen.getRectArea().y < current.getRectArea().y)
			&& (!(chosen.isEmpty())))
		/* if valid context relation and line positions */
		{
			if (chosen.canExists())
			/* chosen line must be an existential sentence */
			{
				ContextTree sub = null;
				/* create new sub-contexts */
				try
				{
					sub = new ContextTree("ExistE");
				} 
				catch (InvalidContextException e) 
				{ System.out.println(e.getMessage()); }

				thisCont.addChildTreeAt(sub, 0);
				sub.setParent(thisCont);
				sub.setApp(this);
	
				/* we know we will have at least four lines ... */
				int reqHeight = 4 * lineBoxHeight + 6 + 10;
				int availHeight = thisCont.minBelowLine(current) -
								  (current.getRectArea().y + current.getRectArea().height) - 10;
				if (reqHeight > availHeight)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
										   current.getRectArea().y + current.getRectArea().height);
					availHeight = thisCont.minBelowLine(current) -
								  (current.getRectArea().y + current.getRectArea().height) - 10;
				}
					
				/* add new local constant */
				String theConst = "sk" + currSkolem;
				sub.addConstants(theConst);
				if (currSkolem == Long.MAX_VALUE)
				{	
					currSkolem = 1;
				}
				else
				{
					currSkolem++;
				}

				ExprTreeValue v = new ExprTreeValue("Atom", theConst+" (ExistE)");
				ExprTree newConstExpr = new ExprTree(v);
				ProofLine newConst = new ProofLine("***", sub, false, newConstExpr);
				newConst.setLocalDecl(true);
				sub.addProofLine(newConst);

				/* get the variable to be replaced */
				String var = ((ExprTreeValue)chosen.getExpr().getValue()).getqContents();
				/* get the quantified sub-expression */
				ExprTree theExp = null;
				try
				{
					theExp = (ExprTree)chosen.getExpr().getRightChild().clone();
				}
				catch (CloneNotSupportedException e)
				{
					/* should never happen */
					System.out.println(e.getMessage());								
				}
			
				/* now perform the actual substitution */
				theExp.substituteVar(var, theConst);

				ProofLine newExpLine = new ProofLine("***", sub, false, theExp);
				newExpLine.assignRef("***************"); /* temporarily for graphical reasons */
				sub.addProofLine(newExpLine);
				
				ProofLine emptyLine = createEmptyLine(sub, "***");
				sub.addProofLine(emptyLine);
				sub.setBottomDerived(emptyLine);

				ProofLine goalLine = new ProofLine("***", sub, false, thisCont.getGoal().getExpr());
				goalLine.assignRef("***************"); /* only temporarily for graphical reasons */
				goalLine.goalStatus(true);
				sub.addProofLine(goalLine);
				sub.setGoal(goalLine);
		
				/* now check if we are wide enough */
				int reqWidth = sub.minWidth(pArea);
				int availWidth = thisCont.getBox().width - 2 * subDist;
				if (reqWidth > availWidth)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.extendWidth(reqWidth - availWidth + 15);
					/* re-calculate the available width */
					availWidth = thisCont.getBox().width - 2 * subDist; 
				}

				/* now we know we have enough space to put box */

				/* layout the boxes and lines on the proof area : */
				sub.setBoxHeight(thisCont.minBelowLine(current) - (current.getRectArea().y +
					              current.getRectArea().height) - 10);
				sub.setBoxPos(new Point(thisCont.getBox().x + subDist, current.getRectArea().y 
									     + current.getRectArea().height + 5));
				sub.setBoxWidth(thisCont.getBox().width - 2 * subDist);
								
				newConst.setRectPos(new Point(sub.getBox().x + 5, sub.getBox().y + 5));
				newConst.setRectHeight(lineBoxHeight);
				newConst.setRectWidth(sub.getBox().width - 10);
				newConst.setLinePos(new Point(newConst.getRectArea().x + 2, newConst.getRectArea().y + lineHeight + 2));

				newExpLine.setRectPos(new Point(newConst.getRectArea().x, newConst.getRectArea().y + 
											    newConst.getRectArea().height + 2));
				newExpLine.setRectHeight(lineBoxHeight);
				newExpLine.setRectWidth(sub.getBox().width - 10);
				newExpLine.setLinePos(new Point(newExpLine.getRectArea().x + 2, newExpLine.getRectArea().y + lineHeight + 2));

				emptyLine.setRectPos(new Point(newExpLine.getRectArea().x, newExpLine.getRectArea().y + 
											   newExpLine.getRectArea().height + 2));
				emptyLine.setRectHeight(lineBoxHeight);
				emptyLine.setRectWidth(sub.getBox().width - 10);
				emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y + lineHeight + 2));

				goalLine.setRectPos(new Point(emptyLine.getRectArea().x, sub.getBox().y + sub.getBox().height - lineBoxHeight - 5));
				goalLine.setRectHeight(lineBoxHeight);
				goalLine.setRectWidth(sub.getBox().width - 10);
				goalLine.setLinePos(new Point(goalLine.getRectArea().x + 2, goalLine.getRectArea().y + lineHeight + 2));
								
				/* update reference position for new contexts */
				sub.setRefPos(newExpLine.getRectArea().x + newExpLine.getRectArea().width
						       - 2 - fm.stringWidth(newExpLine.getRef()));
				
				newConst.assignRef("");
				newExpLine.assignRef("");
				emptyLine.assignRef("");
				goalLine.assignRef("");

				/* mark that a rule has been applied to these lines */
				newConst.setRuleAppliedTo("ThereExistsE");
				newExpLine.setRuleAppliedTo("ThereExistsE");
				thisCont.getGoal().setRuleAppliedTo("ThereExistsE");

				/* now renumber all the lines in the proof */
				main.reLabel();
				/* update references to reflect new line numbers */
				main.updateReferences();
		
				thisCont.getGoal().assignRef("ExstE("+chosen.getNum()+","+goalLine.getNum()+")");
				thisCont.updateLineRecs(pArea);

				pArea.paintMe(horizOffset, vertOffset);
				appMsg.setText("Rule applied OK.");

				/* record proof is now not saved */
				isSaved = false; 
				saveStatus.setText("Changes Not Saved");

				/* record action for undo purposes */
				Vector subs = new Vector();
				subs.addElement(sub);
				UndoObject undo = new UndoObject("ThereExistsE", false, thisCont.getGoal(),
												 subs);
				undoStack.push(undo);
				btnUndo.enable();
				Vector enable = new Vector();
				enable.addElement("Undo");
				menuItems(enable, (Frame)getParent(), true);
			}
			else
			{
				appMsg.setText("The line you have chosen is not applicable for Existential Elimination!");
			}
		}
		else
		{
			appMsg.setText("Could not apply rule: the line you have chosen is not accessible");		
		}
	}


	public void proofByContradiction(ProofLine pl)
	/* applied the PC rule backwards from the given line */
	{
		ContextTree cont = pl.getContext();	

		ContextTree sub = null;
		/* create new sub-context */
		try
		{
			sub = new ContextTree("PC");
		}

		catch (InvalidContextException e) 
		{ System.out.println(e.getMessage()); }

		cont.addChildTree(sub);
		sub.setParent(cont);
		sub.setApp(this);
				
		/* now check whether the new box has enough space */

		/* we know we will have at least three lines ... */
		int reqHeight = 3 * lineBoxHeight + 4 + 10;
		int availHeight = (pl.getRectArea().y - 5) - (cont.getBottomDerived().getRectArea().y +
			              cont.getBottomDerived().getRectArea().height + 5);
		if (reqHeight > availHeight)
		/* if not enough space - extend context and parents ... */
		{
			cont.extendHeight(reqHeight - availHeight + lineBoxHeight + 2, pl);
			availHeight = (pl.getRectArea().y - 5) - (cont.getBottomDerived().getRectArea().y +
			              cont.getBottomDerived().getRectArea().height + 5);	
		}
	
		/* create the proof lines now */
		ExprTree expr = pl.getExpr();
		ExprTreeValue newVal = new ExprTreeValue("Op3", "~");
		ExprTree newExpr = new ExprTree(newVal);
		newExpr.setRightChild(expr);
		ProofLine pl1 = new ProofLine("***", sub, false, newExpr);
		pl1.setRuleAppliedTo("PC");
		sub.addProofLine(pl1);

		ProofLine emptyLine = createEmptyLine(sub, "***");
		sub.addProofLine(emptyLine);
		sub.setBottomDerived(emptyLine);

		ExprTree bottom = new ExprTree(new ExprTreeValue("Atom", "false"));
		ProofLine pl2 = new ProofLine("***", sub, false, bottom);
		pl2.assignRef("***************"); /* temporarily for graphical reasons */
		pl2.goalStatus(true);
		sub.addProofLine(pl2);
		sub.setGoal(pl2);
		
		/* now check if we are wide enough */
		int reqWidth = sub.minWidth(pArea);
		int availWidth = cont.getBox().width - 2 * subDist;
		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */		
		{
			cont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = cont.getBox().width - 2 * subDist; 
		}
		
		/* now we know we have enough space to put box */

		/* layout the box and its lines on the proof area : */
		sub.setBoxPos(new Point(cont.getBox().x + subDist, cont.getBottomDerived().getRectArea().y +
			           cont.getBottomDerived().getRectArea().height + 5));
		sub.setBoxWidth(availWidth);
		sub.setBoxHeight(pl.getRectArea().y - sub.getBox().y - 5);
				
		pl1.setRectPos(new Point(sub.getBox().x + 5, sub.getBox().y + 5));
		pl1.setRectHeight(lineBoxHeight);
		pl1.setRectWidth(sub.getBox().width - 10);
		pl1.setLinePos(new Point(pl1.getRectArea().x + 2, pl1.getRectArea().y + lineHeight + 2));

		pl2.setRectPos(new Point(sub.getBox().x + 5, sub.getBox().y + sub.getBox().height - lineBoxHeight - 5));
		pl2.setRectHeight(lineBoxHeight);
		pl2.setRectWidth(sub.getBox().width - 10);
		pl2.setLinePos(new Point(pl2.getRectArea().x + 2, pl2.getRectArea().y + lineHeight + 2));
		
		emptyLine.setRectPos(new Point(pl1.getRectArea().x, pl1.getRectArea().y + lineBoxHeight + 2));
		emptyLine.setRectHeight(lineBoxHeight);
		emptyLine.setRectWidth(sub.getBox().width - 10);
		emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y + lineHeight + 2));
		
		/* update reference position for new context */
		sub.setRefPos(pl2.getRectArea().x + pl2.getRectArea().width - 2
				      - fm.stringWidth(pl2.getRef()));
		
		/* mark that a rule has been applied to this line */
		pl.setRuleAppliedTo("PC");

		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();

		pl2.assignRef("");
		pl.assignRef("PC(" + pl1.getNum() + "," + pl2.getNum() + ")");
		cont.updateLineRecs(pArea);

		appMsg.setText("Rule applied OK.");
		pArea.paintMe(horizOffset, vertOffset);

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		Vector subs = new Vector();
		subs.addElement(sub);
		UndoObject undo = new UndoObject("PC", true, pl,
										 subs);
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);
	}

	public void eqsubBack(ProofLine current)
	/* applies the equality substitution rule backwards from the
	   given line */
	{
		/* need to know which proof line to use for eqsub */
		appMsg.setText("Please click the line to use for eqsub (must be an equality)...");
		/* now need to wait for the proof line to be clicked */
		currRule = "Eqsub";
		waitForClick();									
	}

	public void eqsubBackChosenLine()
	/* called when the user has selected which line to apply the
	   eqsub to (besides the current line) */
	{
		/* get context of current line */
		ContextTree thisCont = currLine.getContext();
		/* must check that chosen line is accessible within this
		   context */
		ContextTree contChosen = clicked1.getContext();

		if (((thisCont == contChosen) || (contChosen.isParentOf(thisCont)))
			&& (clicked1.getRectArea().y < currLine.getRectArea().y)
			&& (!(clicked1.isEmpty())))
		/* if valid context relation and line positions */
		{
			/* chosen line must be an equality */
			ExprTree e = clicked1.getExpr();
			ExprTreeValue v = (ExprTreeValue)e.getValue();
			if ((v.getType().equals("Atom")) &&
			   (e.strContents().startsWith("eq(")))
			{
				/* now ask the user in which direction the equality
				   should be used */
				appMsg.setText("Line " + clicked1.getNum() + " chosen.\nPress 'L'");
				appMsg.appendText(" to use the equation from left to right, or 'R' to ");
				appMsg.appendText("use the equation from right to left.");
				/* make sure mouse clicking does nothing */
				clickStatus = 0;
			}
			else
			{
				appMsg.setText("Could not apply rule: the line you chose is not an equality!");
				/* re-enable buttons / menu items */
				returnFromClicked();
			}
		}
		else
		{
			appMsg.setText("Could not apply rule: the line you clicked is not accessible");
			/* re-enable buttons / menu items */
			returnFromClicked();
		}
	}

	public void eqsubBackChosenOrientation(int leftOrRight)
	/* called when the user has chosen the way in which the
	   equation is to be used for eqsub (backwards).
	   Pre-condition: leftOrRight must be one of LEFTS, RIGHTS,
	                  LEFTC and RIGHTC */
	{
		/* record orientation - may need it later */
		tempLeftOrRight = leftOrRight;

		if ((leftOrRight == LEFTC) || (leftOrRight == LEFTS))
		/* if user wanted to use the equation from left to
		   right */
		{
			/* extract the LHS of the equation */
			String LHS = clicked1.getExpr().extractEq(0);
			/* find the number if occurrences of ths LHS in the
			   current line */
			occurrences = currLine.getExpr().numOccurrences(LHS);
			if (occurrences == 0)
			{
				appMsg.setText("Cannot apply rule: the LHS of the");
				appMsg.appendText(" chosen equation does not occur");
				appMsg.appendText(" at all in the current line!");
				/* re-enable buttons / menu items */
				returnFromClicked();
			}
			else if (occurrences == 1)
			/* if one occurrence, then do not need to ask the 
			   user anything else */
			{
				eqsubBackDone(clicked1, currLine, leftOrRight, 1);
			}
			else
			/* occurrences > 1, ask the user which occurrence 
			   to substitute for */
			{
				appMsg.setText("In the text box provided above, ");
				appMsg.appendText("either type the occurrence you would");
				appMsg.appendText(" like to substitute for (in the range 1 to ");
				appMsg.appendText((new Integer(occurrences)).toString());
				appMsg.appendText("),\nor type 'all' to substitute all occurrences.");
				dataEntryState = 5; /* indicate reading data for "Eqsub" */
				assump.setText("Occurrence : ");
				dataEntry.setText("");
				dataEntry.enable();
				topSub.add("South", input);
				validate();
				dataEntry.requestFocus();
			}
		}
		else
		/* from right to left */
		{
			/* extract the RHS of the equation */
			String RHS = clicked1.getExpr().extractEq(1);
			/* find the number if occurrences of ths RHS in the
			   current line */
			occurrences = currLine.getExpr().numOccurrences(RHS);
			if (occurrences == 0)
			{
				appMsg.setText("Cannot apply rule: the RHS of the");
				appMsg.appendText(" chosen equation does not occur");
				appMsg.appendText(" at all in the current line!");
				/* re-enable buttons / menu items */
				returnFromClicked();
			}
			else if (occurrences == 1)
			/* if one occurrence, then do not need to ask the 
			   user anything else */
			{
				eqsubBackDone(clicked1, currLine, leftOrRight, 1);
			}
			else
			/* occurrences > 1, ask the user which occurrence 
			   to substitute for */
			{
				appMsg.setText("In the text box provided above, ");
				appMsg.appendText("either type the occurrence you would");
				appMsg.appendText(" like to substitute for (in the range 1 to ");
				appMsg.appendText((new Integer(occurrences)).toString());
				appMsg.appendText("),\nor type 'all' to substitute all occurrences.");
				dataEntryState = 5; /* indicate reading data for "Eqsub" */
				assump.setText("Occurrence : ");
				dataEntry.setText("");
				dataEntry.enable();
				topSub.add("South", input);
				validate();
				dataEntry.requestFocus();
			}
		}
	}

	public void eqsubBackDone(ProofLine chosen, ProofLine current,
							  int leftOrRight, int occurrence)
	/* called when all parameters for eqsub have been collected.
	   If occurence = 0, then substitute all occurences, otherwise
	   substitute the given occurrence.
	   Pre-condition: the occurrence must be valid; leftOrRight
	                  must be one of LEFTS, RIGHTS, LEFTC and 
					  RIGHTC */
	{
		/* re-enable buttons / menu items */
		returnFromClicked();
		dataEntryState = 9; /* indicate no input currently read */
	
		/* update user interface */
		topSub.remove(input);
		validate();

		/* get context of current line */
		ContextTree thisCont = current.getContext();

		/* check if there is enough height */
		int reqHeight = lineBoxHeight + 4;
		int availHeight = current.getRectArea().y - (thisCont.getBottomDerived().getRectArea().y
						  + thisCont.getBottomDerived().getRectArea().height);
		if (reqHeight > availHeight)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
								   current.getRectArea().y - 1);
		}
		
		/* make a copy of the current line */
		ExprTree theExp = null;
		try
		{
			theExp = (ExprTree)current.getExpr().clone();
		}
		catch (CloneNotSupportedException e)
		{
			/* should never happen */
			System.out.println(e.getMessage());
		}

		/* extract the LHS and RHS of the equation */
		String LHS = chosen.getExpr().extractEq(0);
		String RHS = chosen.getExpr().extractEq(1);

		if ((leftOrRight == LEFTC) || (leftOrRight == LEFTS))
		/* if user wanted to use the equation from left to
		   right */
		{
			/* make substitution */
			theExp.substituteOccurrence(LHS, RHS, occurrence);
		}
		else
		/* from right to left */
		{
			/* make substitution */
			theExp.substituteOccurrence(RHS, LHS, occurrence);
		}
		
		ProofLine newGoal = new ProofLine("***", thisCont, true, theExp);
		newGoal.setRectHeight(lineBoxHeight);
		newGoal.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y -
		                            (newGoal.getRectArea().height + 2)));
		newGoal.setLinePos(new Point(newGoal.getRectArea().x + 2, newGoal.getRectArea().y +
								     lineHeight + 2));

		/* record position of current line */			
		int index = thisCont.getProofLines().indexOf(current);
		/* add new goal before current line */
		thisCont.addProofLineAt(newGoal, index);
		thisCont.setGoal(newGoal);
		newGoal.goalStatus(true);
		current.goalStatus(false);
		/* mark rule has been applied to the current line */
		current.setRuleAppliedTo("Eqsub");
		current.assignRef("***************"); /* temporarily */
		newGoal.assignRef("***************"); /* temporarily */

		/* now check whether the refPos can still stay the same */
		int minRefPos1 = current.getLinePos().x + fm.stringWidth(current.getNum()) +
			             current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
						 current.getRefSpace();
		int minRefPos2 = newGoal.getLinePos().x + fm.stringWidth(newGoal.getNum()) +
			             newGoal.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(newGoal.getExpr().strContents())) +
						 newGoal.getRefSpace();
		int minRefPos;
		if (minRefPos1 > minRefPos2)
		{
			minRefPos = minRefPos1;
		}
		else
		{
			minRefPos = minRefPos2;
		}
			
		if (thisCont.getRefPos() < minRefPos)
		/* if need to move refPos */
		{
			thisCont.setRefPos(minRefPos);
			thisCont.updateLineRecs(pArea);
		}

		current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
			                 - current.getRectArea().x);
		newGoal.setRectWidth(newGoal.minimumWidth(fm));
				
		/* now check if need to increase the width of the context */
		int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
		int availWidth = thisCont.getBox().width;

		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = thisCont.getBox().width; 
		}
			
		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();
			
		/* assign reference to current line */
		current.assignRef("Eqsub("+chosen.getNum()+","+newGoal.getNum()+")");
		newGoal.assignRef("");
				
		/* repaint canvas to reflect changes */
		pArea.paintMe(horizOffset, vertOffset);
		appMsg.setText("Rule applied OK.");

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		UndoObject undo = new UndoObject("Eqsub", true, newGoal, new Vector());
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);
	}

	public void eqsubFor(ProofLine current)
	/* applies the equality substitution rule forwards for the
	   given line */
	{
		/* need to know which proof lines to use for the 
		   substitution */
		appMsg.setText("Please click the two lines to use for Eqsub...");
		appMsg.appendText("\nNote: the SECOND line you click should be the ");
		appMsg.appendText("equality which will be used in the substitution");
		/* now need to wait for the proof lines to be clicked */
		currRule = "Eqsub";
		waitForClick();									
	}

	public void eqsubForChosenLine(ProofLine chosen1,
								   ProofLine chosen2,
								   ProofLine current)
	/* called when the user has selected the two lines to which
	   to apply the eqsub rule (forwards) */
	{

		/* get context of current line */
		ContextTree thisCont = current.getContext();
		/* must check that both lines are accessible within this
		   context */
		ContextTree cont1 = chosen1.getContext();
		ContextTree cont2 = chosen2.getContext();
		if (((thisCont == cont1) || (cont1.isParentOf(thisCont)))
			&& ((thisCont == cont2) || (cont2.isParentOf(thisCont)))
			&& (chosen1.getRectArea().y < current.getRectArea().y)
			&& (chosen2.getRectArea().y < current.getRectArea().y)
			&& (!(chosen1.isEmpty())) && (!(chosen2.isEmpty())))
		/* if valid context relation and line positions */
		{
			ExprTree e = chosen2.getExpr();
			ExprTreeValue v = (ExprTreeValue)e.getValue();
			if ((v.getType().equals("Atom")) &&
			    (e.strContents().startsWith("eq(")))
			/* if second line is actually an equality */
			{
				/* now ask the user in which direction the equality should
				   be used */
				appMsg.setText("Lines " + chosen1.getNum() + " and ");
				appMsg.appendText(chosen2.getNum() + " chosen.\nPress 'L' to use");
				appMsg.appendText(" the equation from left to right, or 'R' to ");
				appMsg.appendText("use the equation from right to left.");
				/* make sure mouse clicking does nothing */
				clickStatus = 0;
			}
			else
			/* second line is not equality - report error to user */
			{
				appMsg.setText("Could not apply rule: the second line you clicked ");
				appMsg.appendText("is not an equality!");
				/* re-enable buttons / menu items */
				returnFromClicked();
			}
		}
		else
		{
			appMsg.setText("Could not apply rule: at least one of the lines ");
			appMsg.appendText("you clicked is not accessible");
			/* re-enable buttons / menu items */
			returnFromClicked();
		}
	}

	public void eqsubForChosenOrientation(int leftOrRight)
	/* called when the user has chosen the way in which the
	   equation is to be used for eqsub (forwards).
	   Pre-condition: leftOrRight must be one of LEFTS, RIGHTS,
	                  LEFTC and RIGHTC */
	{
		/* record orientation - may need it later */
		tempLeftOrRight = leftOrRight;

		if ((leftOrRight == LEFTC) || (leftOrRight == LEFTS))
		/* if user wanted to use the equation from left to
		   right */
		{
			/* extract the LHS of the equation */
			String LHS = clicked2.getExpr().extractEq(0);
			/* find the number if occurrences of ths LHS in the
			   current line */
			occurrences = clicked1.getExpr().numOccurrences(LHS);
			if (occurrences == 0)
			{
				appMsg.setText("Could not apply rule: the LHS of the");
				appMsg.appendText(" chosen equation does not occur");
				appMsg.appendText(" at all in the other line!");
				/* re-enable buttons / menu items */
				returnFromClicked();
			}
			else if (occurrences == 1)
			/* if one occurrence, then do not need to ask the 
			   user anything else */
			{
				eqsubForDone(clicked1, clicked2, currLine, leftOrRight, 1);
			}
			else
			/* occurrences > 1, ask the user which occurrence 
			   to substitute for */
			{
				appMsg.setText("In the text box provided above, ");
				appMsg.appendText("either type the occurrence you would");
				appMsg.appendText(" like to substitute for (in the range 1 to ");
				appMsg.appendText((new Integer(occurrences)).toString());
				appMsg.appendText("),\nor type 'all' to substitute all occurrences.");
				dataEntryState = 5; /* indicate reading data for "Eqsub" */
				assump.setText("Occurrence : ");
				dataEntry.setText("");
				dataEntry.enable();
				topSub.add("South", input);
				validate();
				dataEntry.requestFocus();
			}
		}
		else
		/* from right to left */
		{
			/* extract the RHS of the equation */
			String RHS = clicked2.getExpr().extractEq(1);
			/* find the number if occurrences of ths RHS in the
			   current line */
			occurrences = clicked1.getExpr().numOccurrences(RHS);
			if (occurrences == 0)
			{
				appMsg.setText("Could not apply rule: the RHS of the");
				appMsg.appendText(" chosen equation does not occur");
				appMsg.appendText(" at all in the other line!");
				/* re-enable buttons / menu items */
				returnFromClicked();
			}
			else if (occurrences == 1)
			/* if one occurrence, then do not need to ask the 
			   user anything else */
			{
				eqsubForDone(clicked1, clicked2, currLine, leftOrRight, 1);
			}
			else
			/* occurrences > 1, ask the user which occurrence 
			   to substitute for */
			{
				appMsg.setText("In the text box provided above, ");
				appMsg.appendText("either type the occurrence you would");
				appMsg.appendText(" like to substitute for (in the range 1 to ");
				appMsg.appendText((new Integer(occurrences)).toString());
				appMsg.appendText("),\nor type 'all' to substitute all occurrences.");
				dataEntryState = 5; /* indicate reading data for "Eqsub" */
				assump.setText("Occurrence : ");
				dataEntry.setText("");
				dataEntry.enable();
				topSub.add("South", input);
				validate();
				dataEntry.requestFocus();
			}
		}
	}

	public void eqsubForDone(ProofLine chosen1, ProofLine chosen2,
							 ProofLine current, int leftOrRight, 
							 int occurrence)
	/* called when all parameters for eqsub have been collected.
	   If occurence = 0, then substitute all occurences, otherwise
	   substitute the given occurrence.
	   Pre-condition: the occurrence must be valid; leftOrRight
	                  must be one of LEFTS, RIGHTS, LEFTC and 
					  RIGHTC */
	{
		/* re-enable buttons / menu items */
		returnFromClicked();
		dataEntryState = 9; /* indicate no input currently read */
	
		/* update user interface */
		topSub.remove(input);
		validate();

		/* get context of current line */
		ContextTree thisCont = current.getContext();

		/* now check if there is enough height */
		int reqHeight = lineBoxHeight + 4;
		int availHeight = thisCont.minBelowLine(current) - (current.getRectArea().y
						  + current.getRectArea().height);
									
		if (reqHeight > availHeight)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
								   current.getRectArea().y + current.getRectArea().height);
		}
		
		current.userDefinedStatus(true);

		/* record position of current line */			
		int index = thisCont.getProofLines().indexOf(current);
		/* create a new empty proof line */
		ProofLine emptyLine = createEmptyLine(thisCont, "***");
		emptyLine.setRectHeight(lineBoxHeight);
		emptyLine.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y +
			                           current.getRectArea().height + 2));
		emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y +
									   lineHeight + 2));
		/* add new empty line just below the current line */
		thisCont.addProofLineAt(emptyLine, index + 1);
		thisCont.setBottomDerived(emptyLine);

		/* make a copy of the line to be substituted */
		ExprTree theExp = null;
		try
		{
			theExp = (ExprTree)chosen1.getExpr().clone();
		}
		catch (CloneNotSupportedException e)
		{
			/* should never happen */
			System.out.println(e.getMessage());
		}

		/* extract the LHS and RHS of the equation */
		String LHS = chosen2.getExpr().extractEq(0);
		String RHS = chosen2.getExpr().extractEq(1);

		if ((leftOrRight == LEFTC) || (leftOrRight == LEFTS))
		/* if user wanted to use the equation from left to
		   right */
		{
			/* make substitution */
			theExp.substituteOccurrence(LHS, RHS, occurrence);
		}
		else
		/* from right to left */
		{
			/* make substitution */
			theExp.substituteOccurrence(RHS, LHS, occurrence);
		}


		/* make necessary changes to the current proof line */
		current.assignExpr(theExp);
		current.assignRef("Eqsub("+chosen1.getNum()+","+chosen2.getNum()+")");
		current.setNum("***"); /* temporarily */

		/* now check whether the refPos can still stay the same */
		int minRefPos = current.getLinePos().x + fm.stringWidth(current.getNum()) +
			            current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
						current.getRefSpace();
			
		if (thisCont.getRefPos() < minRefPos)
		/* if need to move refPos */
		{
			thisCont.setRefPos(minRefPos);
			thisCont.updateLineRecs(pArea);
		}

		current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
			                 - current.getRectArea().x);
		emptyLine.setRectWidth(emptyLine.minimumWidth(fm));

		/* now check if need to increase the width of the context */
		int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
		int availWidth = thisCont.getBox().width;

		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */
		{
			thisCont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = thisCont.getBox().width; 
		}
			
		/* mark rule has been applied to the current line */
		current.setRuleAppliedTo("Eqsub");

		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();
			
		/* repaint canvas to reflect changes */
		pArea.paintMe(horizOffset, vertOffset);
				
		appMsg.setText("Rule applied OK.");

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		UndoObject undo = new UndoObject("Eqsub", false, current, new Vector());
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);
	}

	public void reflex(ProofLine current)
	/* applies the reflex rule forwards for the given line */
	{
		/* need to read the relevant term from the user */
		appMsg.setText("In the text box provided above, enter the term to apply the rule to.");
		waitForClick();
		clickStatus = 0; /* make sure clicking on proof area does nothing */
		dataEntryState = 4; /* indicate reading data for "Reflex" */
		currRule = "Reflex";
		GlobalTables.initTempLists();
		assump.setText("Term : ");
		dataEntry.setText("");
		dataEntry.enable();
		topSub.add("South", input);
		validate();
		dataEntry.requestFocus();
	}

	public void reflexDone(ProofLine current, String term)
	/* called when the user has chosen the term to which to apply
	   the reflex rule */
	{
		/* must syntax analyse the term */
		ExprTree termExpr = null;
		try
		{
			/* attach predicate to the term so could use parser
			   to analyse it as an atom */
			GlobalTables.appendToPredTable("aSpecialPredForThisPurpose", new Integer(1));
			term = "aSpecialPredForThisPurpose("+term+")";
						
			termExpr = datain.syntaxAnalyse(term);
			/* if got to this point - parser succeeded */

			GlobalTables.predTable().remove("aSpecialPredForThisPurpose");

			ContextTree thisCont = current.getContext();
			Hashtable functions = GlobalTables.tempFunctList();
			if (functions.isEmpty())
			/* no functions may be introduced */
			{
				Hashtable constants = GlobalTables.tempConstList();
				if (!(constants.isEmpty()))
				/* if any constant to be introduced - must be local */
				{
					for (Enumeration e = constants.keys(); e.hasMoreElements(); )
					{
						String constant = (String)e.nextElement();
						boolean b = thisCont.searchConstInParents(constant);
						if (b == false)
						{
							appMsg.setText("You cannot introduce new constants!");
							appMsg.appendText("\nPlease re-type....");
							/* re-initialise temporary global tables */
							GlobalTables.initTempLists();
							dataEntry.requestFocus();
							/* exit immediately */
							return;
						}
					}
				}
				/* if got to this point, input is ok */
				int index = term.indexOf("(");
				/* get back to the actual term */
				term = term.substring(index + 1, term.length() - 1);

				appMsg.setText("Input "+term+" OK.\n");

				/* update user interface */
				topSub.remove(input);
				validate();

				/* re-enable menu items / push-buttons */
				returnFromClicked();
				dataEntryState = 9; /* indicate no input currently read */
								
				/* now check if there is enough height */
				int reqHeight = lineBoxHeight + 4;
				int availHeight = thisCont.minBelowLine(current) - (current.getRectArea().y
								  + current.getRectArea().height);
									
				if (reqHeight > availHeight)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.shiftContents(reqHeight - availHeight + lineBoxHeight + 2,
										   current.getRectArea().y + current.getRectArea().height);
				}
				
				current.userDefinedStatus(true);

				/* record position of current line */			
				index = thisCont.getProofLines().indexOf(current);
				/* create a new empty proof line */
				ProofLine emptyLine = createEmptyLine(thisCont, "***");
				emptyLine.setRectHeight(lineBoxHeight);
				emptyLine.setRectPos(new Point(current.getRectArea().x, current.getRectArea().y +
					                           current.getRectArea().height + 2));
				emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y +
											   lineHeight + 2));
				/* add new empty line just below the current line */
				thisCont.addProofLineAt(emptyLine, index + 1);
				thisCont.setBottomDerived(emptyLine);

				/* create the new expression */
				String newAtom = "eq("+term+","+term+")";
				ExprTreeValue newVal = new ExprTreeValue("Atom", newAtom);
				ExprTree theExp = new ExprTree(newVal);

				/* make necessary changes to the current proof line */
				current.assignExpr(theExp);
				current.assignRef("Reflex");
				current.setNum("***"); /* temporarily */

				/* now check whether the refPos can still stay the same */
				int minRefPos = current.getLinePos().x + fm.stringWidth(current.getNum()) +
					            current.getNumSpace() + fm.stringWidth(ExprTree.formattedContents(current.getExpr().strContents())) +
								current.getRefSpace();
			
				if (thisCont.getRefPos() < minRefPos)
				/* if need to move refPos */
				{
					thisCont.setRefPos(minRefPos);
					thisCont.updateLineRecs(pArea);
				}

				current.setRectWidth(thisCont.getRefPos() + fm.stringWidth(current.getRef()) + 2
					                 - current.getRectArea().x);
				emptyLine.setRectWidth(emptyLine.minimumWidth(fm));

				/* now check if need to increase the width of the context */
				int reqWidth = 5 + thisCont.minWidthLineRecs() + 5;
				int availWidth = thisCont.getBox().width;

				if (reqWidth > availWidth)
				/* if not enough space - extend context and parents ... */
				{
					thisCont.extendWidth(reqWidth - availWidth + 15);
					/* re-calculate the available width */
					availWidth = thisCont.getBox().width; 
				}
			
				/* mark rule has been applied to the current line */
				current.setRuleAppliedTo("Reflex");

				/* now renumber all the lines in the proof */
				main.reLabel();
				/* update references to reflect new line numbers */
				main.updateReferences();
			
				/* repaint canvas to reflect changes */
				pArea.paintMe(horizOffset, vertOffset);
				
				appMsg.appendText("Rule applied OK.");

				/* record proof is now not saved */
				isSaved = false; 
				saveStatus.setText("Changes Not Saved");

				/* record action for undo purposes */
				UndoObject undo = new UndoObject("Reflex", false, current, new Vector());
				undoStack.push(undo);
				btnUndo.enable();
				Vector enable = new Vector();
				enable.addElement("Undo");
				menuItems(enable, (Frame)getParent(), true);
			}
			else
			{
				appMsg.setText("You cannot introduce new function symbols!\n");
				appMsg.appendText("Please re-type...");
				/* re-initialise temporary global tables */
				GlobalTables.initTempLists();
				dataEntry.requestFocus();
			}	
		}
		catch (LexAnalyserException e)
		/* lexical analyser error */
		{
			appMsg.setText(e.getMessage());
			appMsg.appendText("\nPlease re-type...");
			/* re-initialise temporary global tables */
			GlobalTables.initTempLists();
			dataEntry.requestFocus();
		}
		catch (ParserException e)
		/* parser error */
		{
			appMsg.setText("An error was detected in your input!\n");
			appMsg.appendText("Remember, you should input a term.\n");
			appMsg.appendText("Please re-type...");
			/* re-initialise temporary global tables */
			GlobalTables.initTempLists();
			dataEntry.requestFocus();
		}
		catch (IOException e)
		/* any I/O error */
		{
			appMsg.appendText(e.getMessage());
			appMsg.appendText("\nPlease re-type...");
			/* re-initialise temporary global tables */
			GlobalTables.initTempLists();
			dataEntry.requestFocus();
		}
	}

	public void lemma(ProofLine current)
	/* applies the lemma rule backwards from the given line */
	{
		/* need to ask the user what lemma he/she would like to
		   prove - the 'Eureka' step */
		appMsg.setText("In the text box provided above, enter the lemma you would like to prove.");
		waitForClick();	/* disable menu items / push-buttons */								
		clickStatus = 0; /* make sure clicking on proof area does nothing */
		dataEntryState = 2; /* indicate reading data for "Lemma" */
		currRule = "Lemma"; /* record current rule is 'Lemma' */
		GlobalTables.initTempLists();
		assump.setText("Lemma : ");
		dataEntry.setText("");
		dataEntry.enable();
		topSub.add("South", input);
		validate();
		dataEntry.requestFocus();		
	}

	public void lemmaDone(ProofLine current, String theLemma)
	/* called when the user has typed in the lemma to prove */
	{
		/* must syntax analyse the new sentence */
		ExprTree sentence = null;
		try
		{
			sentence = datain.syntaxAnalyse(theLemma);
			/* if got to this point - parser succeeded */
		
			ContextTree thisCont = current.getContext();

			/* cannot use any constants beginning with 'sk' unless they
			   already local to this context */
			for (Enumeration e = GlobalTables.tempConstList().keys(); e.hasMoreElements(); )
			{
				String currConst = (String)e.nextElement();
				if (currConst.startsWith("sk"))
				{
					if (thisCont.searchConstInParents(currConst) == false)
					{
						appMsg.setText("Cannot introduce constants starting with 'sk'!");
						appMsg.appendText("\nPlease re-type...");
						/* re-initialise temporary global tables */
						GlobalTables.initTempLists();
						dataEntry.requestFocus();
						return;
					}
					else
					{
						GlobalTables.tempConstList().remove(currConst);
					}
				}
			}

			appMsg.setText("Rule applied OK.");	
			/* tell user which terms/predicates have been introduced */
			showNewConsts();
			showNewVars();
			showNewFuncts();
			showNewPreds();
			/* update the global tables */
			GlobalTables.updateTables();
			topSub.remove(input);
			validate();

			returnFromClicked();
			dataEntryState = 9; /* indicate no input currently read */
			
			ContextTree sub1 = null;
			ContextTree sub2 = null;
			/* create new sub-contexts */
			try
			{
				sub1 = new ContextTree("Lemma");
				sub2 = new ContextTree("Lemma");
			} 
			catch (InvalidContextException e) 
			{ System.out.println(e.getMessage()); }

			thisCont.addChildTree(sub1);
			thisCont.addChildTree(sub2);
			sub1.setParent(thisCont);
			sub1.setApp(this);
			sub2.setParent(thisCont);
			sub2.setApp(this);
		
			/* now check whether boxes have enough space */

			/* we know we will have at least three lines ... */
			int reqHeight = 3 * lineBoxHeight + 4 + 10;
			int availHeight = (current.getRectArea().y - 5) - (thisCont.getBottomDerived().getRectArea().y +
							  thisCont.getBottomDerived().getRectArea().height + 5);
			if (reqHeight > availHeight)
			/* if not enough space - extend context and parents ... */
			{
				thisCont.extendHeight(reqHeight - availHeight + lineBoxHeight + 2, current);
				availHeight = (current.getRectArea().y - 5) - (thisCont.getBottomDerived().getRectArea().y +
							   thisCont.getBottomDerived().getRectArea().height + 5);	
			}
	
			ProofLine emptyLine1 = createEmptyLine(sub1, "***");
			sub1.addProofLine(emptyLine1);
			sub1.setBottomDerived(emptyLine1);

			ProofLine lemma1 = new ProofLine("***", sub1, false, sentence);
			lemma1.assignRef("***************"); /* only temporarily for graphical reasons */
			lemma1.goalStatus(true);
			sub1.addProofLine(lemma1);
			sub1.setGoal(lemma1);
			
			ProofLine lemma2 = new ProofLine("***", sub2, false, sentence);
			lemma2.assignRef("***************");
			sub2.addProofLine(lemma2);
			
			ProofLine emptyLine2 = createEmptyLine(sub2, "***");
			sub2.addProofLine(emptyLine2);
			sub2.setBottomDerived(emptyLine2);

			ProofLine lemmaGoal = new ProofLine("***", sub2, false, current.getExpr());
			lemmaGoal.assignRef("***************"); /* only temporarily for graphical reasons */
			lemmaGoal.goalStatus(true);
			sub2.addProofLine(lemmaGoal);
			sub2.setGoal(lemmaGoal);

			/* now check if we are wide enough */
			int widthSub1 = sub1.minWidth(pArea);
			int widthSub2 = sub2.minWidth(pArea);
			int reqWidth = widthSub1 + widthSub2;
			int availWidth = thisCont.getBox().width - 2 * subDist - siblingDist;
			if (reqWidth > availWidth)
			/* if not enough space - extend context and parents ... */
			{
				thisCont.extendWidth(reqWidth - availWidth + 15);
				/* re-calculate the available width */
				availWidth = thisCont.getBox().width - 2 * subDist - siblingDist; 
			}

			/* now we know we have enough space to put boxes */

			/* layout the boxes and lines on the proof area : */
			sub1.setBoxPos(new Point(thisCont.getBox().x + subDist, thisCont.getBottomDerived().getRectArea().y +
						   thisCont.getBottomDerived().getRectArea().height + 5));
			sub1.setBoxWidth(widthSub1 + ((availWidth - reqWidth) / 2));
			sub1.setBoxHeight(current.getRectArea().y - sub1.getBox().y - 5);
		
			sub2.setBoxPos(new Point(sub1.getBox().x + sub1.getBox().width + siblingDist,
									 sub1.getBox().y));
			sub2.setBoxWidth(widthSub2 + ((availWidth - reqWidth) / 2));
			sub2.setBoxHeight(sub1.getBox().height);
		
			emptyLine1.setRectPos(new Point(sub1.getBox().x + 5, sub1.getBox().y + 5));
			emptyLine1.setRectHeight(lineBoxHeight);
			emptyLine1.setRectWidth(sub1.getBox().width - 10);
			emptyLine1.setLinePos(new Point(emptyLine1.getRectArea().x + 2, emptyLine1.getRectArea().y + lineHeight + 2));

			lemma1.setRectPos(new Point(emptyLine1.getRectArea().x, sub1.getBox().y + sub1.getBox().height - lineBoxHeight - 5));
			lemma1.setRectHeight(lineBoxHeight);
			lemma1.setRectWidth(sub1.getBox().width - 10);
			lemma1.setLinePos(new Point(lemma1.getRectArea().x + 2, lemma1.getRectArea().y + lineHeight + 2));

			lemma2.setRectPos(new Point(sub2.getBox().x + 5, sub2.getBox().y + 5));
			lemma2.setRectHeight(lineBoxHeight);
			lemma2.setRectWidth(sub2.getBox().width - 10);
			lemma2.setLinePos(new Point(lemma2.getRectArea().x + 2, lemma2.getRectArea().y + lineHeight + 2));

			emptyLine2.setRectPos(new Point(lemma2.getRectArea().x, lemma2.getRectArea().y + 
																	lemma2.getRectArea().height + 2));
			emptyLine2.setRectHeight(lineBoxHeight);
			emptyLine2.setRectWidth(sub2.getBox().width - 10);
			emptyLine2.setLinePos(new Point(emptyLine2.getRectArea().x + 2, emptyLine2.getRectArea().y + lineHeight + 2));

			lemmaGoal.setRectPos(new Point(lemma2.getRectArea().x, sub2.getBox().y + sub2.getBox().height - lineBoxHeight -5));
			lemmaGoal.setRectHeight(lineBoxHeight);
			lemmaGoal.setRectWidth(sub2.getBox().width - 10);
			lemmaGoal.setLinePos(new Point(lemmaGoal.getRectArea().x + 2, lemmaGoal.getRectArea().y + lineHeight + 2));	
				
			/* update reference position for new contexts */
			sub1.setRefPos(lemma1.getRectArea().x + lemma1.getRectArea().width
						   - 2 - fm.stringWidth(lemma1.getRef()));
			int refPos1 = lemma2.getRectArea().x + lemma2.getRectArea().width
						   - 2 - fm.stringWidth(lemma2.getRef());
			int refPos2 = lemmaGoal.getRectArea().x + lemmaGoal.getRectArea().width
						   - 2 - fm.stringWidth(lemmaGoal.getRef());
			int newRefPos;
			if (refPos1 > refPos2)
			{
				newRefPos = refPos1;
			}
			else
			{
				newRefPos = refPos2;
			}
			sub2.setRefPos(newRefPos);
	
			lemma1.assignRef("");
			lemma2.assignRef("");
			lemmaGoal.assignRef("");

			/* mark that a rule has been applied to this line */
			current.setRuleAppliedTo("Lemma");

			/* now renumber all the lines in the proof */
			main.reLabel();
			/* update references to reflect new line numbers */
			main.updateReferences();
		
			current.assignRef("Lemma");
			thisCont.updateLineRecs(pArea);

			/* repaint canvas to reflect changes */			
			pArea.paintMe(horizOffset, vertOffset);

			appMsg.setText("EUREKA!\n");
			appMsg.appendText("Rule applied OK.");

			/* record proof is now not saved */
			isSaved = false; 
			saveStatus.setText("Changes Not Saved");

			/* record action for undo purposes */
			Vector subs = new Vector();
			subs.addElement(sub1);
			subs.addElement(sub2);
			UndoObject undo = new UndoObject("Lemma", true, current,
											 subs);
			undoStack.push(undo);
			btnUndo.enable();
			Vector enable = new Vector();
			enable.addElement("Undo");
			menuItems(enable, (Frame)getParent(), true);
		}
		catch (Exception e)
		/* if an error was encountered in input - re-read new sentence */
		{
			appMsg.setText("Parsing of your input has failed!\n");
			appMsg.appendText(e.getMessage());
			appMsg.appendText("\nPlease re-type...");
			/* re-initialise temporary global tables */
			GlobalTables.initTempLists();
			dataEntry.requestFocus();
		}
	}

	public void forAllArrowIntro(ProofLine pl)
	/* applies the for-all arrow introduction rule backwards from
	   the given line */
	{
		/* check if actually applicable for for-all arrow intro */
		ExprTree exp = (ExprTree)pl.getExpr().getRightChild();
		ExprTreeValue v = (ExprTreeValue)exp.getValue();
		if (!(v.getContents().equals(">")))
		{
			appMsg.setText("Cannot use For-All Arrow Introduction with the current line!");
			return;
		}

		ContextTree cont = pl.getContext();	

		ContextTree sub = null;
		/* create new sub-context */
		try
		{
			sub = new ContextTree("ForAllArrowI");
		}
		catch (InvalidContextException e) 
		{ 
			System.out.println(e.getMessage()); 
		}

		cont.addChildTree(sub);
		sub.setParent(cont);
		sub.setApp(this);

		/* add new local constant */
		String theConst = "sk" + currSkolem;
		sub.addConstants(theConst);
		if (currSkolem == Long.MAX_VALUE)
		{
			currSkolem = 1;
		}
		else
		{
			currSkolem++;
		}
				
		/* now check whether the new box has enough space */

		/* we know we will have at least four lines ... */
		int reqHeight = 4 * lineBoxHeight + 6 + 10;
		int availHeight = (pl.getRectArea().y - 5) - (cont.getBottomDerived().getRectArea().y +
			              cont.getBottomDerived().getRectArea().height + 5);
		if (reqHeight > availHeight)
		/* if not enough height - extend context and parents ... */
		{
			cont.extendHeight(reqHeight - availHeight + lineBoxHeight + 2, pl);
			availHeight = (pl.getRectArea().y - 5) - (cont.getBottomDerived().getRectArea().y +
			              cont.getBottomDerived().getRectArea().height + 5);	
		}
	
		/* create the proof lines now */

		ExprTreeValue val = new ExprTreeValue("Atom", theConst+" (UnvI)");
		ExprTree newConstExpr = new ExprTree(val);
		ProofLine newConst = new ProofLine("***", sub, false, newConstExpr);
		newConst.setLocalDecl(true);
		sub.addProofLine(newConst);

		/* get the variable to be replaced */
		String var = ((ExprTreeValue)pl.getExpr().getValue()).getqContents();
		/* get the quantified sub-expression */
		ExprTree theExp = null;
		try
		{
			theExp = (ExprTree)pl.getExpr().getRightChild().clone();
		}
		catch (CloneNotSupportedException e)
		{
			/* should never happen */
			System.out.println(e.getMessage());								
		}
			
		/* now perform the actual substitution */
		theExp.substituteVar(var, theConst);

		ExprTree LHS = (ExprTree)theExp.getLeftChild();
		ExprTree RHS = (ExprTree)theExp.getRightChild();

		ProofLine topLine = new ProofLine("***", sub, false, LHS);
		topLine.assignRef("***************"); /* temporarily for graphical reasons */
		topLine.setRuleAppliedTo("ForAllArrowI");
		sub.addProofLine(topLine);

		ProofLine emptyLine = createEmptyLine(sub, "***");
		sub.addProofLine(emptyLine);
		sub.setBottomDerived(emptyLine);

		ProofLine goalLine = new ProofLine("***", sub, false, RHS);
		goalLine.assignRef("***************"); /* temporarily for graphical reasons */
		goalLine.goalStatus(true);
		sub.addProofLine(goalLine);
		sub.setGoal(goalLine);
				
		/* now check if we are wide enough */
		int reqWidth = sub.minWidth(pArea);
		int availWidth = cont.getBox().width - 2 * subDist;
		if (reqWidth > availWidth)
		/* if not enough space - extend context and parents ... */		
		{
			cont.extendWidth(reqWidth - availWidth + 15);
			/* re-calculate the available width */
			availWidth = cont.getBox().width - 2 * subDist; 
		}
		
		/* now we know we have enough space to put box */

		/* layout the box and its lines on the proof area : */
		sub.setBoxPos(new Point(cont.getBox().x + subDist, cont.getBottomDerived().getRectArea().y +
			           cont.getBottomDerived().getRectArea().height + 5));
		sub.setBoxWidth(availWidth);
		sub.setBoxHeight(pl.getRectArea().y - sub.getBox().y - 5);
				
		newConst.setRectPos(new Point(sub.getBox().x + 5, sub.getBox().y + 5));
		newConst.setRectHeight(lineBoxHeight);
		newConst.setRectWidth(sub.getBox().width - 10);
		newConst.setLinePos(new Point(newConst.getRectArea().x + 2, newConst.getRectArea().y + lineHeight + 2));
		
		topLine.setRectPos(new Point(newConst.getRectArea().x, newConst.getRectArea().y + lineBoxHeight + 2));
		topLine.setRectHeight(lineBoxHeight);
		topLine.setRectWidth(sub.getBox().width - 10);
		topLine.setLinePos(new Point(topLine.getRectArea().x + 2, topLine.getRectArea().y + lineHeight + 2));

		emptyLine.setRectPos(new Point(topLine.getRectArea().x, topLine.getRectArea().y + lineBoxHeight + 2));
		emptyLine.setRectHeight(lineBoxHeight);
		emptyLine.setRectWidth(sub.getBox().width - 10);
		emptyLine.setLinePos(new Point(emptyLine.getRectArea().x + 2, emptyLine.getRectArea().y + lineHeight + 2));

		goalLine.setRectPos(new Point(sub.getBox().x + 5, sub.getBox().y + sub.getBox().height - lineBoxHeight - 5));
		goalLine.setRectHeight(lineBoxHeight);
		goalLine.setRectWidth(sub.getBox().width - 10);
		goalLine.setLinePos(new Point(goalLine.getRectArea().x + 2, goalLine.getRectArea().y + lineHeight + 2));

		int refPos1 = topLine.getRectArea().x + topLine.getRectArea().width - 2
				      - fm.stringWidth(topLine.getRef());
		int refPos2 = goalLine.getRectArea().x + goalLine.getRectArea().width - 2
				      - fm.stringWidth(goalLine.getRef());
		int refPos;
		if (refPos1 > refPos2)
		{
			refPos = refPos1;
		}
		else
		{
			refPos = refPos2;
		}
		/* update reference position for new context */
		sub.setRefPos(refPos);
		
		/* make necessary changes to the current proof line */
		pl.setRuleAppliedTo("ForAllArrowI");

		/* now renumber all the lines in the proof */
		main.reLabel();
		/* update references to reflect new line numbers */
		main.updateReferences();

		goalLine.assignRef("");
		topLine.assignRef("");
		pl.assignRef("Unv-ArrowI");
		cont.updateLineRecs(pArea);

		appMsg.setText("Rule applied OK.");
		pArea.paintMe(horizOffset, vertOffset);

		/* record proof is now not saved */
		isSaved = false; 
		saveStatus.setText("Changes Not Saved");

		/* record action for undo purposes */
		Vector subs = new Vector();
		subs.addElement(sub);
		UndoObject undo = new UndoObject("ForAllArrowI", true, pl,
										 subs);
		undoStack.push(undo);
		btnUndo.enable();
		Vector enable = new Vector();
		enable.addElement("Undo");
		menuItems(enable, (Frame)getParent(), true);
	}

	public void waitForClick()
	/* disables buttons and menus so that user must click on another
	   line to apply the selected rule (e.g. for ^I) */
	{	
		btnApplyRule.disable();
		btnUndo.disable();
		Vector disable = new Vector();
		disable.addElement("New Proof");
		disable.addElement("Load Proof");
		disable.addElement("Save Proof");
		disable.addElement("Save Proof As...");
		disable.addElement("Print Proof");
		disable.addElement("Save As Theorem");
		disable.addElement("Quit New Pandora");
		disable.addElement("Global Tables...");
		disable.addElement("Undo");
		disable.addElement("Clear Box");
		disable.addElement("Kill Box");
		disable.addElement("Apply Theorem");
		disable.addElement("Add Given");
		disable.addElement("What Now?");
		menuItems(disable, (Frame)getParent(), false);

		if ((!(currRule.equals("KillBox"))) &&
			(!(currRule.equals("ClearBox"))))
		{
			functs.add(btnCancelRule);
			validate();
		}

		currClick = 0;
		clickStatus = 1;
		pArea.requestFocus();
		
	}

	public void returnFromClicked()
	/* enables buttons and menus after lines have been chosen by
	   the user */
	{
		btnApplyRule.enable();
		if (!(undoStack.empty()))
		{
			btnUndo.enable();
		}
		Vector enable = new Vector();
		enable.addElement("New Proof");
		if (isStandAlone)
		/* only enable the following if running stand-alone */
		{
			enable.addElement("Load Proof");
			enable.addElement("Save Proof");
			enable.addElement("Save Proof As...");
			enable.addElement("Print Proof");
			enable.addElement("Quit New Pandora");
			enable.addElement("Apply Theorem");
		}
		enable.addElement("Global Tables...");
		if (!(undoStack.empty()))
		{
			enable.addElement("Undo");
		}
		enable.addElement("Clear Box");
		enable.addElement("Kill Box");
		enable.addElement("Add Given");
		enable.addElement("What Now?");
		menuItems(enable, (Frame)getParent(), true);

		clickStatus = 2;

		/* remove the cancel button if it's there */
		if ((!(currRule.equals("KillBox"))) &&
			(!(currRule.equals("ClearBox"))))
		{
			functs.remove(btnCancelRule);
			validate();
		}

		/* check if also need to remove data entry text box - this
		   is only if the user clicked Cancel in the middle of
		   applying a rule */
		Component[] cArray = topSub.getComponents();
		if (cArray.length == 2)
		/* if data entry is there */
		{
			topSub.remove(input);
			validate();
		}
	}

	public void appRule(String rule)
	/* tries to apply rule to the currently selected line */
	{
		/* first check whether a rule has already been applied to 
		   the current line */
		if (currLine.getRef().equals("Given"))
		/* cannot directly apply a rule to an assumption */
		{
			appMsg.setText("Cannot directly apply a rule to an assumption.\n");
			appMsg.appendText("Please choose another line.");
		}
		else if (!(currLine.getRuleAppliedTo().equals("")) &&
		   (!(rule.equals("Trust Me!"))))
		{
			appMsg.setText("A rule has already been applied to this line!");
		}
		else
		{
			/* if And Introduction */
			if (rule.equals("And Introduction"))
			{
				if (currLine.canAnd())
				/* if applicable for backwards */
				{
					if (currLine.isCurrentGoal())
					/* if used backwards */
					{
						andIntroBack(currLine);
					}
					else
					{
						appMsg.setText("Cannot use And Introduction with the current line!");
					}					
				}
				else if (currLine.isEmpty())
				/* if applicable for forwards */
				{
					andIntroFor(currLine);
				}
				else
				/* not applicable at all */
				{
					appMsg.setText("Cannot use And Introduction with the current line!");
				}
			}
			else if (rule.equals("Or Elimination"))
			{
				if (currLine.isEmpty())
				/* if applicable */
				{
					/* cannot apply rule if there is already a sub-box
					   for the current box */
					ContextTree thisCont = currLine.getContext();
					if (thisCont.numChildren() == 0)
					{
						orElim(currLine);
					}
					else
					{
						appMsg.setText("Cannot apply rule in the context of the current line, ");
						appMsg.appendText("since this context already has sub-boxes in it!\n");
						appMsg.appendText("If you still want to apply this rule, you");
						appMsg.appendText(" must clear this context first.");
					}
				}
				else
				{
					appMsg.setText("The current line must be empty for this rule.");
				}
			}
			else if (rule.equals("Or Introduction"))
			{
				if (currLine.isEmpty())
				/* if forwards */
				{
					orIntroFor(currLine);
				}
				else if ((currLine.isCurrentGoal()) && (currLine.canOr()))
				/* if backwards */
				{
					orIntroBack(currLine);
				}
				else
				{
					appMsg.setText("Cannot use Or Introduction with the current line");
				}
			}
			else if (rule.equals("And Elimination"))
			{
				if (currLine.isEmpty())
				/* if applicable (only forwards) */
				{
					andElim(currLine);		
				}
				else
				{
					appMsg.setText("The current line must be empty for this rule.");
				}
			}
			else if (rule.equals("Arrow Introduction"))
			{
				if ((currLine.canArrow()) && (currLine.isCurrentGoal()))
				/* if applicable */
				{
					arrowIntro(currLine);
				}
				else
				/* not applicable at all */
				{
					appMsg.setText("Cannot use Arrow Introduction with the current line!");
				}					
			}
			else if (rule.equals("Arrow Elimination"))
			{
				if (currLine.isCurrentGoal())
				/* if used backwards */
				{
					arrowElimBack(currLine);
				}
				else if (currLine.isEmpty())
				/* if applicable for forwards */
				{
					arrowElimFor(currLine);
				}
				else
				/* not applicable at all */
				{
					appMsg.setText("Cannot use Arrow Elimination with the current line!");
				}
			}
			else if (rule.equals("Not Elimination"))
			{
				if ((currLine.isCurrentGoal()) &&
				   (currLine.getExpr().strContents().equals("false")))
				/* if used backwards */
				{
					notElimBack(currLine);
				}
				else if (currLine.isEmpty())
				/* if applicable for forwards */
				{
					notElimFor(currLine);
				}
				else
				/* not applicable at all */
				{
					appMsg.setText("Cannot use Not Elimination with the current line!");
				}
			}
			else if (rule.equals("Not Introduction"))
			{
				if ((currLine.canNot()) && (currLine.isCurrentGoal()))
				/* if applicable */
				{
					notIntro(currLine);
				}
				else
				/* not applicable at all */
				{
					appMsg.setText("Cannot use Not Introduction with the current line!");
				}					
			}
			else if (rule.equals("Not-Not (~~)"))
			{
				if (currLine.isEmpty())
				/* only applicable forwards */
				{
					notNot(currLine);
				}
				else
				/* not applicable */
				{
					appMsg.setText("The current line must be empty for this rule.");
				}
			}
			else if (rule.equals("If-And-Only-If Introduction"))
			{
				if ((currLine.canIff()) && (currLine.isCurrentGoal()))
				/* if applicable */
				{
					iffIntro(currLine);
				}
				else
				/* if not applicable */
				{
					appMsg.setText("Cannot use If-And-Only-If Introduction with the current line!");
				}
			}
			else if (rule.equals("If-And-Only-If Elimination"))
			{
				if (currLine.isEmpty())
				/* can only use it forwards */
				{
					iffElim(currLine);
				}
				else
				{
					appMsg.setText("The current line must be empty for this rule.");
				}		
			}
			else if (rule.equals("If-And-Only-If Equiv"))
			{
				if (currLine.isEmpty())
				/* if used forwards */
				{
					iffEquivFor(currLine);
				}
				else if (currLine.isCurrentGoal())
				/* if used backwards */
				{
					iffEquivBack(currLine);
				}
				else
				{
					appMsg.setText("Cannot use If-And-Only-If Equiv with the current line!");
				}
			}
			else if (rule.equals("Bottom Elimination"))
			{
				if (currLine.isEmpty())
				/* if used forwards */
				{
					bottomElimFor(currLine);
				}
				else if (currLine.isCurrentGoal())
				/* if used backwards */
				{
					bottomElimBack(currLine);
				}
				else
				/* not applicable */
				{
					appMsg.setText("Cannot use Bottom Elimination with the current line!");
				}
			}
			else if (rule.equals("Trust Me!"))
			{
				if (!(currLine.isEmpty()))
				/* cannot be applied to an empty line or an assumption */
				{
					trustMe(currLine);
				}
				else
				{
					appMsg.setText("Cannot apply this rule to an empty line!");
				}
			}
			else if (rule.equals("Tick"))
			{
				if (!(currLine.isEmpty()))
				/* cannot be applied to an empty line */
				{
					tick(currLine);
				}
				else
				{
					appMsg.setText("Cannot apply this rule to an empty line!");
				}
			}
			else if (rule.equals("For-All Introduction"))
			{
				if ((currLine.canForAll()) && (currLine.isCurrentGoal()))
				/* if applicable */
				{
					forAllIntro(currLine);
				}
				else
				/* not applicable at all */
				{
					appMsg.setText("Cannot use For-All Introduction with the current line!");
				}					
			}
			else if (rule.equals("For-All Elimination"))
			{
				if (currLine.isEmpty())
				/* can only be used forwards */
				{
					/* must have constants available */
					ContextTree cont = currLine.getContext();
					if ((GlobalTables.constTable().isEmpty()) &&
					   (!(cont.localConstsAvail())))
					{
						appMsg.setText("Must have constants available for this rule!");
					}
					else
					{
						forAllElim(currLine);
					}
				}
				else
				{
					appMsg.setText("The current line must be empty for this rule.");
				}
			}
			else if (rule.equals("There-Exists Introduction"))
			{
				if ((currLine.isCurrentGoal()) &&
				   (currLine.canExists()))
				/* can only be used backwards */
				{
					/* must have constants available */
					ContextTree cont = currLine.getContext();
					if ((GlobalTables.constTable().isEmpty()) &&
					   (!(cont.localConstsAvail())))
					{
						appMsg.setText("Must have constants available for this rule!");
					}
					else
					{
						thereExistsIntro(currLine);
					}
				}
				else
				{
					appMsg.setText("Cannot use There-Exists Introduction with the current line!");
				}
			}
			else if (rule.equals("There-Exists Elimination"))
			{
				if (currLine.isEmpty())
				/* may only be used forwards */
				{
					/* cannot apply rule if there is already a sub-box
					   for the current box */
					ContextTree thisCont = currLine.getContext();
					if (thisCont.numChildren() == 0)
					{
						thereExistsElim(currLine);
					}
					else
					{
						appMsg.setText("Cannot apply rule in the context of the current line, ");
						appMsg.appendText("since this context already has sub-boxes in it!\n");
						appMsg.appendText("If you still want to apply this rule, you");
						appMsg.appendText(" must clear this context first.");
					}
				}
				else
				{
					appMsg.setText("The current line must be empty for this rule.");
				}
			}
			else if (rule.equals("Proof by Contradiction (PC)"))
			{
				if (currLine.isCurrentGoal())
				/* may only be used backwards from the goal */
				{
					proofByContradiction(currLine);
				}
				else
				{
					appMsg.setText("PC may only be used backwards from a goal!");
				}
			}
			else if (rule.equals("Eqsub (Equality substitution)"))
			{
				if (currLine.isCurrentGoal())
				/* if used backwards */
				{
					eqsubBack(currLine);
				}
				else if (currLine.isEmpty())
				/* if used forwards */
				{
					eqsubFor(currLine);
				}
				else
				{
					appMsg.setText("Cannot use Eqsub with the current line!");
				}
			}
			else if (rule.equals("Reflex (x = x)"))
			{
				if (currLine.isEmpty())
				/* can only be used forwards */
				{
					/* must have constants available */
					ContextTree cont = currLine.getContext();
					if ((GlobalTables.constTable().isEmpty()) &&
					   (!(cont.localConstsAvail())))
					{
						appMsg.setText("Must have constants available for this rule!");
					}
					else
					{
						reflex(currLine);
					}
				}
				else
				{
					appMsg.setText("The current line must be empty for this rule.");
				}
			}
			else if (rule.equals("Lemma"))
			{
				if (currLine.isCurrentGoal())
				/* if applicable */
				{
					lemma(currLine);
				}
				else
				/* not applicable at all */
				{
					appMsg.setText("Cannot use Lemma with the current line!");
				}					
			}
			else if (rule.equals("For-All Arrow Introduction"))
			{
				if ((currLine.canForAll()) && (currLine.isCurrentGoal()))
				/* if applicable */
				{
					forAllArrowIntro(currLine);
				}
				else
				/* not applicable at all */
				{
					appMsg.setText("Cannot use For-All Arrow Introduction with the current line!");
				}					
			}
		}

	}

}
