package NewPand;

/* this file contains the definition of the MainMenu class. This is
   the application's main menu. */

import java.awt.*;

public class MainMenu
{
	Frame   m_Frame        = null;
	boolean m_fInitialized = false;

	/* MenuBar definitions */
	MenuBar mb;

	/* Menu and Menu item definitions */
	Menu FileMenu;
	MenuItem File_NewProof;	
	MenuItem File_LoadProof;	
	MenuItem File_SaveProof;
	MenuItem File_SaveProofAs;
	MenuItem sep1;	
	MenuItem File_PrintProof;	
	MenuItem File_SaveTheorem;	
	MenuItem sep2;	
	MenuItem File_Quit;	
	Menu ViewMenu;	
	Menu View_GlobalTables;
	MenuItem View_GlobalTables_Constants;
	MenuItem View_GlobalTables_Variables;
	MenuItem View_GlobalTables_Predicates;
	MenuItem View_GlobalTables_Functions;
	Menu ActionMenu; 
	MenuItem Action_Undo; 
	MenuItem Action_ClearBox;
	MenuItem Action_KillBox;
	MenuItem sep3;
	MenuItem Action_AddGiven;
	MenuItem Action_ApplyTheorem;
	Menu HelpMenu;
	MenuItem Help_HelpNow;
	MenuItem sep4;
	MenuItem Help_Characters;
	MenuItem Help_UserGuide;

	
	public MainMenu (Frame frame)
	/* main constructor */
	{
		m_Frame = frame;
	}

	public boolean CreateMenu()
	/* initialisation */
	{
		/* Can only init controls once */
		if (m_fInitialized || m_Frame == null)
			return false;

		/* Create menubar */
		mb = new MenuBar();
		
		/* Create menu and menu items and assign to menubar */
		FileMenu = new Menu("File");
		mb.add(FileMenu);
		File_NewProof = new MenuItem("New Proof");
		FileMenu.add(File_NewProof);
		File_LoadProof = new MenuItem("Load Proof");
		FileMenu.add(File_LoadProof);
		File_SaveProof = new MenuItem("Save Proof");
		FileMenu.add(File_SaveProof);
		File_SaveProofAs = new MenuItem("Save Proof As...");
		FileMenu.add(File_SaveProofAs);
		sep1 = new MenuItem("-");
		FileMenu.add(sep1);
		File_PrintProof = new MenuItem("Print Proof");
		FileMenu.add(File_PrintProof);
		File_SaveTheorem = new MenuItem("Save As Theorem");
		FileMenu.add(File_SaveTheorem);
		sep2 = new MenuItem("-");
		FileMenu.add(sep2);
		File_Quit = new MenuItem("Quit New Pandora");
		FileMenu.add(File_Quit);
		ViewMenu = new Menu("View");
		mb.add(ViewMenu);		
		View_GlobalTables = new Menu("Global Tables...");
		ViewMenu.add(View_GlobalTables);
		View_GlobalTables_Constants = new MenuItem("Constants");
		View_GlobalTables.add(View_GlobalTables_Constants);
		View_GlobalTables_Variables = new MenuItem("Variables");
		View_GlobalTables.add(View_GlobalTables_Variables);
		View_GlobalTables_Predicates = new MenuItem("Predicates");
		View_GlobalTables.add(View_GlobalTables_Predicates);
		View_GlobalTables_Functions = new MenuItem("Functions");
		View_GlobalTables.add(View_GlobalTables_Functions);
		ActionMenu = new Menu("Action");
		mb.add(ActionMenu);
		Action_Undo = new MenuItem("Undo");
		ActionMenu.add(Action_Undo);
		Action_ClearBox = new MenuItem("Clear Box");
		ActionMenu.add(Action_ClearBox);
		Action_KillBox = new MenuItem("Kill Box");
		ActionMenu.add(Action_KillBox);
		sep3 = new MenuItem("-");
		ActionMenu.add(sep3);
		Action_AddGiven = new MenuItem("Add Given");
		ActionMenu.add(Action_AddGiven);
		Action_ApplyTheorem = new MenuItem("Apply Theorem");
		ActionMenu.add(Action_ApplyTheorem);
		HelpMenu = new Menu("Help");
		mb.add(HelpMenu);
		Help_HelpNow = new MenuItem("What Now?");
		HelpMenu.add(Help_HelpNow);
		sep4 = new MenuItem("-");
		HelpMenu.add(sep4);
		Help_Characters = new MenuItem("Characters");
		HelpMenu.add(Help_Characters);
		Help_UserGuide = new MenuItem("User Guide");
		HelpMenu.add(Help_UserGuide);
		
		/* attach menu bar to the frame */
		m_Frame.setMenuBar(mb);

		m_fInitialized = true;
		return true;
	}
}
