package NewPand;

/* This file contains the classes which read data
   (assumptions and conclusions) from the user and
   build expression trees from them.

   Included here are:
   
   ** Lexical Analyser
   ** Syntax Analyser (Tree builder)

*/

import java.io.*;
import java.util.*;

public class DataInput implements Serializable

{
	/* member variables */
	
	public final char[] tokenSymbolsArr = {'>', '~', '#', '^', '|', ')', '(', ']', '[', 'A', 'E', ',', '='};
	private final int tokenArrLength = 13;
	private Vector tokenSymbolsVec;
	private int currentToken;
	
	Vector varsInScope; /* for handling variables and scope */
	Vector scopeVarsNum;
	int currentVarsNum;
	
	int currentArity; /* for handling predicate and function arities */
	Vector arities;
	Vector predsAndFuns;
	String currentName; /* current function or predicate symbol */
		
	/* methods */

	DataInput()
	/* constructor */
	{
		/* initialise vector */
		tokenSymbolsVec = new Vector();
		for (int i = 0; i < tokenArrLength ; i++)
		{	tokenSymbolsVec.addElement(new Character(tokenSymbolsArr[i])); }
	}

	private Vector lexAnalyse(String in)
		throws InvalidTokenException, InvalidCharException, 
			   InvalidIdentException
	/* this method takes as input a stream of characters
	   and returns a vector (list) of tokens */
	{

		Vector tokens = new Vector(); /* the vector of tokens */
		Token currentToken = null; /* current token to be added */
		int currentChar = 0; /* points to the current character
							    being read */
		int inputLength = in.length();
		
		while (currentChar < in.length())
		{	
		    switch (in.charAt(currentChar))
			{
		   	  case '~' : /* not character */
						  currentToken = new Token("NotToken", "~");
						  break;
			  case '>' : /* implies character */
						  currentToken = new Token("ImpliesToken", ">");
						  break;
			  case '#' : /* iff character */
						  currentToken = new Token("IfAndOnlyIfToken", "#");
						  break;
			  case '^' : /* and character */
						  currentToken = new Token("AndToken", "^");
						  break;
			  case '|' :  /* or character */
						  currentToken = new Token("OrToken", "|");
						  break;
			  case 'A' : /* for all character */
						  currentToken = new Token("ForAllToken", "A");
						  break;
			  case 'E' : /* there exists character */
						  currentToken = new Token("ThereExistsToken", "E");
						  break;
			  case '(' : /* left bracket character */
						  currentToken = new Token("LeftBracketToken", "(");
						  break;
			  case ')' : /* right bracket character */
						  currentToken = new Token("RightBracketToken", ")");
						  break;
			  case '[' : /* left square bracket character */
						  currentToken = new Token("LeftSquareBracketToken", "[");
						  break;
			  case ']' : /* right square bracket character */
						  currentToken = new Token("RightSquareBracketToken", "]");
						  break;
			  case ',' : /* comma character */
						  currentToken = new Token("CommaToken", ",");
						  break;
			  case '=' : /* equals character */
						  currentToken = new Token("EqualsToken", "=");
			  case ' ' : /* space character - skip it */
						  currentChar++;
						  continue;
			  default  : /* any other character - must be an identifier */
						  StringBuffer ident = new StringBuffer();
						  while ((currentChar < in.length()) 
				  			  && (!(tokenSymbolsVec.contains(new Character(in.charAt(currentChar)))))
							  && (in.charAt(currentChar) != ' '))
						  {
							  if (!(Character.isLetterOrDigit(in.charAt(currentChar))))
							  {
								  throw (new InvalidCharException("Invalid character in input"));
							  }
							  else
							  {
								  ident.append(in.charAt(currentChar));
								  currentChar++;
							  }
						  }
						  String s = new String(ident);
						  /* check identifier */
						  checkIdent(s);
						  currentToken = new Token("NameToken", s);
						  /* decrement character pointer so nothing will be missed */
						  currentChar--;
						  break;
										
			}
		  tokens.addElement(currentToken);
		  currentChar++;
		} 
		return(tokens);
	}

	private void checkIdent(String ident)
		throws InvalidIdentException
	/* this method checks that the input parameter is not an identifier
	   which starts with digits (and has character afterwards) */
	{ 
		/* if first character is a digit */
		if (Character.isDigit(ident.charAt(0)))
		{
			for (int i = 1; i < ident.length(); i++)
			{
				/* if found a letter - throw an exception */
				if (Character.isLetter(ident.charAt(i)))
				{
					throw (new InvalidIdentException("Invalid identifier in input"));
				}
			}
		}
	}

	public ExprTree syntaxAnalyse(String in)
		throws IOException, LexAnalyserException,
			   ParserException
	/* this method attempts to build a valid expression
	   tree from a logical expression entered by the user.
	   Uses a recursive-descent top-down parsing algorithm.
	 */
	{
		Vector tokens; /* a vector to hold the input tokens */
		
		/* use lexAnalyse to divide up the input into tokens */
		try
		{
			tokens = lexAnalyse(in);
		}
		catch (Exception e)
		{	
			throw (new LexAnalyserException(e.getMessage()));
		}
		
		if (tokens.size() > 0)
		{
			currentToken = 0;
			/* create new vectors for variables in scope */
			varsInScope = new Vector();
			scopeVarsNum = new Vector();
			currentVarsNum = 0;

			/* initialise arity variables */
			arities = new Vector();
			predsAndFuns = new Vector();

			/* start parsing and get abstract syntax tree */
			ExprTree ast = parseSentence(tokens);
						
			if (currentToken < (tokens.size() - 1))
			{
				System.out.println("Ignored garbage at the end");
			}

			return ast; /* return abstract syntax tree */
		}
		else 
		{
			throw (new ParserException("No tokens to process!"));
		}
	}

	private boolean noMoreTokens(Vector tokens)
	/* returns true iff 'tokens' has no more tokens to scan */
	{
		return (currentToken >= tokens.size());
	}

	private ExprTree parseSentence(Vector tokens)
		throws ParserException
	/* parses a sentence. Receives a vector of tokens.
	   Pre-condition : there are tokens to scan 
	   Post-condition : a 'Sentence' parsed; currentToken pointing to last token scanned.
	   Returns an expression tree representing 'Sentence' */
	{
		/* check if sentence starts with a quantifier */
		//if ((((Token)tokens.elementAt(currentToken)).getType().equals("ForAllToken"))
		//  || (((Token)tokens.elementAt(currentToken)).getType().equals("ThereExistsToken")))
		//{
		//	currentToken++;
		//	if ((noMoreTokens(tokens)) ||
		//	   (!(((Token)tokens.elementAt(currentToken)).getType().equals("NameToken"))))
		//	    
		//	{
		//		throw(new ParserException("A variable name is expected after every quantifier"));
		//	}
		//	
		//	/* perform checking on the variable */
		//	checkVar(((Token)tokens.elementAt(currentToken)).getValue());
		//	
		//	/* build the tree */
		//	ExprTreeValue val = new ExprTreeValue("Quant", 
		//						  ((Token)tokens.elementAt(currentToken-1)).getValue(),
		//						  ((Token)tokens.elementAt(currentToken)).getValue());
		//	ExprTree tree = new ExprTree(val);
		//
		//	currentToken++;
		//	if (noMoreTokens(tokens))
		//	{
		//		throw(new ParserException("Premature end of input: sub-expression [...] or more quantifiers expected"));
		//	}
		//	
		//	/* get the sub-tree */
		//	ExprTree subtree = parseMoreQuants(tokens);
		//	/* link sub-tree */
		//	tree.setRightChild(subtree);
		//	/* return the tree */
		//	return tree;
		//}
		/* otherwise parse an expression */
		//else
		//{
			return (parseExp1(tokens));
		//}
	}

	private ExprTree parseMoreQuants(Vector tokens)
		throws ParserException
	/* parses a 'MoreQuants' non-terminal symbol. Receives a vector of tokens.
	   Pre-condition: there are tokens to scan
	   Post-condition: a 'MoreQuants' parsed; currentToken pointing to last token scanned.
	   Returns an expression tree representing 'MoreQuants' */
	{
		/* check if there are more quantifiers */
		if ((((Token)tokens.elementAt(currentToken)).getType().equals("ForAllToken"))
		   || (((Token)tokens.elementAt(currentToken)).getType().equals("ThereExistsToken")))
		{
			currentToken++;
			if ((noMoreTokens(tokens)) ||
 		       (!(((Token)tokens.elementAt(currentToken)).getType().equals("NameToken"))))  
			{
				throw(new ParserException("A variable name is expected after every quantifier"));
			}

			/* perform checking on the variable */
			checkVar(((Token)tokens.elementAt(currentToken)).getValue());

			/* build the tree */
			ExprTreeValue val = new ExprTreeValue("Quant", 
								  ((Token)tokens.elementAt(currentToken-1)).getValue(),
								  ((Token)tokens.elementAt(currentToken)).getValue());
			ExprTree tree = new ExprTree(val);

			currentToken++;
			if (noMoreTokens(tokens))
			{
				throw(new ParserException("Premature end of input: sub-expression [...] or more quantifiers expected"));
			}
			
			/* get the sub-tree */
			ExprTree subtree = parseMoreQuants(tokens);
			/* link sub-tree */
			tree.setRightChild(subtree);
			/* return the tree */
			return tree;
		}
		else
		{
			/* check for opening square brackets */
			if (!(((Token)tokens.elementAt(currentToken)).getType().equals("LeftSquareBracketToken")))
			{
				throw(new ParserException("'[' expected after quantifier list"));
			}
			
			/* update scope variables Vector */
			scopeVarsNum.addElement(new Integer(currentVarsNum));
			/* re-initialise currentVarsNum */
			currentVarsNum = 0;

			currentToken++;
			if (noMoreTokens(tokens))
			{
				throw(new ParserException("Premature end of input: sub-expression expected after '['"));
			}
			
			/* parse sub-expression */
			ExprTree tree = parseExp1(tokens);
			currentToken++;
			if ((noMoreTokens(tokens)) ||
 			   (!(((Token)tokens.elementAt(currentToken)).getType().equals("RightSquareBracketToken"))))
			{
				throw(new ParserException("Expected ']' after quantified sub-expression"));
			}
			
			/* remove the current scope variables */
			for (int i = 0; i < ((Integer)scopeVarsNum.lastElement()).intValue(); i++)
			{
				varsInScope.removeElement(varsInScope.lastElement());
			}
			scopeVarsNum.removeElement(scopeVarsNum.lastElement());

			return tree;
		}
	}

	private ExprTree parseExp1(Vector tokens)
		throws ParserException
	/* parses an 'Exp1' non-terminal symbol. Receives a vector of tokens.
	   Pre-condition: there are tokens to scan
	   Post-condition: an 'Exp1' parsed; currentToken pointing to last token scanned.
	   Returns an expression tree representing 'Exp1' */
	{	
		/* parse an 'Exp2' */
		ExprTree tree1 = parseExp2(tokens);
		currentToken++;
		if (!(noMoreTokens(tokens)))
		{
			/* parse Exp1` */
			ExprTree tree2 = parseExp1Prime(tokens);
			/* if Exp1` consists of IfAndOnlyIf or Implies */
			if (((ExprTreeValue)tree2.getValue()).getType() == "Op1")
			{
				/* link the trees */
				tree2.setLeftChild(tree1);
				/* return the main tree */
				return tree2;
			}
			else
			{
				/* return the current tree */
				return tree1;
			}
		}
		else
		{
			--currentToken;
			/* return the tree */
			return tree1;
		}
	}

	private ExprTree parseExp1Prime(Vector tokens)
		throws ParserException
	/* parses an 'Exp1`' non-terminal symbol. Receives a vector of tokens.
	   Pre-condition: there are tokens to scan
	   Post-condition: an 'Exp1`' parsed; currentToken pointing to last token scanned.
	   Returns an expression tree representing 'Exp1`' */
	{		
		/* check for a '>' or '#' */
		if ((((Token)tokens.elementAt(currentToken)).getType().equals("ImpliesToken"))
		   || (((Token)tokens.elementAt(currentToken)).getType().equals("IfAndOnlyIfToken")))
		{
			/* build the tree */
			ExprTreeValue val = new ExprTreeValue("Op1",
								  ((Token)tokens.elementAt(currentToken)).getValue());
			ExprTree tree1 = new ExprTree(val);

			currentToken++;
			if (noMoreTokens(tokens))
			{
				throw(new ParserException("Expected an operand after an '>' or '#'"));
			}

			/* parse another Exp1 */
			ExprTree tree2 = parseExp1(tokens);
			tree1.setRightChild(tree2);
			return tree1;
		}
		else
		/* the empty branch */
		{
			--currentToken;
			/* return an empty tree */
			return (new ExprTree());
		}
	}

	private ExprTree parseExp2(Vector tokens)
		throws ParserException
	/* parses an 'Exp2' non-terminal symbol. Receives a vector of tokens.
	   Pre-condition: there are tokens to scan
	   Post-condition: an 'Exp2' parsed; currentToken pointing to last token scanned.
	   Returns an expression tree representing 'Exp2' */
	{
		/* parse an 'Exp3' */
		ExprTree tree1 = parseExp3(tokens);

		currentToken++;
		if (!(noMoreTokens(tokens)))
		{
			/* parse an Exp2` */
			ExprTree tree2 = parseExp2Prime(tokens);
			/* if Exp2` consists of And or Or */
			if (((ExprTreeValue)tree2.getValue()).getType() == "Op2")
			{
				/* link the trees */
				tree2.setLeftChild(tree1);
				/* return the main tree */
				return tree2;
			}
			else
			{
				/* return the current tree */
				return tree1;
			}
		}
		else
		{
			--currentToken;
			/* return the tree */
			return tree1;
		}
	}

	private ExprTree parseExp2Prime(Vector tokens)
		throws ParserException
	/* parses an 'Exp2`' non-terminal symbol. Receives a vector of tokens.
	   Pre-condition: there are tokens to scan
	   Post-condition: a 'Exp2`' parsed; currentToken pointing to last token scanned.
	   Returns an expression tree representing 'Exp2`' */
	{
		/* check for a '|' or '^' */
		if ((((Token)tokens.elementAt(currentToken)).getType().equals("OrToken"))
		   || (((Token)tokens.elementAt(currentToken)).getType().equals("AndToken")))
		{
			/* build the tree */
			ExprTreeValue val = new ExprTreeValue("Op2",
								  ((Token)tokens.elementAt(currentToken)).getValue());
			ExprTree tree1 = new ExprTree(val);
			
			currentToken++;
			if (noMoreTokens(tokens))
			{
				throw(new ParserException("Expected an operand after an '|' or '^'"));
			}

			/* parse another Exp3 */
			ExprTree tree2 = parseExp3(tokens);

			currentToken++;
			if (noMoreTokens(tokens))
			{
				--currentToken;
				/* link the trees and return the main tree */
				tree1.setRightChild(tree2);
			}
			else
			{
				/* parse an Exp2` */
				ExprTree tree3 = parseExp2Prime(tokens);
				/* if Exp2` consists of And or Or */
				if (((ExprTreeValue)tree3.getValue()).getType() == "Op2")
				{
					/* link trees */
					tree3.setLeftChild(tree2);
					tree1.setRightChild(tree3);
				}
				else
				{
					/* link trees */
					tree1.setRightChild(tree2);
				}
			}
			return tree1;
		}
		else
		/* the empty branch */
		{
			--currentToken;
			/* return an empty tree */
			return (new ExprTree());
		}
	}

	private ExprTree parseExp3(Vector tokens)
		throws ParserException
	/* parses an 'Exp3' non-terminal symbol. Receives a vector of tokens.
	   Pre-condition: there are tokens to scan
	   Post-condition: an 'Exp3' parsed; currentToken pointing to last token scanned.
	   Returns an expression tree representing 'Exp3' */	
	{
		if (((Token)tokens.elementAt(currentToken)).getType().equals("NotToken"))
		/* if we have a 'Not' expression */
		{
			/* build the tree */
			ExprTreeValue v = new ExprTreeValue("Op3","~");
			ExprTree tree = new ExprTree(v);
			
			currentToken++;
			if (noMoreTokens(tokens))
			{
				throw(new ParserException("a '~' must be followed by an expression"));
			}

			/* get the sub-tree */
			ExprTree subtree = parseExp3(tokens);
			/* link the sub-tree */
			tree.setRightChild(subtree);
			/* return the tree */
			return tree;
		}
		/* otherwise check if we have 'Quant Var MoreQuants' */
		else if ((((Token)tokens.elementAt(currentToken)).getType().equals("ForAllToken"))
			    || (((Token)tokens.elementAt(currentToken)).getType().equals("ThereExistsToken")))
		{
			currentToken++;
			if ((noMoreTokens(tokens)) ||
			   (!(((Token)tokens.elementAt(currentToken)).getType().equals("NameToken"))))
			{
				throw(new ParserException("A variable name is expected after every quantifier"));
			}

			/* perform checking on the variable */
			checkVar(((Token)tokens.elementAt(currentToken)).getValue());
			
			/* build the tree */
			ExprTreeValue val = new ExprTreeValue("Quant", 
								  ((Token)tokens.elementAt(currentToken-1)).getValue(),
								  ((Token)tokens.elementAt(currentToken)).getValue());
			ExprTree tree = new ExprTree(val);

			currentToken++;
			if (noMoreTokens(tokens))
			{
				throw(new ParserException("Premature end of input: sub-expression [...] or more quantifiers expected"));
			}

			/* get the sub-tree */
			ExprTree subtree = parseMoreQuants(tokens);
			/* link sub-tree */
			tree.setRightChild(subtree);
			/* return the tree */
			return tree;
		}
		else if (((Token)tokens.elementAt(currentToken)).getType().equals("LeftBracketToken"))
		/* otherwise check if we have a '(Sentence)' */
		{
			currentToken++;
			if (noMoreTokens(tokens))
			{
				throw(new ParserException("A left bracket must be followed by a sentence"));
			}

			/* parse the sentence */
			ExprTree tree = parseSentence(tokens);

			currentToken++;
			if ((noMoreTokens(tokens)) ||
			   (!(((Token)tokens.elementAt(currentToken)).getType().equals("RightBracketToken"))))
			{
				throw(new ParserException("An open bracket without a matching close bracket"));
			}

			/* return the tree */
			return tree;
		}
		/* otherwise, must be an atom */
		else if (((Token)tokens.elementAt(currentToken)).getType().equals("NameToken"))
		{
			/* record current token position */
			int temp = currentToken;
			parseAtom(tokens);
			StringBuffer theAtom = new StringBuffer("");
			for (int i = temp; i <= currentToken; i++)
			{
				theAtom.append(((Token)tokens.elementAt(i)).getValue());
			}
			ExprTreeValue val = new ExprTreeValue("Atom", theAtom.toString());
			ExprTree tree = new ExprTree(val);
			return tree;
		}
		/* otherwise, report an error */
		else
		{
			throw(new ParserException("Expecting either a '~','(', quantified expression, or an atom, but got a different token"));
		}			
	}

	private void parseAtom(Vector tokens)
		throws ParserException
	/* parses an 'Atom' non-terminal symbol. Receives a vector of tokens.
	   Pre-condition: there are tokens to scan
	   Post-condition: an 'Atom' parsed; currentToken pointing to last token scanned */
	{
		/* an atom must start with a name */
		if (!(((Token)tokens.elementAt(currentToken)).getType().equals("NameToken")))
		{
			throw(new ParserException("Expected a predicate but got a different token"));
		}
		
		String pred = ((Token)tokens.elementAt(currentToken)).getValue();
		currentToken++;
		if (!(noMoreTokens(tokens)))
		{
			currentName = pred;
			currentArity = 0; /* initialise arity accumulator */
			parseAtomPrime(tokens);
		}
		else /* a proposition */
		{
			checkAtom(pred, 0); /* perform some checks on 0-arity atom */
			--currentToken;
		}
	}

	private void parseAtomPrime(Vector tokens)
		throws ParserException
	/* parses an 'Atom`' non-terminal symbol. Receives a vector of tokens.
	   Pre-condition: there are tokens to scan
	   Post-condition: an 'Atom`' parsed; currentToken pointing to last token scanned */
	{
		/* if left bracket, then we have a n-ary predicate, n>=1 */
		if (((Token)tokens.elementAt(currentToken)).getType().equals("LeftBracketToken"))
		{
			currentToken++;
			if (noMoreTokens(tokens))
			{
				throw(new ParserException("A left bracket must be followed by some arguments"));
			}

			/* parse the arguments */
			parseArgs(tokens);
			currentToken++;
			if ((noMoreTokens(tokens)) ||
			   (!(((Token)tokens.elementAt(currentToken)).getType().equals("RightBracketToken"))))
			{
				throw(new ParserException("An open bracket without a matching close bracket"));
			}
			else
			{
				checkAtom(currentName, currentArity);
			}
		}
		else
		/* the empty branch - a proposition */
		{
			checkAtom(currentName, currentArity); /* perform some checks on 0-arity atom */
			--currentToken;
		}
	}

	private void parseArgs(Vector tokens)
		throws ParserException
	/* parses an 'Args' non-terminal symbol. Receives a vector of tokens.
	   Pre-condition: there are tokens to scan
	   Post-condition: an 'Args' parsed; currentToken pointing to last token scanned */
	{
		/* parse the first argument */
		parseArg(tokens);
		currentToken++;
		if (!(noMoreTokens(tokens)))
		{
			parseArgsPrime(tokens);
		}
		else
		{
			--currentToken;
		}

	}

	private void parseArgsPrime(Vector tokens)
		throws ParserException
	/* parses an 'Args`' non-terminal symbol. Receives a vector of tokens.
	   Pre-condition: there are tokens to scan
	   Post-condition: an 'Args`' parsed; currentToken pointing to last token scanned */
	{
		/* check for a ',' */
		if (((Token)tokens.elementAt(currentToken)).getType().equals("CommaToken"))
		{
			currentToken++;
			if (noMoreTokens(tokens))
			{
				throw(new ParserException("Expected another argument after ','"));
			}

			/* parse another Args */
			parseArgs(tokens);
		}
		else
		/* the empty branch */
		{
			--currentToken;
		}
	}

	private void parseArg(Vector tokens)
		throws ParserException
	/* parses an 'Arg' non-terminal symbol. Receives a vector of tokens.
	   Pre-condition: there are tokens to scan
	   Post-condition: an 'Arg' parsed; currentToken pointing to last token scanned */
	{
		/* an argument must start with a name */
		if (!(((Token)tokens.elementAt(currentToken)).getType().equals("NameToken")))
		{
			throw(new ParserException("Expected a variable/constant/function but got a different token"));
		}
		
		currentArity++; /* increment arity counter */

		currentToken++;
		if (!(noMoreTokens(tokens)))
		{
			parseArgPrime(tokens);
		}
		else
		{
			--currentToken;
		}
	}

	private void parseArgPrime(Vector tokens)
		throws ParserException
	/* parses an 'Arg`' non-terminal symbol. Receives a vector of tokens.
	   Pre-condition: there are tokens to scan
	   Post-condition: an 'Arg`' parsed; currentToken pointing to last token scanned */
	{
		/* if left bracket, then we have a function */
		if (((Token)tokens.elementAt(currentToken)).getType().equals("LeftBracketToken"))
		{
			currentToken++;
			if (noMoreTokens(tokens))
			{
				throw(new ParserException("A left bracket must be followed by some arguments"));
			}

			/* update arity vectors */
			predsAndFuns.addElement(currentName);
			arities.addElement(new Integer(currentArity));

			/* re-initialise arity variables */
			currentName = ((Token)tokens.elementAt(currentToken - 2)).getValue();
			currentArity = 0;

			/* parse the arguments */
			parseArgs(tokens);
			currentToken++;
			if ((noMoreTokens(tokens)) ||
			   (!(((Token)tokens.elementAt(currentToken)).getType().equals("RightBracketToken"))))
			{
				throw(new ParserException("An open bracket without a matching close bracket"));
			}
			else
			{
				/* perform checks on functor */
				checkFunct(currentName, currentArity);
				/* update arity variables */
				currentName = (String)predsAndFuns.lastElement();
				currentArity = ((Integer)arities.lastElement()).intValue();
				predsAndFuns.removeElement(currentName);
				arities.removeElement((Integer)arities.lastElement());
			}
		}	
		else
		/* the empty branch - we have either a constant or a variable */
		{
			--currentToken;
			String val = ((Token)tokens.elementAt(currentToken)).getValue();
			if (!(varsInScope.contains(val))) /* if we have a constant */
			{
				checkConst(val); /* perform some checks */
			}
			/* if it's a variable, checks must have been performed upon
			   declaration */
		}
	}

	private void checkAtom(String pred, int arity)
		throws ParserException
	/* checks if name is already used as variable/constant/functor;
	   if everything ok then introduce predicate if necessary */
	{
		if (pred.startsWith("sk"))
		/* must not start a predicate with "sk" - only used for
		   new local constants */
		{
			throw (new ParserException("A predicate name cannot begin with 'sk'"));
		}
		else if ((GlobalTables.varTable().containsKey(pred))
		   || (GlobalTables.tempVarList().containsKey(pred)))
		{
			throw(new ParserException("Cannot use "+pred+" both as a variable and as a predicate"));
		}
		else if ((GlobalTables.constTable().containsKey(pred))
			    || (GlobalTables.tempConstList().containsKey(pred)))
		{
			throw(new ParserException("Cannot use "+pred+" both as a constant and as a predicate"));
		}
		else if ((GlobalTables.functTable().containsKey(pred))
			    || (GlobalTables.tempFunctList().containsKey(pred)))
		{
			throw(new ParserException("Cannot use "+pred+" both as a function and as a predicate"));
		}
		else if ((GlobalTables.tempPredList().containsKey(pred)))
		{
			int storedArity = ((Integer)GlobalTables.tempPredList().get(pred)).intValue();
			if (storedArity != arity) /* if already in different arity */
			{
				throw(new ParserException(pred+" cannot have two distinct arities"));
			}
		}
		else if ((GlobalTables.predTable().containsKey(pred)))
		{
			int storedArity = ((Integer)GlobalTables.predTable().get(pred)).intValue();
			if (storedArity != arity) /* if already in different arities */
			{
				throw(new ParserException(pred+" cannot have two distinct arities"));
			}
		}
		else if (Character.isDigit(pred.charAt(0)))
		{
			throw(new ParserException(pred+" is an invalid predicate"));
		}
		else
		{
			GlobalTables.appendToTempPredList(pred, new Integer(arity));
		}
	}

	private void checkVar(String var)
		throws ParserException
	/* checks if name is already used as predicate/constant/functor or
	   if variable is not already used in current scope;
	   adds to scope if everything goes ok. Also introduces variable
	   name if necessary */
	{
		if (var.startsWith("sk"))
		/* must not start a variable with "sk" - only used for
		   new local constants */
		{
			throw (new ParserException("A variable name cannot begin with 'sk'"));
		}
		else if ((GlobalTables.predTable().containsKey(var))
		   || (GlobalTables.tempPredList().containsKey(var)))
		{
			throw(new ParserException("Cannot use "+var+" both as a predicate and as a variable"));
		}
		else if ((GlobalTables.constTable().containsKey(var))
			    || (GlobalTables.tempConstList().containsKey(var)))
		{
			throw(new ParserException("Cannot use "+var+" both as a constant and as a variable"));
		}
		else if ((GlobalTables.functTable().containsKey(var))
			    || (GlobalTables.tempFunctList().containsKey(var)))
		{
			throw(new ParserException("Cannot use "+var+" both as a function and as a variable"));
		}
		/* check that variable is not already in scope */
		else if (varsInScope.contains(var))
		{
			throw(new ParserException(var+" is re-used but it is already in scope"));
		}
		else if (Character.isDigit(var.charAt(0)))
		{
			throw(new ParserException(var+" is an invalid variable"));
		}
		else 
		/* if not - mark the new one in scope and add to global table if necessary*/
		{
			varsInScope.addElement(var);
			currentVarsNum++;
			if ((!(GlobalTables.tempVarList().containsKey(var)))
			   && (!(GlobalTables.varTable().containsKey(var))))
			{
				GlobalTables.appendToTempVarList(var, new Integer(0));
			}
		}

	}

	private void checkConst(String constant)
		throws ParserException
	/* checks if name is already used as variable/predicate/functor;
	   if everything ok then introduce constant if necessary */
	{
		if ((GlobalTables.varTable().containsKey(constant))
		   || (GlobalTables.tempVarList().containsKey(constant)))
		{
			throw(new ParserException("Cannot use "+constant+" both as a variable and as a constant"));
		}
		else if ((GlobalTables.predTable().containsKey(constant))
			    || (GlobalTables.tempPredList().containsKey(constant)))
		{
			throw(new ParserException("Cannot use "+constant+" both as a predicate and as a constant"));
		}
		else if ((GlobalTables.functTable().containsKey(constant))
			    || (GlobalTables.tempFunctList().containsKey(constant)))
		{
			throw(new ParserException("Cannot use "+constant+" both as a function and as a constant"));
		}
		else if ((!(GlobalTables.tempConstList().containsKey(constant)))
			    && (!(GlobalTables.constTable().containsKey(constant))))
		{
			GlobalTables.appendToTempConstList(constant, new Integer(0));
		}
	}

	private void checkFunct(String funct, int arity)
			throws ParserException
	/* checks if name is already used as variable/predicate/constant;
	   if everything ok then introduce functors if necessary */
	{
		if (funct.startsWith("sk"))
		/* must not start a function with "sk" - only used for
		   new local constants */
		{
			throw (new ParserException("A function symbol cannot begin with 'sk'"));
		}
		else if ((GlobalTables.varTable().containsKey(funct))
		   || (GlobalTables.tempVarList().containsKey(funct)))
		{
			throw(new ParserException("Cannot use "+funct+" both as a variable and as a function"));
		}
		else if ((GlobalTables.predTable().containsKey(funct))
			    || (GlobalTables.tempPredList().containsKey(funct)))
		{
			throw(new ParserException("Cannot use "+funct+" both as a predicate and as a function"));
		}
		else if ((GlobalTables.constTable().containsKey(funct))
			    || (GlobalTables.tempConstList().containsKey(funct)))
		{
			throw(new ParserException("Cannot use "+funct+" both as a constant and as a function"));
		}
		else if ((GlobalTables.tempFunctList().containsKey(funct)))
		{
			int storedArity = ((Integer)GlobalTables.tempFunctList().get(funct)).intValue();
			if (storedArity != arity) /* if already in different arity */
			{
				throw(new ParserException(funct+" cannot have two distinct arities"));
			}
		}
		else if ((GlobalTables.functTable().containsKey(funct)))
		{
			int storedArity = ((Integer)GlobalTables.functTable().get(funct)).intValue();
			if (storedArity != arity) /* if already in different arities */
			{
				throw(new ParserException(funct+" cannot have two distinct arities"));
			}
		}
		else if (Character.isDigit(funct.charAt(0)))
		{
			throw(new ParserException(funct+" is an invalid function symbol"));
		}
		else
		{
			GlobalTables.appendToTempFunctList(funct, new Integer(arity));
		}

	}

}

class Token
/* this is a definition of the Token class */
{

	/* member variables */
	
	String tokenType;
	/* to store the token type.
	   
	   NOTE: 
	   'tokenType' must take one of the following values:
	   
	   ForAllToken - a for-all quantifier
	   ThereExistsToken - a there-exists quantifier
	   NameToken - an identifier (e.g. a variable, a predicate, etc.)
	   ImpliesToken - an implication symbol (->, or > currently)
	   IfAndOnlyIfToken - an iff symbol(<->, or # currently)
	   OrToken - an or symbol (currently |)
	   AndToken - an and symbol (currently ^)
	   NotToken - a not symbol (currently ~)
	   LeftBracketToken - a left bracket '('
	   RightBracketToken - a right bracket ')'
	   LeftSquareBracketToken = a left square bracket '['
	   RightSquareBracketToken = a right square bracket ']'
	   CommaToken = a comma ','
	   EqualsToken = an equals sign '='

	*/

	String tokenValue;
	/* to store the token value (for NameToken only) */

	/* methods */
	Token(String tType, String tValue)
		throws InvalidTokenException
	/* constructor */
	{
		/* make sure the token type is valid - otherwise throw an exception */
		if ((tType.equals("ForAllToken")) || (tType.equals("ThereExistsToken"))
			|| (tType.equals("NameToken")) || (tType.equals("ImpliesToken"))
			|| (tType.equals("IfAndOnlyIfToken"))
			|| (tType.equals("OrToken")) || (tType.equals("AndToken"))
			|| (tType.equals("NotToken")) || (tType.equals("LeftBracketToken"))
			|| (tType.equals("RightBracketToken")) || (tType.equals("LeftSquareBracketToken"))
			|| (tType.equals("RightSquareBracketToken")) || (tType.equals("CommaToken"))
			|| (tType.equals("EqualsToken")))
		{   /* initialise member variables */
			tokenType = tType;
			tokenValue = tValue;
		}
		else
		{ 
			throw (new InvalidTokenException("Cannot create token - Invalid type"));
		}
	}

	public String getType()
	/* returns the token type */
	{
		return tokenType;
	}

	public String getValue()
	/* returns the token value */
	{
		return tokenValue;
	}

}