package NewPand;

/* this file defines the class the representing the dialog box
   which appears when the user wants to start a new proof or load
   another proof */

import java.awt.*;

public class ConfirmDlg extends Dialog
{

	/* member variables */

	NewPandora myApp; /* the applet class that created this dialog */
	Label msg; /* the message appearing in the dialog box */
	
	/* the dialog buttons */
	Button save, noSave, cancel;


	/* methods */

	ConfirmDlg(Frame parent, NewPandora app)
	/* constructor */
	{
		super(parent, "Action Confirmation", true);
		myApp = app;
	}

	public void initialiseWithoutSave()
	/* called for initialisation of dialog box without
	   the saving option */
	{
		setLayout(new BorderLayout());
		Panel top = new Panel();
		Panel bottom = new Panel();
		top.setLayout(new FlowLayout());
		bottom.setLayout(new FlowLayout(FlowLayout.CENTER));
		msg = new Label("This will terminate the current proof!");
		Font f1 = new Font("Helvetica", Font.BOLD, 12);
		msg.setFont(f1);
		top.add(msg);
		noSave = new Button("Proceed");
		cancel = new Button("Cancel");
		bottom.add(noSave);
		bottom.add(cancel);
		add("North", top);
		add("Center", bottom);
		setBackground(Color.lightGray);
		pack();
		setResizable(false);
	}

	public void initialiseWithSave()
	/* called for initialisation of dialog box with the
	   saving option */
	{
		setLayout(new BorderLayout());
		Panel top = new Panel();
		Panel bottom = new Panel();
		top.setLayout(new FlowLayout());
		bottom.setLayout(new FlowLayout(FlowLayout.CENTER));
		msg = new Label("This will terminate the current proof!");
		Font f1 = new Font("Helvetica", Font.BOLD, 12);
		msg.setFont(f1);
		top.add(msg);
		save = new Button("Save and Proceed");
		noSave = new Button("Proceed without saving");
		cancel = new Button("Cancel");
		bottom.add(save);
		bottom.add(noSave);
		bottom.add(cancel);
		add("North", top);
		add("Center", bottom);
		setBackground(Color.lightGray);
		pack();
		setResizable(false);
	}

	public boolean action(Event evt, Object target)
	/* to handle the button events */
	{
		if (evt.target == save)
		{
			dispose();
			boolean success = myApp.saveProof();
			if (success)
			{
				int i = myApp.getLoadOrNewOrQuit();
				if (i == 0)
				/* loading */
				{
					myApp.loadProof();
				}
				else if (i == 1)
				/* new proof */
				{
					myApp.newProof();
				}
				else
				/* quitting */
				{
					((Frame)myApp.getParent()).dispose();
					System.exit(0);
				}
			}
			return true;
		}
		else if (evt.target == noSave)
		{
			dispose();
			int i = myApp.getLoadOrNewOrQuit();
			if (i == 0)
			/* loading */
			{
				myApp.loadProof();
			}
			else if (i == 1)
			/* new proof */
			{
				myApp.newProof();
			}
			else
			/* quitting */
			{
				((Frame)myApp.getParent()).dispose();
				System.exit(0);
			}
			return true;
		}
		else if (evt.target == cancel)
		{
			dispose();
			return true;
		}
		return false;
	}

	public boolean handleEvent(Event evt)
	/* to handle the window events */
	{
		switch (evt.id)
		{
			case Event.WINDOW_DESTROY :
			{
				dispose();
				return true;
			}
			default : return super.handleEvent(evt);
		}

	}
}