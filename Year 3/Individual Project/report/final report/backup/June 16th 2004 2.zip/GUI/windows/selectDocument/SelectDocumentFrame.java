/*
 * Created on 01-Jun-2004
 *
 */
package GUI.windows.selectDocument;

import GUI.GUIController;
import GUI.windows.XTractorFrame;

/**
 * @author ss401
 *
 */
public class SelectDocumentFrame extends XTractorFrame{

	public SelectDocumentFrame(GUIController c) {
		super(c);
	}

}
