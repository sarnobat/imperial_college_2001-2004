package GUI.windows.dialog;

/*
 * Created on 01-Jun-2004
 *
 */

import GUI.GUIController;
import GUI.windows.XTractorFrame;

/**
 * @author ss401
 *
 */
public abstract class AbstractDialogFrame extends XTractorFrame {

	/**
	 * @param guiController
	 */
	public AbstractDialogFrame(GUIController guiController) {
		super(guiController);
	}

}
