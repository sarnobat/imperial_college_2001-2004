/*
 * Created on 15-May-2004
 *
 */
package exception;

/**
 * @author ss401
 *
 */
public class NoDocumentsExistException extends Exception {

}
