/*
 * Created on 31-May-2004
 *
 */
package GUI.windows.xerModelView.xerTreeComponents;


import xtractor.schemaConverter.xer.xerConstructs.XERCompoundConstruct;

/**
 * @author ss401
 *
 */
public class XERCompoundConstructNode extends XERNode {

	/**
	 * @param userObject
	 */
	public XERCompoundConstructNode(XERCompoundConstruct construct) {
		super(construct,true);
	}


}
