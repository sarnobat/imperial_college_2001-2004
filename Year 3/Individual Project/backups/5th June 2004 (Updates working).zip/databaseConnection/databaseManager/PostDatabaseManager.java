/*
 * Created on 28-May-2004
 *
 */
package databaseConnection.databaseManager;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import databaseConnection.Nomenclature;

/**
 * @author ss401
 * This manager assumes that the schema has already been created and thus
 * we can use the schema to deduce information about the XML files
 */
public class PostDatabaseManager extends AbstractDatabaseManager {

	/**
	 * @param databaseSchemaName
	 */
	public PostDatabaseManager(String databaseSchemaName) {
		super(databaseSchemaName);
	}

	/**
	 * @param elementName - The name of an XML element (e.g. name)
	 * @return - True if its table uses a sequence to determine the primary key value
	 * that should be inserted.
	 */
	public boolean dataTableUsesAutoKey(String elementName) {

		try {
			String[] types = { "SEQUENCE" };
			ResultSet rs = metaData.getTables("pg_class", schemaName, elementName + "%", types);
			if (rs.next()) {
				return true;
			}
			else {
				return false;
			}

		}
		catch (SQLException e) {
			logger.error("Couldn't determine whether " + elementName + " requires an auto key. " + e);
			return false;
		}

	}

	/**
	 * @param keyName - The name of a primary key column in a table
	 * @return - True if it relies on a sequence to determine its value (and not an XML attribute value)
	 * (it's an 'implicit key'0
	 */
	public boolean isAutoKey(String keyName) {
		String[] types = { "SEQUENCE" };
		try {
			ResultSet rs = metaData.getTables("pg_class", schemaName, keyName + "%", types);
			if (rs.next()) {
				return true;
			}
		}
		catch (SQLException e) {
			logger.error("Couldn't determine if key relies on a sequence. " + e);
		}
		return false;
	}

	/**
	 * @param elementName - The name of a SIMPLE XML element which we are trying to determine
	 * can occur more than once.
	 * @return - True if this element's character data is represented in a multi-value foreign table
	 * (e.g. true for 'supplies')
	 */
	public boolean isMultiValued(String elementName) {
		// At the moment, we'll check by seeing if there is a table with the name 'elementName'
		// AND an attribute with the name 'elementName'

		try {
			ResultSet rs = metaData.getColumns(null, schemaName, elementName, elementName);
			if (rs.next()) {
				/*System.out.println(rs.getString("TABLE_NAME"));
				System.out.println(rs.getString("COLUMN_NAME"));*/
				return true;
			}

		}
		catch (SQLException e) {
			logger.error("Couldn't deterine whether " + elementName + " is a multi-occurring element. " + e);
		}
		return false;
	}

	/**
	 * Note these are the GENUINE key fields and not our internal ones. They will be the fields that
	 * will be in both the meta table AND the data table
	 * @param element - The name of the XML element whose key attributes you wish to determine
	 * @return - A list of Strings for each column name
	 */
	public List getPrimaryKeyAttributesNames(String elementName) {

		List keyColumnNames = new LinkedList();

		try {
			ResultSet rs = metaData.getPrimaryKeys("pg_class", schemaName, elementName);
			while (rs.next()) {
				String keyColumnName = rs.getString("column_name");
				keyColumnNames.add(keyColumnName);
			}
			return keyColumnNames;
		}
		catch (SQLException e) {
			logger.error("Couldn't determine key fields." + e);
			return null;
		}

	}
	/**
	 * @param element
	 * @return
	 */
	public boolean isSimpleElement(String elementName) {
		String sql =
			"SELECT * FROM "
				+ getSystemTableName(Nomenclature.SIMPLE_ELEMENTS)
				+ " WHERE "
				+ Nomenclature.SIMPLE_ELEMENTS_element
				+ "='"
				+ elementName
				+ "';";
		ResultSet rs = executeQuery(sql);
		try {
			if (rs.next()) {
				return true;
			}
			else {
				return false;
			}
		}
		catch (SQLException e) {
			logger.error("Couldn't determine whether " + elementName + " has character data. " + e);
			return false;
		}
	}
	/**
	 * @param tableName - the QUALIFIED table name
	 * @return - A list of Integers for each type
	 */
	protected Map getColumnTypesForTable(String tableName) throws SQLException {

		//The following isn't ideal because we cannot be sure that a thrown exception was due to a
		// table not exisiting; but we have no choice

		String sql = "SELECT * FROM " + tableName;
		PreparedStatement ps = conn.prepareStatement(sql);

		ResultSet rs = ps.executeQuery();
		ResultSetMetaData metaData = rs.getMetaData();
		Map columnNamesToTypes = new TreeMap();
		for (int i = 1; i <= metaData.getColumnCount(); i++) {
			columnNamesToTypes.put(metaData.getColumnName(i), new Integer(metaData.getColumnType(i)));
		}
		return columnNamesToTypes;

	}
	/**
		* @param element
		* @return
		*/
	public boolean isMixedElement(String elementName) {
		String sql =
			"SELECT * FROM "
				+ getSystemTableName(Nomenclature.MIXED_ELEMENTS)
				+ " WHERE "
				+ Nomenclature.MIXED_ELEMENTS_element
				+ "='"
				+ elementName
				+ "';";
		ResultSet rs = executeQuery(sql);
		try {
			if (rs.next()) {
				return true;
			}
			else {
				return false;
			}
		}
		catch (SQLException e) {
			logger.error("Couldn't determine whether " + elementName + " has mixed content. " + e);
			return false;
		}
	}
	/**
		* The attribute names must be from the data table.
		* @param elementName - The name of an XML element (e.g. part)
		* @param attributeNames - The names of the attributes whose values you want returned
		* @return - A map from attribute name to attribute value
		*/
	public Map getAttributeValues(String elementName, List attributeNames) {

		Map attributeNamesToValues = new HashMap();
		String tableName = getDataTableName(elementName);
		String sql = "SELECT * FROM " + tableName;
		ResultSet rs = executeQuery(sql);

		try {
			rs.next();
			ResultSetMetaData rsMeta = rs.getMetaData();
			for (Iterator iter = attributeNames.iterator(); iter.hasNext();) {
				String attributeName = (String) iter.next();
				Object attributeValue = rs.getObject(attributeName);
				attributeNamesToValues.put(attributeName, attributeValue);
			}
		}
		catch (SQLException e) {
			logger.error("Couldn't get attribure values for element " + elementName + ". " + e);
			logger.error("Statement was: " + sql);
		}
		return attributeNamesToValues;
	}

	/**
			* Determines the key values given an element and its element schema global id
			* (by looking in the database)
			* @param id
			* @return
			*/
	public Map getPrimaryKeyNamesAndValues(String elementName, int id) {

		Map keyNamesToValues = new TreeMap();

		String sql = "SELECT ";
		List primaryKeyNames = getPrimaryKeyAttributesNames(elementName);
		for (Iterator iter = primaryKeyNames.iterator(); iter.hasNext();) {
			String keyAttributeName = (String) iter.next();
			sql += keyAttributeName;
			if (iter.hasNext()) {
				sql += ",";
			}
		}
		sql += " FROM " + getCompleteTableName(elementName) + " WHERE id=" + id;

		ResultSet rs = executeQuery(sql);
		try {
			rs.next();
			ResultSetMetaData rsMeta = rs.getMetaData();
			int columnCount = rsMeta.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				keyNamesToValues.put(rsMeta.getColumnName(i), rs.getObject(i));
			}
		}
		catch (SQLException e) {
			logger.error("Couldn't determine key values for " + elementName + ". " + e);
			logger.error("Statement was:\n\t" + sql);
		}

		return keyNamesToValues;
	}
	/**
		* @param elementName
		* @return
		*/
	public boolean isSpecialization(String elementName) {

		String sql =
			"SELECT * FROM "
				+ getSystemTableName(Nomenclature.GENERALIZATIONS)
				+ " WHERE "
				+ Nomenclature.GENERALIZATIONS_specialization_table
				+ "='"
				+ elementName
				+ "'";
		ResultSet rs = executeQuery(sql);
		try {
			if (rs.next()) {
				return true;
			}
			else {

				return false;
			}
		}
		catch (SQLException e) {
			logger.error("Couldn't determine if " + elementName + " was part of a generalization hierarchy. " + e);
			return false;
		}
	}

	/**
	 * @param id - The globally unique element schema id for an element
	 * @return - The element name (i.e. table name) for 'id'
	 */
	public String getElementName(int id) {
		String sql = "SELECT table_name FROM " + getSystemTableName(Nomenclature.IDS_TO_TABLES) + " WHERE id = " + id;
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				return rs.getString("table_name");
			}
			logger.error("No table contains a row with id " + id);
		}
		catch (SQLException e) {
			logger.error("Couldn't determine which table id " + id + " belongs to." + e);
			logger.error("Statement was: " + sql);
		}
		return null;
	}
	/**
	 * @return - The name of the root xml element
	 */
	protected String getRootElementName() {
		String sql =
			"SELECT * FROM "
				+ getSystemTableName(Nomenclature.ELEMENTS)
				+ " WHERE "
				+ Nomenclature.ELEMENTS_parent_name
				+ " IS null";
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				return rs.getString(Nomenclature.ELEMENTS_name);
			}
			logger.error("No root table was specified.");
		}
		catch (SQLException e) {
			logger.debug("Attempting to find root element name: " + sql);
			logger.error("Couldn't determine root element." + e);
		}
		return null;
	}
}
