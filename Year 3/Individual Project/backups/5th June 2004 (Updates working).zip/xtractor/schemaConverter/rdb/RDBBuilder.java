/*
 * Created on 24-Feb-2004
 *
 */
package xtractor.schemaConverter.rdb;

import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

import org.apache.log4j.Logger;

import xtractor.schemaConverter.rdb.parsers.SystemTableHandler;
import xtractor.schemaConverter.rdb.parsers.XERAttributeParser;
import xtractor.schemaConverter.rdb.parsers.XEREntityParser;
import xtractor.schemaConverter.rdb.parsers.XERGeneralizationParser;
import xtractor.schemaConverter.rdb.parsers.XERRelationshipParser;
import xtractor.schemaConverter.xer.XERModel;
import xtractor.schemaConverter.xer.xerConstructs.XEREntity;
import xtractor.schemaConverter.xer.xerConstructs.XERGeneralization;
import xtractor.schemaConverter.xer.xerConstructs.XERRelationship;
import xtractor.schemaConverter.xsd.XSDReader;
/*
 * TODO: Need to create Triggers for schema datatypes which don't correspond exactly to SQL datatypes
 */
/**
 * @author ss401
 * Takes an XER model and generates a relational database model 
 */
public class RDBBuilder {

	final String SYSTEM_PREFIX = "SYSTEM_";
	final String DELIMITER = "\t";
	Logger logger = Logger.getLogger(this.getClass());
	Writer out;
	XERModel model;
	SQLMapper sqlMapper;
	String schemaName;

	// The entities whose tables have been created.
	Collection parsedEntities;

	// parsers
	XEREntityParser entityParser;
	XERAttributeParser attributeParser;
	XERGeneralizationParser generalizationParser;
	XERRelationshipParser relationshipParser;

	SystemTableHandler systemTableHandler;

	/**
	 * @param xerModel - The XER model to convert to a relational schema
	 * @param schemaFile
	 */
	public RDBBuilder(XERModel xerModel, File schemaFile, Writer out) {
		this.model = xerModel;
		this.out = out;
		XSDReader schemaWalker = new XSDReader(schemaFile);
		this.sqlMapper = new SQLMapper(schemaWalker.getRootElement().getNamespace().getPrefix());
		this.schemaName = schemaFile.getName().split(".x")[0];

		this.parsedEntities = new LinkedList();

		// Initialize parsers
		this.systemTableHandler = new SystemTableHandler(this.schemaName);
		this.attributeParser = new XERAttributeParser(this);
		this.entityParser = new XEREntityParser(this);
		this.generalizationParser = new XERGeneralizationParser(this);
		this.relationshipParser = new XERRelationshipParser(this);

	}

	/**
	 * @param out - The place to write the SQL code
	 */
	public void build() throws IOException {

		// Make sure the database schema doesn't exist already
		out.write("DROP SCHEMA " + schemaName + " CASCADE;\n");

		// Delete the 'well known' table listing all the schemas
		//TODO: This isn't right. It should just delete the entry for the schema
		//out.write("DROP TABLE xtractor_schemas;\n");
		out.write("DELETE FROM XTractor_schemas WHERE name='" + schemaName + "';\n");
		out.write("INSERT INTO XTractor_schemas(name) VALUES ('" + schemaName + "');\n");

		// Declare a new database schema
		out.write("CREATE SCHEMA " + schemaName + ";\n\n");

		// Create system tables
		/*out.write(systemTableHandler.createElementLocation());
		out.write(systemTableHandler.createMixedEntitySummary());
		out.write(systemTableHandler.createCharacterDataElements());*/
		createSystemTables();

		// Create a sequence so we can identify each element uniquely (in an element schema)
		out.write("CREATE SEQUENCE ss.id MINVALUE 1;\n");

		// We must create a table saying which table references which,
		// otherwise we don't know which tables to populate when expressing a containment 
		// relationship (at least in some cases such as a generalization)
		//out.write(systemTableHandler.createGeneralization());
		Collection generalizations = model.getGeneralizations();

		out.flush();

		//TODO: Actually, the root entity shouldn't be treated like the rest of them.
		// Parse the entities
		Collection entities = model.getEntities();
		for (Iterator iter = entities.iterator(); iter.hasNext();) {
			XEREntity xerEntity = (XEREntity) iter.next();
			entityParser.parseEntity(xerEntity);
			out.write("\n\n");
		}

		/*
		 * Parse the generalizations 
		 */
		for (Iterator iter = generalizations.iterator(); iter.hasNext();) {
			XERGeneralization generalization = (XERGeneralization) iter.next();
			out.write(generalizationParser.parseGeneralization(generalization));
			out.write("\n\n");

		}

		// Parse the relationships
		Collection relationships = model.getRelationships();
		for (Iterator iter = relationships.iterator(); iter.hasNext();) {
			XERRelationship relationship = (XERRelationship) iter.next();
			out.write(relationshipParser.parseRelationship(relationship));
			out.write("\n\n");
		}

		out.write(systemTableHandler.getPendingSystemData());

		/* 
		 * The following cannot be done before the tables have been created:
		 * 		- Creating the complete view of the element schema tables is done
		 * 		- Creating an id to table mapping
		 */

		out.flush();

	}

	/**
	 * 
	 */
	private void createSystemTables() throws IOException {
		out.write(systemTableHandler.getTableCreationSQL());
		out.write(systemTableHandler.insertElementInformation(model.getRootEntity().getName(), null, null, "complex"));
	}

	/**
	 * @return - The SQL output stream writer
	 */
	public Writer getWriter() {
		return out;
	}

	/**
	 * Convenience method
	 * @return
	 */
	public XERAttributeParser getAttributeParser() {
		return this.attributeParser;
	}

	/**
	 * @return - The default delimiter at the lowest level (e.g. a tab)
	 */
	public String getDelimiter() {
		return this.DELIMITER;
	}

	/**
	 * @return - The SQL mapper which handles XSD to SQL type conversions
	 */
	public SQLMapper getSqlMapper() {
		return sqlMapper;
	}

	/**
	 * @return - The name of the xsd file minus the extension, i.e. the name of the table space
	 */
	public String getPrefix() {
		return this.schemaName;
	}

	/**
	 * @return - A collection of strings, where each string is the qualified name of a table which has been created
	 */
	public Collection getParsedEntities() {
		return this.parsedEntities;
	}

	/**
	 * @return
	 */
	public String getSchemaName() {
		return schemaName;
	}

	/**
	 * @return
	 */
	public SystemTableHandler getSystemTableHandler() {
		return systemTableHandler;
	}

}
