/*
 * Created on 28-May-2004
 *
 */
package xtractor.schemaConverter.rdb.parsers;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

import databaseConnection.Nomenclature;
import databaseConnection.databaseManager.AbstractDatabaseManager;

/**
 * @author ss401
 * Note: we cannot use any methods which read the database
 */
public class SystemTableHandler extends AbstractDatabaseManager {

	// This is a list of SQL commands which could not be inserted into the sql
	// script on the fly (e.g. for attributes)
	Collection pendingSystemDataAdditions;

	String DELIMITER = Nomenclature.DELIMITER;

	String[] ELEMENTS_columns =
		{
			Nomenclature.ELEMENTS_name,
			Nomenclature.ELEMENTS_parent_name,
			Nomenclature.ELEMENTS_alias,
			Nomenclature.ELEMENTS_type };
	String[] ATTRIBUTES_columns =
		{ Nomenclature.ATTRIBUTES_attribute, Nomenclature.ATTRIBUTES_element, Nomenclature.ATTRIBUTES_alias };

	/**
	 * @param databaseSchemaName
	 */
	public SystemTableHandler(String databaseSchemaName) {
		super(databaseSchemaName);
		this.pendingSystemDataAdditions = new LinkedList();
	}

	/**
	 * 
	 */
	public String getTableCreationSQL() {
		String sql = "";
		sql += createElementSystemTable();
		sql += createAttributeSystemTable();
		sql += createGeneralizationSystemTable();

		sql += createViews();

		return sql;
	}

	/**
	 * @return
	 */
	private String createViews() {
		String sql = "";

		// Complex elements
		sql += "CREATE VIEW " + getSystemTableName(Nomenclature.COMPLEX_ELEMENTS) + " AS (\n";
		sql += DELIMITER
			+ "SELECT "
			+ Nomenclature.ELEMENTS_name
			+ "\n"
			+ DELIMITER
			+ "FROM "
			+ getSystemTableName(Nomenclature.ELEMENTS)
			+ "\n"
			+ DELIMITER
			+ "WHERE type='complex' OR type='mixed'";
		sql += "\n);\n";

		// Simple elements
		sql += "CREATE VIEW " + getSystemTableName(Nomenclature.SIMPLE_ELEMENTS) + " AS (\n";
		sql += DELIMITER
			+ "SELECT "
			+ Nomenclature.ELEMENTS_name
			+ "\n"
			+ DELIMITER
			+ "FROM "
			+ getSystemTableName(Nomenclature.ELEMENTS)
			+ "\n"
			+ DELIMITER
			+ "WHERE type='simple'";
		sql += "\n);\n";

		// Mixed elements
		sql += "CREATE VIEW " + getSystemTableName(Nomenclature.MIXED_ELEMENTS) + " AS (\n";
		sql += DELIMITER
			+ "SELECT "
			+ Nomenclature.ELEMENTS_name
			+ "\n"
			+ DELIMITER
			+ "FROM "
			+ getSystemTableName(Nomenclature.ELEMENTS)
			+ "\n"
			+ DELIMITER
			+ "WHERE type='mixed'";
		sql += "\n);\n";
		return sql;
	}

	/**
	 * @return
	 */
	private String createAttributeSystemTable() {
		String sql = "";
		String[] columns = ATTRIBUTES_columns;

		sql += "CREATE TABLE " + getSystemTableName(Nomenclature.ATTRIBUTES) + " (\n";
		for (int i = 0; i < columns.length; i++) {
			sql += "\n" + DELIMITER + columns[i] + DELIMITER + "VARCHAR(50),";
		}
		sql += "\n" + DELIMITER + "PRIMARY KEY(" + Nomenclature.ATTRIBUTES_attribute + ")";
		sql += "\n);";

		return sql;
	}
	/**
	 * @return
	 */
	private String createElementSystemTable() {
		String sql = "";
		String[] columns = ELEMENTS_columns;

		sql += "CREATE TABLE " + getSystemTableName(Nomenclature.ELEMENTS) + " (\n";
		for (int i = 0; i < columns.length; i++) {
			sql += "\n" + DELIMITER + columns[i] + DELIMITER + "VARCHAR(50),";
		}
		sql += "\n" + DELIMITER + "PRIMARY KEY(" + Nomenclature.ELEMENTS_name + ")";
		sql += "\n);";

		return sql;

	}

	/**
	 * We allow nulls
	 * @param elementName - The name of an XML element
	 * @param parent_name - The name of the parent XML element (can be null)
	 * @param alias - The name the user gives to the element (can be null)
	 * @param type - simple/mixed/complex
	 */
	public String insertElementInformation(String elementName, String parent_name, String alias, String type) {
		String[] columns = ELEMENTS_columns;

		String sql = "INSERT INTO " + getSystemTableName(Nomenclature.ELEMENTS) + "(";
		for (int i = 0; i < columns.length; i++) {
			sql += columns[i];
			if (i < columns.length - 1) {
				sql += ",";
			}
		}
		sql += ") VALUES (";

		sql += resolveValue(elementName)
			+ ","
			+ resolveValue(parent_name)
			+ ","
			+ resolveValue(alias)
			+ ","
			+ resolveValue(type)
			+ ");";
		// This may cause a problem with null
		//executeUpdate(sql);
		return sql;
	}

	/**
	 * 
	 * @param attributeName - The name of an XML attribute
	 * @param elementResidence - The XML element in which the attribute is found
	 * @param alias - The name the user wishes to give to the attribute
	 */
	public String insertAttribute(String attributeName, String elementResidence, String alias) {
		String[] columns = ATTRIBUTES_columns;

		String sql = "INSERT INTO " + getSystemTableName(Nomenclature.ATTRIBUTES) + "(";
		for (int i = 0; i < columns.length; i++) {
			sql += columns[i];
			if (i < columns.length - 1) {
				sql += ",";
			}
		}
		sql += ") VALUES (";
		sql += resolveValue(attributeName) + "," + resolveValue(elementResidence) + "," + resolveValue(alias);
		sql += ");";
		// This may cause a problem with null
		//executeUpdate(sql);
		return sql;
	}

	/**
	 * @return - A string for all the pending SQL insertion commands
	 */
	public String getPendingSystemData() {
		String acc = "";
		for (Iterator iter = pendingSystemDataAdditions.iterator(); iter.hasNext();) {
			String dataInsertion = (String) iter.next();
			acc += dataInsertion + "\n";
		}
		return acc;
	}

	/**
	 * 
	 * @param systemDataSQL - System data which needs to be added to a system table
	 */
	public void addPendingDataInsertion(String systemDataSQL) {
		pendingSystemDataAdditions.add(systemDataSQL);
	}

	/**
	 * @param attributeSystemInformation
	 */
	public void addPendingDataInsertions(Collection systemDataSQLStatements) {
		for (Iterator iter = systemDataSQLStatements.iterator(); iter.hasNext();) {
			String insertionCommand = (String) iter.next();
			addPendingDataInsertion(insertionCommand);

		}

	}

	/**
	 * @return - SQL code to generate a system table which says which table references which
	 * "table" is the name of a table containing a foreign key to "foreign_table". Do not think
	 * about it in any other terms (e.g.Entity relationships) otherwise you may get it the
	 * wrong way round
	 */
	private String createGeneralizationSystemTable() {
		String sql = "";

		sql += "CREATE TABLE " + getSystemTableName(Nomenclature.GENERALIZATIONS) + " (\n";
		sql += DELIMITER + Nomenclature.GENERALIZATIONS_generalization_table + DELIMITER + "VARCHAR(50),\n";
		sql += DELIMITER + Nomenclature.GENERALIZATIONS_specialization_table + DELIMITER + "VARCHAR(50)";
		//sql += ",\n" + DELIMITER + "PRIMARY KEY (table,foreign_table)\n";
		sql += ");\n";
		return sql;
	}
	/**
	 * @param referringTable - The unqualified name of a data table which contains a foreign key reference
	 * to 'foreign table'
	 * @param foreignTable - The table whose primary key appears as a foreign key in the referring
	 * table
	 * @return - The SQL code to add an entry to the table_containment table 
	 */
	public String insertGeneralizationInformation(String generalization, String specialization) {
		String sql =
			"INSERT INTO "
				+ getSystemTableName(Nomenclature.GENERALIZATIONS)
				+ "("
				+ Nomenclature.GENERALIZATIONS_generalization_table
				+ ","
				+ Nomenclature.GENERALIZATIONS_specialization_table
				+ ") VALUES ("
				+ resolveValue(generalization)
				+ ","
				+ resolveValue(specialization)
				+ ");\n";
		return sql;
	}

	private String resolveValue(String columnValue) {
		if (columnValue == null) {
			columnValue = "NULL";
		}
		else {
			columnValue = "'" + columnValue + "'";
		}
		return columnValue;
	}
}
