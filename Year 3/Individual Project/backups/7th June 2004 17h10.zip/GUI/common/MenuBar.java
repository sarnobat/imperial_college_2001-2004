/*
 * Created on 31-May-2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package GUI.common;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.event.MenuEvent;
import javax.swing.event.MenuListener;

import GUI.GUIController;
import GUI.windows.XTractorFrame;

/**
 * @author ss401
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class MenuBar extends JMenuBar {

	JMenu returnToStart;
	GUIController c;
	XTractorFrame frame;

	/**
	 * 
	 */
	public MenuBar(GUIController c, XTractorFrame f) {
		this.c = c;
		this.frame = f;
		this.returnToStart = new JMenu("Main Menu");
		this.add(returnToStart);

		returnToStart.addMenuListener(new ReturnListener());
	}

	class ReturnListener implements MenuListener {

		public void menuSelected(MenuEvent e) {

			frame.dispose();
			c.launchTaskSelectorFrame();

		}

		public void menuDeselected(MenuEvent e) {

		}
		public void menuCanceled(MenuEvent e) {

		}
	}

}
