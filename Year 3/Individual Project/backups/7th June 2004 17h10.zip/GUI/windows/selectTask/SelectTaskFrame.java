/*
 * Created on 31-May-2004
 */
package GUI.windows.selectTask;

import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.filechooser.FileFilter;

import org.apache.log4j.Logger;

import GUI.GUIController;
import GUI.windows.XTractorFrame;

/**
 * @author ss401
 *
 */
public class SelectTaskFrame extends XTractorFrame {

	Logger logger = Logger.getLogger(this.getClass());

	JFileChooser fc;
	JButton generateRDB;
	JButton importData;
	JButton exportData;

	/**
	 * @param c
	 */
	public SelectTaskFrame(GUIController c) {
		super(c);

		setup();
	}

	protected void setup() {
		Container pane = this.getContentPane();
		pane.setLayout(new GridBagLayout());

		GridBagConstraints c = new GridBagConstraints();

		//JLabel instruction = new JLabel("Select a task.");
		fc = new JFileChooser("./xml/");
		//fc.setPreferredSize(new Dimension(guiController.width, guiController.height));
		fc.addActionListener(new FileChooserListener());
		XMLFileFilter filter = new XMLFileFilter();
		fc.setFileFilter(new XMLFileFilter());
		c.gridx = 0;
		c.gridy = 0;
		//c.weightx = 1;
		//c.weighty = 1;
		c.gridwidth = 2;
		pane.add(fc, c);

		generateRDB = new JButton("Create relational schema");
		generateRDB.addActionListener(new GenerateRDBListener());
		generateRDB.setEnabled(false);
		//c.weightx = 0;
		//c.weighty = 0;
		c.gridx = 0;
		c.gridy = 1;
		c.gridwidth = 1;
		pane.add(generateRDB, c);
		JLabel generateRDBLabel = new JLabel("Create a relational database schema from an XML Schema");
		c.gridx = 1;
		c.gridy = 1;
		pane.add(generateRDBLabel, c);

		importData = new JButton("Import XML Data");
		importData.setEnabled(false);
		importData.addActionListener(new ImportDataListener());
		c.gridx = 0;
		c.gridy = 2;
		pane.add(importData, c);
		JLabel importDataLabel =
			new JLabel("Add a the data in an XML Document to a relational database that has been generated from this XML document's schema.");
		c.gridx = 1;
		c.gridy = 2;
		pane.add(importDataLabel, c);

		JButton exportData = new JButton("Export XML Data");
		exportData.addActionListener(new ExportDataListener());
		c.gridx = 0;
		c.gridy = 3;
		pane.add(exportData, c);
		JLabel exportDataLabel = new JLabel("Reconstruct an XML Document that was imported into the database");
		c.gridx = 1;
		c.gridy = 3;
		pane.add(exportDataLabel, c);

	}

	class GenerateRDBListener implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			File xsdFile = fc.getSelectedFile();
			if (xsdFile != null) {
				guiController.launchXERFrame(xsdFile);
			}
		}
	}
	class ImportDataListener implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			File xmlFile = fc.getSelectedFile();
			if (xmlFile != null) {
				guiController.launchImportSelectorFrame(xmlFile);
			}
		}
	}
	class ExportDataListener implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			guiController.launchExportSchemaSelectorFrame();
		}
	}
	class FileChooserListener implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			if (fc.getSelectedFile() != null) {
				File f = fc.getSelectedFile();
				if (f.getName().endsWith(".xsd") || f.getName().endsWith(".xsd.xml")) {
					generateRDB.setEnabled(true);
					importData.setEnabled(false);
				}
				else if (f.getName().endsWith(".xml")) {
					importData.setEnabled(true);
					generateRDB.setEnabled(false);
				}
			}
		}
	}

	class XMLFileFilter extends FileFilter {

		public boolean accept(File file) {
			if (file.getName().endsWith(".xml") || file.getName().endsWith(".xsd") || file.isDirectory()) {
				return true;
			}
			return false;
		}

		public String getDescription() {
			return "*.xml, *.xsd";
		}
	}

}
