

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import GUI.GUIController;

/*
 * Created on 15-May-2004
 *
 */

/**
 * @author ss401
 * This is the class that is invoked when the application is launched
 */
public class Application {
	static Logger logger = Logger.getRootLogger();
	public static void main(String[] args) {
		// Initialize logger
		BasicConfigurator.configure();
		logger.setLevel(Level.DEBUG);

		GUIController g = new GUIController();
	}
}
