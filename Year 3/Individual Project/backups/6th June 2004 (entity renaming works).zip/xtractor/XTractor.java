package xtractor;
import java.io.File;
import java.io.IOException;
import java.io.Writer;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import xtractor.dataExporter.DataExporter;
import xtractor.dataImporter.DataImporter;
import xtractor.schemaConverter.SchemaConverter;
import xtractor.schemaConverter.xer.XERModel;

/*
 * Created on 13-Mar-2004
 *
 */

/**
 * @author ss401
 * This is the API class with all the business logic.
 */
public class XTractor {
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		// Initialize logger
		BasicConfigurator.configure();
		logger.setLevel(Level.DEBUG);

		//try {
		//translateSchema("xml/ss.xsd");
		logger.info("Finished generating schema.");
		//importData("xml/parts.xml");
		logger.info("Finished importing data.");
		//exportXMLFile(1, "ss");
		/*}
		catch (NoAssociatedSchemaException e) {
			logger.fatal("Couldn't find associated schema." + e);
		}*/

	}

//	private static void importData(String xmlFilePath) throws NoAssociatedSchemaException {
//		File dataFile = new File(xmlFilePath);
//		//DataImporter.importData(dataFile);
//		DataImporter dataImporter = new DataImporter();
//		dataImporter.importData(dataFile);
//	}

	private static void translateSchema(String xsdFilePath) {
		/*
		 * get the attached schema
		 * validate the document against it
		 * IF Schema not previously encountered
		 * 	create schema
		 * perform import of XML file data
		 * add the document to the document.xml list which includes id,date,database,comment
		 * 	 
		 */
		File schemaFile = new File(xsdFilePath);
		//SchemaConverter.convertSchema(schemaFile);

	}

//	public static void exportXMLFile(int docId, String databaseSchemaName) {
//		/*
//		 * create xml document
//		 * validate against schema
//		 * Tell the user the location of the xml file generated
//		 */
//		DataExporter dataExporter = new DataExporter(databaseSchemaName);
//		dataExporter.exportData(docId);
//	}

	private static void listImportedDocuments() {
		/*
		 * Iterate through xml file
		 * 	print a list of documents
		 */
	}

	public static XERModel getXERModel(File xsdFile) {

		//XERBuilder xerBuilder = new XERBuilder(xsdFile);
		SchemaConverter converter = new SchemaConverter(xsdFile);
		return converter.createXERModel();
	}

	public static void createRelationalDatabase(XERModel model, File xsdFile, Writer writer) {
		/*File creationScript = SchemaConverter.createSQLScript(model,xsdFile);
		try {
			SchemaConverter.executeSQLScript(creationScript,writer);
		} catch (IOException e) {
			logger.error("Couldn't writer errors to output stream. ");
		}*/
		SchemaConverter converter = new SchemaConverter(xsdFile);
		File script = converter.createSQLScript(model, xsdFile);
		try {
			converter.executeSQLScript(script, writer);
		}
		catch (IOException e) {
			logger.error("Couldn't execute SQL script.");
		}
	}

	/**
	 * @return
	 */
	public static String[][] getDatabaseSchemas() {
		
		return DatabaseSchemas.getSchemas();
	}

	//	public static File createScript(XERModel model,File xsdFile){
	//		return SchemaConverter.createSQLScript(model,xsdFile);
	//	}
	
	public static void importData(File xmlFile,String databaseSchemaName,Writer out){
		DataImporter importer = new DataImporter(xmlFile,databaseSchemaName,out);
		importer.importData();
	}

	/**
	 * @return
	 */
	public static String[][] getDocuments(String databaseSchemaName) {
		DataExporter exporter = new DataExporter(databaseSchemaName,null);
		return exporter.getFileList();
	}

	/**
	 * @param databaseSchema
	 * @param selectedDocumentNumber
	 * @param writer
	 * @return
	 */
	public static File exportData(String databaseSchemaName, int selectedDocumentNumber, Writer writer) {
		DataExporter exporter = new DataExporter(databaseSchemaName,writer);
		return exporter.getFile(selectedDocumentNumber);
	}
}
