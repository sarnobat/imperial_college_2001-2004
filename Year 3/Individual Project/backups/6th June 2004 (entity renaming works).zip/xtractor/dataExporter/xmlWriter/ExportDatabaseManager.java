/*
 * Created on 13-May-2004
 */
package xtractor.dataExporter.xmlWriter;

import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;

import databaseConnection.Nomenclature;
import databaseConnection.databaseManager.PostDatabaseManager;

/**
 * @author ss401
 */
public class ExportDatabaseManager extends PostDatabaseManager {

	public ExportDatabaseManager(String databaseSchemaName) {
		super(databaseSchemaName);
	}

	/**
	 * @param id - The globally unique id of an element
	 * @return - The Collection (of Strings) of names of all the elements which 
	 * can (in theory) appear as a child of the given element 
	 */
	private Collection getChildElementNames(int id) {
		Collection c = new LinkedList();
		String originalElementName = getElementName(id);
		String unqualifiedMetaTableName =
			getUnqualifiedTableName(getMetaTableName(originalElementName))
				.toLowerCase();

		try {
			String metaPrefix = (Nomenclature.META_PREFIX).toLowerCase();
			DatabaseMetaData metaData = conn.getMetaData();
			ResultSet rs = metaData.getImportedKeys(null, schemaName, null);
			while (rs.next()) {
				String parentTable = rs.getString("PKTABLE_NAME");
				String childTable = rs.getString("FKTABLE_NAME");

				if (parentTable.equals(unqualifiedMetaTableName)) {
					if (childTable.startsWith(metaPrefix)) {
						//System.out.println(childTable + "-->" + parentTable);
						c.add(Nomenclature.removeMetaDecorator(childTable));
					}
				}

			}
		} catch (SQLException e) {
			logger.error(
				"Couldn't determine what meta tables contain pid references to the given id. "
					+ e);
		}

		return c;
	}

	/**
	 * @param parentId - the id of the parent element
	 * @return - a map of all child elements' order to their unique id
	 */
	public TreeMap getOrdsToIds(int parentId) {
		TreeMap ordsToIds = new TreeMap();

		// The first thing we need to do is determine what tables to look in
		Collection childElementNames = getChildElementNames(parentId);
		for (Iterator iter = childElementNames.iterator(); iter.hasNext();) {
			String childElementName = (String) iter.next();
			String metaTableName = getMetaTableName(childElementName);

			String sql =
				"SELECT id,ord FROM "
					+ metaTableName
					+ " WHERE pid="
					+ parentId;
			ResultSet rs = executeQuery(sql);
			try {
				while (rs.next()) {
					int ord = rs.getInt("ord");
					int id = rs.getInt("id");
					ordsToIds.put(new Integer(ord), new Integer(id));
				}
			} catch (SQLException e) {
				logger.error("Couldn't create ord to id map." + e);
			}
		}

		return ordsToIds;
	}

	public Map getIdsToElementNames(int parentId) {
		TreeMap idsToElementNames = new TreeMap();

		// The first thing we need to do is determine what tables to look in
		Collection childElementNames = getChildElementNames(parentId);
		for (Iterator iter = childElementNames.iterator(); iter.hasNext();) {
			String childElementName = (String) iter.next();
			String metaTableName = getMetaTableName(childElementName);

			String sql =
				"SELECT id,ord FROM "
					+ metaTableName
					+ " WHERE pid="
					+ parentId;
			ResultSet rs = executeQuery(sql);
			try {
				while (rs.next()) {
					int id = rs.getInt("id");
					idsToElementNames.put(new Integer(id), childElementName);
				}
			} catch (SQLException e) {
				logger.error("Couldn't create ord to id map." + e);
			}
		}

		return idsToElementNames;
	}

	/**
	 * 
	 * @param parentId
	 * @return - A map from Integer (id) to a Map (of attribute name,attribute value pairs)
	 */
	public Map getIdsToAttributeMap(int parentId) {
		Map idsToAttributeMap = new TreeMap();

		// The first thing we need to do is determine what tables to look in
		Collection childElementNames = getChildElementNames(parentId);
		for (Iterator iter = childElementNames.iterator(); iter.hasNext();) {
			String childElementName = (String) iter.next();

			// Get the result set for this particular element type
			String sql = "SELECT ";
			Collection dataColumnNames = getDataColumnNames(childElementName);
			/*for (Iterator iterator = dataColumnNames.iterator(); iterator.hasNext();) {
				String dataColumnName = (String) iterator.next();
				sql += dataColumnName;
				if (iter.hasNext()) {
					sql += ",";
				}
			}*/
			sql += "* FROM "
				+ getCompleteTableName(childElementName)
				+ " WHERE pid="
				+ parentId;

			// Get the attribute names and values
			ResultSet rs = executeQuery(sql);
			try {
				while (rs.next()) {
					Map attributeMap = new HashMap();
					int childId = rs.getInt("id");
					for (Iterator iterator = dataColumnNames.iterator();
						iterator.hasNext();
						) {
						String dataColumnName = (String) iterator.next();
						Object dataColumnValue = rs.getObject(dataColumnName);
						attributeMap.put(dataColumnName, dataColumnValue);
					}
					idsToAttributeMap.put(new Integer(childId), attributeMap);
				}
			} catch (SQLException e) {
				logger.error("Couldn't get attributes for id." + e);
			}
		}

		return idsToAttributeMap;
	}

	/**
	 * @param elementName
	 * @return
	 */
	private Collection getDataColumnNames(String elementName) {
		Collection columnNames = new LinkedList();
		String sql =
			"SELECT * FROM "
				+ getSystemTableName(Nomenclature.ATTRIBUTES)
				+ " WHERE "
				+ Nomenclature.ATTRIBUTES_element
				+ "='"
				+ elementName
				+ "'";
		ResultSet rs = executeQuery(sql);
		try {
			while (rs.next()) {
				columnNames.add(rs.getString(Nomenclature.ATTRIBUTES_name));
			}
		} catch (SQLException e) {
			logger.error("Couldn't determine data columns." + e);
		}
		return columnNames;
	}

	public String getCharacterData(int id) {

		String originalElementName = getElementName(id);
		if (isSimpleElement(originalElementName)) {
			String sql =
				"SELECT * FROM "
					+ getCompleteTableName(originalElementName)
					+ " WHERE id="
					+ id;
			Object cData = getOnlyResult(sql, originalElementName);

			return Nomenclature.convertAttributeValueToString(cData);
		} else if (isMixedElement(originalElementName)) {
			String sql =
				"SELECT * FROM "
					+ getCompleteTableName(originalElementName)
					+ " WHERE id="
					+ id;
			Object cData = getOnlyResult(sql, originalElementName);
			return Nomenclature.convertAttributeValueToString(cData);
		} else {
			logger.error("Unexpected case.");
			return null;
		}

	}

	/**
	 * @return
	 */
	public String[][] getDocuments() {
		// collection of type string[]
		Collection entries = new LinkedList();

		String rootTableName = getMetaTableName(getRootElementName());
		String sql = "SELECT * FROM " + rootTableName;
		ResultSet rs = executeQuery(sql);
		int width = 1;
		try {
			while (rs.next()) {
				String[] entry = { new Integer(rs.getInt("id")).toString()};
				width = entry.length;
				entries.add(entry);
			}
			String[][] entriesArr = new String[entries.size()][width];
			int i = 0;
			for (Iterator iter = entries.iterator(); iter.hasNext();) {
				String[] entry = (String[]) iter.next();
				entriesArr[i] = entry;
				i++;
			}
			return entriesArr;
		} catch (SQLException e) {
			return new String[0][0];
		}
	}
		/**
		 * @param id - The globally unique element schema id for an element
		 * @return - The element's original name for 'id'
		 */
		public String getElementName(int id) {
			String sql =
				"SELECT table_name FROM "
					+ getSystemTableName(Nomenclature.IDS_TO_TABLES)
					+ " WHERE id = "
					+ id;
			try {
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					String elementAliasName =rs.getString("table_name"); 
					return (String) aliasToElementName.get(elementAliasName);
				}
				logger.error("No table contains a row with id " + id);
			} catch (SQLException e) {
				logger.error(
					"Couldn't determine which table id "
						+ id
						+ " belongs to."
						+ e);
				logger.error("Statement was: " + sql);
			}
			return null;
		}
}
