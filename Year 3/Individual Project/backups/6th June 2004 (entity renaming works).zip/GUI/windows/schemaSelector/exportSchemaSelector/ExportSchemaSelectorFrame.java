/*
 * Created on 01-Jun-2004
 *
 */
package GUI.windows.schemaSelector.exportSchemaSelector;

import GUI.GUIController;
import GUI.windows.schemaSelector.AbstractSchemaSelectorController;
import GUI.windows.schemaSelector.AbstractSelectSchemaFrame;

/**
 * @author ss401
 *
 */
public class ExportSchemaSelectorFrame extends AbstractSelectSchemaFrame {

	/**
	 * @param c
	 * @param dataImporterController
	 * @param xmlFile
	 */
	public ExportSchemaSelectorFrame(GUIController c, AbstractSchemaSelectorController dataImporterController) {
		super(c, dataImporterController);
	}

}
