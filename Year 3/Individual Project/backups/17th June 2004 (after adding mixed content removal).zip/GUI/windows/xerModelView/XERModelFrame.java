/*
 * Created on 31-May-2004
 *
 */
package GUI.windows.xerModelView;

import org.apache.log4j.Logger;

import GUI.GUIController;
import GUI.windows.XTractorFrame;

/**
 * @author ss401
 *
 */
public class XERModelFrame extends XTractorFrame {

	Logger logger = Logger.getLogger(this.getClass());

	/**
	 * 
	 */
	public XERModelFrame(XERModelFrameController c, GUIController guiController) {
		super(guiController);

	}

}
