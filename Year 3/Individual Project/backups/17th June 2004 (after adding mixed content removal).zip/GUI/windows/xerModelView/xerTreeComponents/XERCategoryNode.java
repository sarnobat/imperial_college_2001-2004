/*
 * Created on 08-Jun-2004
 *
 */
package GUI.windows.xerModelView.xerTreeComponents;

/**
 * @author ss401
 *
 */
public class XERCategoryNode extends XERNode {

	/**
	 * @param object
	 * @param allowsChildren
	 */
	public XERCategoryNode(String categoryName) {
		super(categoryName, true);
		
	}

}
