/*
 * Created on 31-May-2004
 *
 */
package GUI.windows.xerModelView.xerTreeComponents;


import xtractor.schemaConverter.xer.xerConstructs.XERGeneralization;

/**
 * @author ss401
 *
 */
public class XERGeneralizationNode extends XERNode {

	/**
	 * @param userObject
	 */
	public XERGeneralizationNode(XERGeneralization generalization) {
		super(generalization,true);
	}


}
