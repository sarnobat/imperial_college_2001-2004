/*
 * Created on 31-May-2004
 *
 */
package GUI.windows.xerModelView.xerConstructSummary;

import javax.swing.JLabel;
import javax.swing.JPanel;

import GUI.windows.xerModelView.XERModelFrameController;

/**
 * @author ss401
 *
 */
public abstract class XERConstructSummary extends JPanel {

	JLabel info;
	XERModelFrameController c;

	public XERConstructSummary(XERModelFrameController c) {
		this.c = c;		
		//this.setLayout(new FlowLayout());
//		if (construct == null) {
//			info = new JLabel("Default");
//			this.add(info);
//		}
//		else {
//			//this.add(new JLabel(construct.getName()));}
//
//		}
	}

	protected abstract void setup();

//	{
//		info.setText(construct.getName());
//		//this.invalidate();
//		this.validate();
//
//	}
}