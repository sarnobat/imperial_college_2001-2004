/*
 * Created on 19-Mar-2004
 *
 */
package xtractor.schemaConverter.exception;

/**
 * @author ss401
 *
 */

public class NoAssociatedSchemaException extends Throwable {

	/**
	 * @param string
	 */
	public NoAssociatedSchemaException(String string) {
	}

}
