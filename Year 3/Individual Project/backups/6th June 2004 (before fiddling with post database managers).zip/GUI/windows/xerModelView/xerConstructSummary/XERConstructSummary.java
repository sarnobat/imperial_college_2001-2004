/*
 * Created on 31-May-2004
 *
 */
package GUI.windows.xerModelView.xerConstructSummary;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.apache.log4j.Logger;

import xtractor.schemaConverter.xer.xerConstructs.XERConstruct;

import GUI.windows.xerModelView.XERModelFrameController;

/**
 * @author ss401
 *
 */
public abstract class XERConstructSummary extends JPanel {

	final Logger logger = Logger.getLogger(this.getClass());
	JLabel info;
	XERModelFrameController c;

	public XERConstructSummary(XERModelFrameController c) {
		this.c = c;
		//this.setLayout(new FlowLayout());
		//		if (construct == null) {
		//			info = new JLabel("Default");
		//			this.add(info);
		//		}
		//		else {
		//			//this.add(new JLabel(construct.getName()));}
		//
		//		}
	}

	protected abstract void setup();

	//class EntityNameListener implements ActionListener{
	class EntityNameListener implements KeyListener {

		XERConstruct xerConstruct;

		public EntityNameListener(XERConstruct construct) {
			this.xerConstruct = construct;
		}

		public void actionPerformed(ActionEvent e) {
			JTextField textBox = (JTextField) e.getSource();
			String newName = textBox.getText();

			xerConstruct.setAlias(newName);
			System.out.println(xerConstruct.getName());

		}

		/* (non-Javadoc)
		 * @see java.awt.event.KeyListener#keyTyped(java.awt.event.KeyEvent)
		 */
		public void keyTyped(KeyEvent e) {
			//logger.warn("Key pressed");


		}

		public void keyPressed(KeyEvent e) {
		}

		public void keyReleased(KeyEvent e) {
			JTextField textBox = (JTextField) e.getSource();
			String newName = textBox.getText();

			xerConstruct.setAlias(newName);
			System.out.println(xerConstruct.getName());
		}

	}
}