DROP SCHEMA ss CASCADE;
DROP TABLE xtractor_schemas;
CREATE SCHEMA ss;

CREATE SEQUENCE ss.id MINVALUE 1;

--------------------	ps_db	--------------------

CREATE TABLE ss.META_ps_db(
	id	SERIAL	PRIMARY KEY,
	pid	INT	NOT NULL,
	ord	INT	NOT NULL
);

--------------------	supplier	--------------------
CREATE TABLE ss.supplier(
	sno	VARCHAR(50),
	town	VARCHAR(50),
	PRIMARY KEY (sno)
);
CREATE TABLE ss.supplies (
	sno	VARCHAR(50)	REFERENCES ss.supplier(sno),
	supplies	INT,
	PRIMARY KEY(sno,supplies)
);
CREATE TABLE ss.META_supplies (
	id	SERIAL	PRIMARY KEY,
	pid	INT	NOT NULL	REFERENCES ss.META_supplies(id),
	ord	INT,
	sno	VARCHAR(50),
	supplies	INT,
	FOREIGN KEY (sno,supplies) REFERENCES ss.supplies (sno,supplies)
);

CREATE TABLE ss.META_supplier(
	id	SERIAL	PRIMARY KEY,
	pid	INT	NOT NULL	REFERENCES ss.META_ps_db(id),
	ord	INT	NOT NULL,
	sno	VARCHAR(50)	UNIQUE REFERENCES ss.supplier(sno)
);

--------------------	name	--------------------

CREATE TABLE ss.META_name(
	id	SERIAL	PRIMARY KEY,
	pid	INT	NOT NULL	REFERENCES ss.META_supplier(id),
	ord	INT	NOT NULL
);



--------------------	part	--------------------
CREATE TABLE ss.part(
	colour	VARCHAR(50),
	pno	INT,
	price	FLOAT,
	PRIMARY KEY (pno)
);

CREATE TABLE ss.META_part(
	id	SERIAL	PRIMARY KEY,
	pid	INT	NOT NULL	REFERENCES ss.META_ps_db(id),
	ord	INT	NOT NULL,
	pno	INT	UNIQUE REFERENCES ss.part(pno)
);






--------------------	name_choice	--------------------

CREATE TABLE ss.name_choice (

);

--------------------	ps_db_choice	--------------------

CREATE TABLE ss.ps_db_choice (
	sno	VARCHAR(50),
	FOREIGN KEY (sno) REFERENCES ss.supplier(sno),
	pno	INT,
	FOREIGN KEY (pno) REFERENCES ss.part(pno),
	CHECK ((sno IS NULL) OR (pno IS NULL))
);



ALTER TABLE ss.supplies ADD CONSTRAINT supplies_fkey FOREIGN KEY (supplies) REFERENCES ss.part(pno);


