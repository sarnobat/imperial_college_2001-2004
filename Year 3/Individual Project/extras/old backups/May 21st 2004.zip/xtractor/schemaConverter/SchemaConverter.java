package xtractor.schemaConverter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import xtractor.schemaConverter.rdb.RDBBuilder;
import xtractor.schemaConverter.xer.XERBuilder;
import xtractor.schemaConverter.xer.XERModel;
import databaseConnection.DatabaseConnection;

/*
 * Created on 16-Feb-2004
 *
 */

/**
 * @author ss401
 * Root class to run schema converter
 */

public class SchemaConverter {
	static Logger logger = Logger.getLogger("SchemaConverter");
	static String schemaName;
	static File xsdSchemaFile;

	/**
	 * 
	 * @param schemaFile - The schema file which needs translating
	 */
	public static void convertSchema(File schemaFile) {
		
		// Build an XER Model		
		schemaName = schemaFile.getName().split(".x")[0];		
		XERBuilder xerBuilder = new XERBuilder(schemaFile);
		XERModel xerModel = xerBuilder.build();

		logger.info("Resulting XER Model:\n" + xerModel +"\n\n\n\n\n\n");
		
		//xerBuilder.transformModel(xerModel);

		
		try {
			// Create the database from it
			//Writer sqlWriter = new OutputStreamWriter(System.out);
			File f = new File("programOutput.sql");
			FileWriter sqlWriter = new FileWriter(f);
			RDBBuilder rdbBuilder = new RDBBuilder(xerModel, schemaFile,sqlWriter);
			rdbBuilder.build();
		}
		catch (IOException e) {
			logger.error("Couldn't build Database." + e);
		}
		
//		Delete any exisiting database schema
//		deleteSchema(schemaFile);
//		executeSQL(sql);
//
//		try {
//			// Create the file for creating the database schema
//			File create = new File("CreateDatabase.sql");
//			create.createNewFile();
//			FileWriter createWriter = new FileWriter(create);
//			createWriter.write(sql);
//			createWriter.flush();
//		}
//		catch (IOException e) {
//			System.out.println("Couldn't create sql file" + e);
//		}

	}

	private static void executeSQL(String sql) {
		Connection conn = DatabaseConnection.getConnection();
		
		String[] statements = sql.split(";");
		String successes = "";
		String failures = "";
		for (int i = 0; i < statements.length; i++) {			
			try {	
				PreparedStatement ps = conn.prepareStatement(statements[i]);
				boolean success= ps.execute();
			} catch (SQLException e) {
				logger.error("FAILED: ");
				logger.error(statements[i]);
			}
			
		}
	}
	
	public static void deleteSchema(File schemaFile){
		schemaName = schemaFile.getName().split(".x")[0];
		String schemaName = schemaFile.getName().split(".x")[0];
		try {
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement ps = conn.prepareStatement("DROP SCHEMA " + schemaName + " CASCADE;");
			ps.execute();
		} catch (SQLException e) {
			logger.info("Schema not found. No schema deletion will take place." + e);
		}
	}

}
