/*
 * Created on 18-May-2004
 *
 */
package xtractor.schemaConverter.xer.xerConstructs;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import xtractor.schemaConverter.xer.XERBuilder;

/**
 * @author ss401
 *
 */
public class XERGeneralization extends XERCompoundConstruct {

	Map entities;
	
	
	//TODO: I think these should be in XER relationship, not here
	int minOccurs;
	int maxOccurs;
	
	
	//Shouldn't have an implicit parent. This is purely for XML element schema purposes;
	//at this level, choice entities don't exist
	//XERCompoundConstruct implicitParent;
	XEREntity mostRecentParentEntity;

	/**
	 * @param generalizationName - The name of the generalization
	 * @param entities - All the entities to which the generalization apply to
	 * @param minOccurs - The minimum number of times the choice collection (AS A WHOLE) can be selected
	 * @param maxOccurs - The maximum number of times the choice collection (AS A WHOLE) can be selected
	 */
	public XERGeneralization(
		String generalizationName,
		Collection entities,
		int minOccurs,
		int maxOccurs,
		XERBuilder xerBuilder) {
		super(xerBuilder);
		this.entities = new HashMap();
		for (Iterator iter = entities.iterator(); iter.hasNext();) {
			XEREntity entity = (XEREntity) iter.next();
			this.entities.put(entity.getName(), entity);
		}
		this.name = generalizationName;
		this.minOccurs = minOccurs;
		this.maxOccurs = maxOccurs;
		this.attributes = new HashMap();
	}

	public void addConstruct(XERConstruct xerConstruct, int minOccurs, int maxOccurs) {
		if (xerConstruct instanceof XEREntity) {
			XEREntity entity = (XEREntity) xerConstruct;
			entities.put(entity.getName(), entity);
			entity.setImplicitParent(this);
		}
		else if (xerConstruct instanceof XERAttribute) {
			XERAttribute attribute = (XERAttribute) xerConstruct;
			attributes.put(attribute.getName(), attribute);
			
			if(attribute instanceof XERPrimaryKey) {
				XERPrimaryKey key = (XERPrimaryKey)attribute; 
				super.keyAttributes.add(key);
			}
			else if(attribute instanceof XERForeignKey){
				foreignKeyAttributes.add(attribute);
			}
			
		}
		else {
			logger.warn("Unimplemented case");
		}

	}


	public String toString() {
		String str = getName() + "(";
		for (Iterator iter = entities.values().iterator(); iter.hasNext();) {
			XEREntity xerEntity = (XEREntity) iter.next();
			str += xerEntity.getName();
			if (iter.hasNext()) {
				str += ",";
			}
		}
		str = removeLastComma(str);
		str += ",";

		for (Iterator iter = attributes.values().iterator(); iter.hasNext();) {
			XERAttribute xerAttribute = (XERAttribute) iter.next();
			str += xerAttribute.getName();
			if (iter.hasNext()) {
				str += ",";
			}
		}

		str = removeLastComma(str);

		str += ")";
		return str;
	}

	/**
	 * @return - The minimum number of times the whole collection of choices can be selected
	 */
	public int getMinOccurs() {
		return minOccurs;
	}

	/**
	 * @return - The maximum number of times the whole collection of choices can be selected
	 */
	public int getMaxOccurs() {
		return maxOccurs;
	}

	/* (non-Javadoc)
	 * @see xtractor.schemaConverter.xer.xerConstructs.XERCompoundConstruct#getAttribute(java.lang.String)
	 */
	public XERAttribute getAttribute(String attributeName) {
		
		return (XERAttribute) attributes.get(attributeName);
	}

	/**
	 * @param entity - The most recent XEREntity above this generalization construct in the XER model hierarchy
	 */
	public void setMostRecentParentEntity(XEREntity entity) {
		this.mostRecentParentEntity = entity;		
	}

	/**
	 * @return - The XEREntity which is closest to this generalization above it in the model hierarchy
	 */
	public XEREntity getMostRecentParentEntity() {
		return this.mostRecentParentEntity;		
	}

	/**
	 * @return - A collection of entities which are specific forms of this generalization
	 */
	public Collection getEntities() {
		return this.entities.values();
	}


//	SHOULDN'T BE HERE - SEE TOP FOR JUSTIFICATION
//	/**
//	 * @param parent - The XER construct which contains this XER entity in the XML hierarchy
//	 */
//	public void setImplicitParent(XERCompoundConstruct parent) {
//		this.implicitParent = parent;
//
//	}
//
//	/**
//		*@return - The XER construct which contains this XER entity in the XML hierarchy
//		*/
//	public XERCompoundConstruct getImplicitParent() {
//
//		return this.implicitParent;
//	}

}
