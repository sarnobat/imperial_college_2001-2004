package xtractor;
import java.io.File;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import xtractor.dataExporter.DataExporter;
import xtractor.dataImporter.DataImporter;
import xtractor.schemaConverter.SchemaConverter;
import xtractor.schemaConverter.exception.NoAssociatedSchemaException;


/*
 * Created on 13-Mar-2004
 *
 */

/**
 * @author ss401
 * This is the API class with all the business logic.
 */
public class XTractor {
	static Logger logger = Logger.getRootLogger();

	/*
	 * -i [xml file] 	: Import xml data
	 * -e [document id]	: Export Data
	 * -l		: List documents
	 */
	public static void main(String[] args) {
		// Initialize logger
		BasicConfigurator.configure();
		logger.setLevel(Level.INFO);

		//translateSchema("schemas/purchaseOrder.xsd");
		//importData("xml/po.xml");
		translateSchema("xml/ss.xsd");
		//logger.info("Schema successfully translated.");
		/*try {
			//importData("xml/parts.xml");
			//logger.debug("\n\n\n\n\n\n");
			//exportXMLFile(1,"ss");
		}
		catch (NoAssociatedSchemaException e) {
			logger.fatal("Couldn't find associated schema." + e);
		}*/
	}

	private static void importData(String xmlFilePath) throws NoAssociatedSchemaException {
		File dataFile = new File(xmlFilePath);
		//DataImporter.importData(dataFile);
		DataImporter dataImporter = new DataImporter();
		dataImporter.importData(dataFile);
	}

	private static void translateSchema(String xsdFilePath) {
		/*
		 * get the attached schema
		 * validate the document against it
		 * IF Schema not previously encountered
		 * 	create schema
		 * perform import of XML file data
		 * add the document to the document.xml list which includes id,date,database,comment
		 * 	 
		 */
		File schemaFile = new File(xsdFilePath);
		SchemaConverter.convertSchema(schemaFile);

	}

	public static void exportXMLFile(int docId, String databaseSchemaName) {
		/*
		 * create xml document
		 * validate against schema
		 * Tell the user the location of the xml file generated
		 */
		DataExporter dataExporter = new DataExporter(databaseSchemaName);
		dataExporter.exportData(docId);
	}

	private static void listImportedDocuments() {
		/*
		 * Iterate through xml file
		 * 	print a list of documents
		 */
	}
}
