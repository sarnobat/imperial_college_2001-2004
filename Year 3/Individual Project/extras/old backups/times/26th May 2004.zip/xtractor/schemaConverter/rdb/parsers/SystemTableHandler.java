/*
 * Created on 24-May-2004
 *
 */
package xtractor.schemaConverter.rdb.parsers;

import databaseConnection.Nomenclature;
import xtractor.schemaConverter.rdb.RDBBuilder;

/**
 * @author ss401
 *
 */
public class SystemTableHandler {

	final String DELIMITER;
	final String schemaName;
	private final String SYSTEM_PREFIX = Nomenclature.SYSTEM_PREFIX;
	final String TABLE_CONTAINMENT = "table_containment";
	final String ELEMENT_LOCATIONS = "element_locations";

	// System table names

	public SystemTableHandler(RDBBuilder rdbBuilder) {
		this.DELIMITER = rdbBuilder.getDelimiter();
		this.schemaName = rdbBuilder.getSchemaName();

	}
	/**
	 * @return - A string of SQL code to create a table with the following structure:
	 * ss.SYSTEM_element_locations(element_name,table_name,column_name)
	 * 		columnName - The name of the column where a simple element's data should be stored 
	 * 					(null if the element is complex)
	 * 		table_name - The name of the table where this column is located OR
	 * 					 the name of the table holding a complex element's attributes
	 * This will also be useful if the user renames the tables or columns
	 */
	public String createElementLocation() {
		String sql = "CREATE TABLE " + getSystemTableName(ELEMENT_LOCATIONS) + " (\n";
		sql += DELIMITER + "element_name" + DELIMITER + "VARCHAR(50) NOT NULL UNIQUE,\n";
		sql += DELIMITER + "table_name" + DELIMITER + "VARCHAR(50) NOT NULL,\n";
		sql += DELIMITER + "column_name" + DELIMITER + "VARCHAR(50)\n";

		sql += "\n);";
		return sql;
	}

	/**
	 * Gets the SQL code to add a system table entry saying where an XML element's data should be
	 * inserted
	 * @param elementName - An element of simple type
	 * @param tableName - The table where the attribute that the XML element's value should be inserted is found
	 * @param attributeName - The name of the attribute where the XML element's value should be inserted
	 * @return
	 */
	public String addElementLocation(String elementName, String tableName, String attributeName) {
		String sql =
			"INSERT INTO "
				+ getSystemTableName("element_locations")
				+ "(element_name,table_name,column_name) VALUES ('"
				+ elementName
				+ "','"
				+ tableName
				+ "','"
				+ attributeName
				+ "');\n";
		return sql;
	}

	/**
	 * 
	 * @param elementName - An element of complex type
	 * @param tableName
	 * @return
	 */
	public String addElementLocation(String elementName, String tableName) {
		String sql =
			"INSERT INTO "
				+ getSystemTableName("element_locations")
				+ "(element_name,table_name) VALUES ('"
				+ elementName
				+ "','"
				+ tableName
				+ "');\n";
		return sql;
	}

	/**
	 * 
	 * @param tableName - The name of the table excluding any schema name or prefix
	 * @return - The fully qualified name of the table
	 */
	private String getSystemTableName(String tableName) {
		return schemaName + "." + SYSTEM_PREFIX + tableName;
	}

	/**
	 * @return - SQL code to generate a system table which says which table references which
	 * "table" is the name of a table containing a foreign key to "foreign_table". Do not think
	 * about it in any other terms (e.g.Entity relationships) otherwise you may get it the
	 * wrong way round
	 */
	public String createTableContainment() {
		String sql = "";

		sql += "CREATE TABLE " + getSystemTableName(TABLE_CONTAINMENT) + " (\n";
		sql += DELIMITER + "referring_table" + DELIMITER + "VARCHAR(50),\n";
		sql += DELIMITER + "foreign_table" + DELIMITER + "VARCHAR(50)";
		//sql += ",\n" + DELIMITER + "PRIMARY KEY (table,foreign_table)\n";
		sql += ");\n";
		return sql;
	}
	/**
	 * @param referringTable - The unqualified name of a data table which contains a foreign key reference
	 * to 'foreign table'
	 * @param foreignTable - The table whose primary key appears as a foreign key in the referring
	 * table
	 * @return - The SQL code to add an entry to the table_containment table 
	 */
	public String addTableContainment(String referringTable, String foreignTable) {
		String sql =
			"INSERT INTO "
				+ getSystemTableName(TABLE_CONTAINMENT)
				+ "(referring_table,foreign_table) VALUES ('"
				+ referringTable
				+ "','"
				+ foreignTable
				+ "');\n";
		return sql;
	}
}
