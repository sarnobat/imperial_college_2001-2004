

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import GUI.GUIController;

/*
 * Created on 15-May-2004
 *
 */

/**
 * @author ss401
 * This is the class that is invoked when the application is launched
 */
public class Application {
	static Logger logger = Logger.getRootLogger();
	public static void main(String[] args) {
		// Initialize logger
		BasicConfigurator.configure();
		logger.setLevel(Level.DEBUG);


		// TODO: This shouldn't be here; it's just for some testing
		/*File dataFile = new File("xml/parts.xml");
		DataImporter dataImporter = new DataImporter();
		try {
			dataImporter.importData(dataFile);
		}
		catch (NoAssociatedSchemaException e) {
			logger.error("." + e);
		}*/

		//Console c = new Console();
		GUIController g = new GUIController();
	}
}
