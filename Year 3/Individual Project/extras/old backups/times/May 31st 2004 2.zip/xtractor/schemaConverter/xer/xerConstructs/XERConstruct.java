/*
 * Created on 18-May-2004
 *
 */
package xtractor.schemaConverter.xer.xerConstructs;

import xtractor.schemaConverter.xer.XERBuilder;
import xtractor.schemaConverter.xer.XERFactory;

/**
 * @author ss401
 *
 */
public abstract class XERConstruct {

	XERBuilder xerBuilder;

	/**
	 * @param xerBuilder
	 */
	public XERConstruct(XERBuilder xerBuilder) {
		this.xerBuilder = xerBuilder;
	}
	
	public abstract String getName();

	/**
	 * Useful for the toString() methods.
	 * @param str - The string you wish to truncate
	 * @return - The same string as given, but if the last character is 
	 * a comma then it is removed.
	 */
	protected String removeLastComma(String str) {
		if (str.charAt(str.length() - 1) == (',')) {
			str = str.substring(0, str.length() - 1);
		}
		return str;

	}
	
	protected XERFactory getXERFactory(){
		return xerBuilder.getXERFactory();
	}
	public final String toString() {
		return getName();
	}

}
