/*
 * Created on 31-May-2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package GUI;

import java.io.File;

import xtractor.XTractor;
import xtractor.schemaConverter.xer.XERModel;

import GUI.windows.rdbCreator.RDBCreationWindowController;
import GUI.windows.xerModelView.XERWindowController;

/**
 * @author ss401
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class GUIController {

	// Dimensions
	public int height = 500;
	public int width = 500;
	public int locationX = 100;
	public int locationY = 100;

	XERWindowController xerWindowController;
	
	RDBCreationWindowController rdbWindowController;
	
	File xsdFile;

	public GUIController() {

		this.xsdFile = new File("xml/ss.xsd");

		xerWindowController =
			new XERWindowController(this, createXERModel(xsdFile));
		rdbWindowController = new RDBCreationWindowController(this,xsdFile);
	}

	/**
	 * @param xsdFile
	 */
	private XERModel createXERModel(File xsdFile) {
		return XTractor.getXERModel(xsdFile);

	}

	/**
	 * 
	 */
	public void createDatabase(XERModel model) {
		xerWindowController.disposeWindow();
		rdbWindowController.showWindow();
		rdbWindowController.createDatabase(model);
		

	}

}
