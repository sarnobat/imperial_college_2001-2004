/*
 * Created on 31-May-2004
 *
 */
package GUI.windows.xerModelView.xerConstructSummary;

import java.awt.GridLayout;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JTextField;

import xtractor.schemaConverter.xer.xerConstructs.XERAttribute;
import xtractor.schemaConverter.xer.xerConstructs.XEREntity;
import GUI.windows.xerModelView.XERWindowController;

/**
 * @author ss401
 *
 */
public class XEREntitySummary extends XERConstructSummary {

	XEREntity entity;

	/**
	 * @param c
	 */
	public XEREntitySummary(XERWindowController c, XEREntity entity) {
		super(c);
		this.entity = entity;
		setup();
	}

	protected void setup() {

		List rows = new LinkedList();

		// Name
		String[] values = { "Entity Name:", entity.getName()};

		// Attributes
		Collection c = entity.getAttributes();
		for (Iterator iter = c.iterator(); iter.hasNext();) {
			XERAttribute attribute = (XERAttribute) iter.next();
			String[] attributeValues =
				{ attribute.getName(), attribute.getType()};
			rows.add(attributeValues);
		}

		this.setLayout(new GridLayout(rows.size(), 2));

		/*entityNameLabel = new JLabel("Entity name:");
		this.add(entityNameLabel);
		entityNameValueField = new JTextField(entity.getName());
		this.add(entityNameValueField);*/
		for (Iterator iter = rows.iterator(); iter.hasNext();) {
			String[] row = (String[]) iter.next();

			JLabel label = new JLabel(row[0]);
			this.add(label);
			JTextField value = new JTextField(row[1]);
			this.add(value);
		}
	}
}
