/*
 * Created on 31-May-2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package GUI.windows.rdbCreator;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.Writer;

/**
 * @author ss401
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class DialogWriter extends Writer {

	DialogArea dialog;

	//String buffer = "";

	/**
	 * @param out
	 */
	public DialogWriter(DialogArea dialog) {
		//super(new PrintWriter());
		//super(System.out);
		this.dialog = dialog;
	}

	/*public void write(String s) {
		dialog.append(s);
		this.flush();
	}*/

	/* (non-Javadoc)
	 * @see java.io.Writer#write(char[], int, int)
	 */
	public void write(char[] cbuf, int off, int len) throws IOException {
	}

	public void write(String s) {
		//buffer += s;
		dialog.append(s);
	dialog.invalidate();
	dialog.repaint();
	}

	/* (non-Javadoc)
	 * @see java.io.Writer#flush()
	 */
	public void flush() throws IOException {
		// TODO Auto-generated method stub
		//dialog.append(buffer);
		//buffer = "";

	}

	/* (non-Javadoc)
	 * @see java.io.Writer#close()
	 */
	public void close() throws IOException {
		// TODO Auto-generated method stub

	}

}
