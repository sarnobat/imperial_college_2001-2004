/*
 * Created on 31-May-2004
 *
 */
package GUI.windows.xerModelView;

import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.io.File;

import org.apache.log4j.Logger;

import xtractor.schemaConverter.xer.XERModel;
import GUI.GUIController;
import GUI.windows.xerModelView.xerTreeComponents.XERNode;
import GUI.windows.xerModelView.xerTreeComponents.XERRootNode;

/**
 * @author ss401
 *
 */
public class XERWindowController {

	Logger logger = Logger.getLogger(this.getClass());


	GUIController guiController;

	// GUI Components
	
	public XERFrame xerViewFrame;
	public XERTree xerTree;
	public SummaryPanel summary;
	public CreateRDBButton createRDBButton;

	// Objects
	XERModel xerModel;
	File xsdFile;

	public XERWindowController(GUIController guiController,XERModel xerModel) {

		this.guiController = guiController;


		this.xerViewFrame = new XERFrame(this,guiController);
		this.xerModel = xerModel;//createXERModel();
		XERRootNode root = new XERRootNode(this, xerModel);
		this.xerTree = new XERTree(this, root);
		this.summary = new SummaryPanel(this);
		this.createRDBButton = new CreateRDBButton(this,"Create Relational Database");
		showXERViewWindow();
		

	}

	
//	private XERModel createXERModel() {
//
//		return XTractor.getXERModel(xsdFile);
//	}

	private void showXERViewWindow() {
		Container pane = xerViewFrame.getContentPane();

		pane.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.BOTH;

		c.gridx = 0;
		c.gridy = 0;
		//c.gridheight = 2;
		//c.gridwidth = 1;
		c.weightx = 0.5;
		c.weighty = 1;
		pane.add(xerTree, c);

		//createRDBButton.setPreferredSize(new Dimension(10,10));
		c.gridx = 1;
		c.gridy = 1;
		//c.gridheight = 1;
		//c.gridwidth = 1;
		//c.weightx = 0.1;
		c.weighty = 0;
		pane.add(createRDBButton, c);

		c.gridx = 1;
		c.gridy = 0;
		//c.gridheight = 1;
		//c.gridwidth = 1;
		c.weightx = 1;
		pane.add(summary, c);

		/*label = new JLabel("label");
		c.gridx = 1;
		c.gridy = 1;
		//c.gridheight = 1;
		pane.add(label, c);*/
		

		

		xerViewFrame.show();

	}

	public XERModel getXERModel() {
		return xerModel;
	}

	public void updateObjectSummary(Object construct, XERNode node) {
		summary.removeAll();
		summary.addSummary(construct);
		// Both of these are needed.			
		xerViewFrame.update(xerViewFrame.getGraphics());
		summary.validate();

		logger.debug(
			"Updated summary panel. Now displaying info for " + construct);

	}

	public void createRelationalDatabase() {
		/*xerViewWindow.dispose();
		showSchemaCreator();
		XTractor.createRelationalDatabase(xerModel,xsdFile);*/
		guiController.createDatabase(xerModel);
		
	}


	public void disposeWindow() {
		xerViewFrame.dispose();		
	}

}
