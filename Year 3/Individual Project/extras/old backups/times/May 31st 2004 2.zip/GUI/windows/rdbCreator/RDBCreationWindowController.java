/*
 * Created on 31-May-2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package GUI.windows.rdbCreator;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

import xtractor.XTractor;
import xtractor.schemaConverter.SchemaConverter;
import xtractor.schemaConverter.xer.XERModel;
import GUI.GUIController;

/**
 * @author ss401
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class RDBCreationWindowController {

	GUIController guiController;

	RDBCreationFrame rdbCreationFrame;

	DialogArea dialog;
	DialogWriter dialogWriter;

	File xsdFile;

	public RDBCreationWindowController(
		GUIController controller,
		File xsdFile) {
		this.guiController = controller;
		this.xsdFile = xsdFile;

	}

	/**
	 * 
	 */
	public void showWindow() {
		this.rdbCreationFrame = new RDBCreationFrame(this, guiController);
		this.dialog = new DialogArea(this);

		this.dialogWriter = new DialogWriter(dialog);

		rdbCreationFrame.getContentPane().add(dialog);

		rdbCreationFrame.show();
	}

	/**
	 * @param model
	 */
	public void createDatabase(XERModel model) {
		XTractor.createRelationalDatabase(model, xsdFile, dialogWriter);
		/*File creationScript = XTractor.createScript(model, xsdFile);
		Collection statements;
		try {

			FileReader r = new FileReader(creationScript);
			statements = SchemaConverter.getStatements(r);
			for (Iterator iter = statements.iterator(); iter.hasNext();) {
				String s = (String) iter.next();
				dialog.append(s);

			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

	}
}
