/*
 * Created on 31-May-2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package GUI.windows.rdbCreator;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Writer;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * @author ss401
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class DialogArea extends JTextArea {

	public DialogArea(RDBCreationWindowController controller) {
		this.setLineWrap(true);
	}
	//	window elements
	JTextArea textDisplay;
	JScrollPane scrollPane;
	//
	//	private OutputStream out = new ConsoleStream(this);
	//	private PrintStream pout = new PrintStream(out, true);
	//
	//	public DialogArea() {
	//		super()

	/*this.setLayout(new GridLayout(1, 1));
	
	textDisplay = new JTextArea();
	textDisplay.setVisible(true);
	textDisplay.setEditable(false);
	textDisplay.setLineWrap(false);
	textDisplay.setWrapStyleWord(true);
	textDisplay.setFont(new Font("Monospaced", Font.PLAIN, 10));
	
	scrollPane = new JScrollPane();
	scrollPane.getViewport().setView(textDisplay);
	
	this.add(scrollPane);*/
	

}
