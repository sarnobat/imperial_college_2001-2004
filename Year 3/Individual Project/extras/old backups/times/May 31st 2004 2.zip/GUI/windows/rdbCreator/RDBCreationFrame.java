/*
 * Created on 31-May-2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package GUI.windows.rdbCreator;

import GUI.GUIController;
import GUI.windows.XTractorFrame;

/**
 * @author ss401
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class RDBCreationFrame extends XTractorFrame {

	/**
	 * @param controller
	 */
	public RDBCreationFrame(RDBCreationWindowController controller,GUIController guiController) {
		super(guiController);
	}

}
