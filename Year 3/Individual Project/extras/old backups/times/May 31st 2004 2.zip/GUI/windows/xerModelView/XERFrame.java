/*
 * Created on 31-May-2004
 *
 */
package GUI.windows.xerModelView;

import org.apache.log4j.Logger;

import GUI.GUIController;
import GUI.windows.XTractorFrame;

/**
 * @author ss401
 *
 */
public class XERFrame extends XTractorFrame {

	Logger logger = Logger.getLogger(this.getClass());

	/**
	 * 
	 */
	public XERFrame(XERWindowController c, GUIController guiController) {
		super(guiController);

	}

}
