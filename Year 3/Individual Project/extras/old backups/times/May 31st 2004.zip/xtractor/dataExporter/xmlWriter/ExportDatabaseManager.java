/*
 * Created on 13-May-2004
 */
package xtractor.dataExporter.xmlWriter;

import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;

import databaseConnection.Nomenclature;
import databaseConnection.databaseManager.PostDatabaseManager;

/**
 * @author ss401
 */
public class ExportDatabaseManager extends PostDatabaseManager {

	public ExportDatabaseManager(String databaseSchemaName) {
		super(databaseSchemaName);
	}

	/**
	 * @param id - The globally unique id of an element
	 * @return - The Collection (of Strings) of names of all the elements which 
	 * can (in theory) appear as a child of the given element 
	 */
	private Collection getChildElementNames(int id) {
		Collection c = new LinkedList();
		String elementName = getElementName(id);
		String unqualifiedMetaTableName = getUnqualifiedTableName(getMetaTableName(elementName)).toLowerCase();

		try {
			String metaPrefix = (Nomenclature.META_PREFIX).toLowerCase();
			DatabaseMetaData metaData = conn.getMetaData();
			ResultSet rs = metaData.getImportedKeys(null, schemaName, null);
			while (rs.next()) {
				String parentTable = rs.getString("PKTABLE_NAME");
				String childTable = rs.getString("FKTABLE_NAME");

				if (parentTable.equals(unqualifiedMetaTableName)) {
					if (childTable.startsWith(metaPrefix)) {
						//System.out.println(childTable + "-->" + parentTable);
						c.add(Nomenclature.removeMetaDecorator(childTable));
					}
				}

			}
		}
		catch (SQLException e) {
			logger.error("Couldn't determine what meta tables contain pid references to the given id. " + e);
		}

		return c;
	}


	/**
	 * @param parentId - the id of the parent element
	 * @return - a map of all child elements' order to their unique id
	 */
	public TreeMap getOrdsToIds(int parentId) {
		TreeMap ordsToIds = new TreeMap();

		// The first thing we need to do is determine what tables to look in
		Collection childElementNames = getChildElementNames(parentId);
		for (Iterator iter = childElementNames.iterator(); iter.hasNext();) {
			String childElementName = (String) iter.next();
			String metaTableName = getMetaTableName(childElementName);

			String sql = "SELECT id,ord FROM " + metaTableName + " WHERE pid=" + parentId;
			ResultSet rs = executeQuery(sql);
			try {
				while (rs.next()) {
					int ord = rs.getInt("ord");
					int id = rs.getInt("id");
					ordsToIds.put(new Integer(ord), new Integer(id));
				}
			}
			catch (SQLException e) {
				logger.error("Couldn't create ord to id map." + e);
			}
		}

		return ordsToIds;
	}

	public Map getIdsToElementNames(int parentId) {
		TreeMap idsToElementNames = new TreeMap();

		// The first thing we need to do is determine what tables to look in
		Collection childElementNames = getChildElementNames(parentId);
		for (Iterator iter = childElementNames.iterator(); iter.hasNext();) {
			String childElementName = (String) iter.next();
			String metaTableName = getMetaTableName(childElementName);

			String sql = "SELECT id,ord FROM " + metaTableName + " WHERE pid=" + parentId;
			ResultSet rs = executeQuery(sql);
			try {
				while (rs.next()) {
					int id = rs.getInt("id");
					idsToElementNames.put(new Integer(id), childElementName);
				}
			}
			catch (SQLException e) {
				logger.error("Couldn't create ord to id map." + e);
			}
		}

		return idsToElementNames;
	}

	/**
	 * 
	 * @param parentId
	 * @return - A map from Integer (id) to a Map (of attribute name,attribute value pairs)
	 */
	public Map getIdsToAttributeMap(int parentId) {
		Map idsToAttributeMap = new TreeMap();

		// The first thing we need to do is determine what tables to look in
		Collection childElementNames = getChildElementNames(parentId);
		for (Iterator iter = childElementNames.iterator(); iter.hasNext();) {
			String childElementName = (String) iter.next();

			// Get the result set for this particular element type
			String sql = "SELECT ";
			Collection dataColumnNames = getDataColumnNames(childElementName);
			/*for (Iterator iterator = dataColumnNames.iterator(); iterator.hasNext();) {
				String dataColumnName = (String) iterator.next();
				sql += dataColumnName;
				if (iter.hasNext()) {
					sql += ",";
				}
			}*/
			sql += "* FROM " + getCompleteTableName(childElementName) + " WHERE pid=" + parentId;

			// Get the attribute names and values
			ResultSet rs = executeQuery(sql);
			try {
				while (rs.next()) {
					Map attributeMap = new HashMap();
					int childId = rs.getInt("id");
					for (Iterator iterator = dataColumnNames.iterator(); iterator.hasNext();) {
						String dataColumnName = (String) iterator.next();
						Object dataColumnValue = rs.getObject(dataColumnName);
						attributeMap.put(dataColumnName, dataColumnValue);
					}
					idsToAttributeMap.put(new Integer(childId), attributeMap);
				}
			}
			catch (SQLException e) {
				logger.error("Couldn't get attributes for id." + e);
			}
		}

		return idsToAttributeMap;
	}

	/**
	 * @param elementName
	 * @return
	 */
	private Collection getDataColumnNames(String elementName) {
		Collection columnNames = new LinkedList();
		String sql =
			"SELECT * FROM "
				+ getSystemTableName(Nomenclature.ATTRIBUTES)
				+ " WHERE "
				+ Nomenclature.ATTRIBUTES_element
				+ "='"
				+ elementName
				+ "'";
		ResultSet rs = executeQuery(sql);
		try {
			while (rs.next()) {
				columnNames.add(rs.getString(Nomenclature.ATTRIBUTES_attribute));
			}
		}
		catch (SQLException e) {
			logger.error("Couldn't determine data columns." + e);
		}
		return columnNames;
	}

	public String getCharacterData(int id) {

		String elementName = getElementName(id);
		if (isSimpleElement(elementName)) {
			String sql = "SELECT * FROM " + getCompleteTableName(elementName) + " WHERE id=" + id;
			Object cData = getOnlyResult(sql, elementName);
			
			return Nomenclature.convertAttributeValueToString(cData);
		}
		else if (isMixedElement(elementName)) {
			String sql = "SELECT * FROM " + getCompleteTableName(elementName) + " WHERE id=" + id;
			Object cData = getOnlyResult(sql, elementName);
			return Nomenclature.convertAttributeValueToString(cData);
		}
		else{
			logger.error("Unexpected case.");
			return null;
		}

	}

}
