/*
 * Created on 13-May-2004
 */
package xtractor.dataExporter.xmlWriter;

import java.io.Writer;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;

import xtractor.dataExporter.xmlWriter.databaseManager.ExportDatabaseManager;

/**
 * @author ss401
 */
public class RDBWalker {

	Logger logger = Logger.getLogger(this.getClass());
	Writer fileWriter;
	ExportDatabaseManager databaseManager;
	String databaseSchemaName;

	/**
	 * @param fileWriter - The writer to write the xml output to
	 */
	public RDBWalker(Writer fileWriter, String databaseSchemaName) {
		this.fileWriter = fileWriter;
		this.databaseSchemaName = databaseSchemaName;
		this.databaseManager = new ExportDatabaseManager(databaseSchemaName);
	}

	/**
	 * Does the file writing  
	 * @param rootId - The globally unique root identifier for the element schema
	 */

	public Document writeXMLFile(int id) {
		String rootElementName = databaseManager.getElementName(id);
		Element root = new Element(rootElementName);
		Document doc = new Document(root);

		/*TreeMap m = new TreeMap();
		// find out what tables need to be searched for children
		Collection childElementNames = databaseManager.getChildElementNames(id);
		// in each table...
		for (Iterator iter = childElementNames.iterator(); iter.hasNext();) {
			String childElementName = (String) iter.next();
			// Get the ids of the children
			Collection childIds = databaseManager.getChildIds(id,childElementName);
						
			// Create the children elements and cccumulate them in an ordered map
			for (Iterator iterator = childIds.iterator(); iterator.hasNext();) {
				Integer childId = (Integer) iterator.next();
				Integer order = databaseManager.getOrder(childId,childElementName);
				Map attributes = databaseManager.getAttribtues(childId,childElementName);
				m.put(order,attributes);				
			}				
		}
		
		for (Iterator iter = m.keySet().iterator(); iter.hasNext();) {
			Integer order = (Integer) iter.next();
			Map elementNameTo
			root.addContent(new Element());
		}*/

		//regenerateElement();
		
		TreeMap ordsToIds = databaseManager.getOrdsToIds(id);
		Map idsToElementNames = databaseManager.getIdsToElementNames(id);
		Map idsToAttributeMap = databaseManager.getIdsToAttributeMap(id);

		for (Iterator iter = ordsToIds.keySet().iterator(); iter.hasNext();) {
			Integer ord = (Integer) iter.next();
			Integer childId = (Integer) ordsToIds.get(ord);
			Map attributeNamesToValues = (Map) idsToAttributeMap.get(childId);
			String elementName = (String) idsToElementNames.get(childId);
			insertElement(root,elementName,attributeNamesToValues);			
		}

		return doc;

	}


	/**
	 * This must be called in the right order for each element
	 * @param parent - e.g. <ps_db>
	 * @param elementName - e.g. "part"
	 * @param attributeNamesToValues - String to String, e.g. ["pno"-->"100","colour"-->"red",price-->"20"]
	 */
	private void insertElement(Element parent, String elementName, Map attributeNamesToValues) {
		Element child = new Element(elementName);
		for (Iterator iter = attributeNamesToValues.keySet().iterator(); iter.hasNext();) {
			String attributeName = (String) iter.next();
			String attributeValue = (String) attributeNamesToValues.get(attributeName);
			child.setAttribute(new Attribute(attributeName, attributeValue));
		}
		parent.addContent(child);
	}

}
