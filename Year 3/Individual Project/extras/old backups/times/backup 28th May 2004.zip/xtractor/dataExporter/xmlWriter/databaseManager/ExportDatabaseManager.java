/*
 * Created on 13-May-2004
 */
package xtractor.dataExporter.xmlWriter.databaseManager;

import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.jdom.Element;

import databaseConnection.AbstractDatabaseManager;
import databaseConnection.Nomenclature;

/**
 * @author ss401
 */
public class ExportDatabaseManager extends AbstractDatabaseManager {

	//Logger logger = Logger.getLogger(this.getClass());
	//Connection conn;
	//String schemaName;

	public ExportDatabaseManager(String databaseSchemaName) {
		super(databaseSchemaName);
		//this.conn = DatabaseConnection.getConnection();
		//this.schemaName = databaseSchemaName;
	}

	/**
	 * @param id - The globally unique id of an element
	 * @return - The Collection (of Strings) of names of all the elements which 
	 * can (in theory) appear as a child of the given element 
	 */
	private Collection getChildElementNames(int id) {
		Collection c = new LinkedList();
		String elementName = getElementName(id);
		String unqualifiedMetaTableName = getUnqualifiedTableName(getMetaTableName(elementName)).toLowerCase();

		try {
			String metaPrefix = (Nomenclature.META_PREFIX).toLowerCase();
			DatabaseMetaData metaData = conn.getMetaData();
			ResultSet rs = metaData.getImportedKeys(null, schemaName, null);
			while (rs.next()) {
				String parentTable = rs.getString("PKTABLE_NAME");
				String childTable = rs.getString("FKTABLE_NAME");

				if (parentTable.equals(unqualifiedMetaTableName)) {
					if (childTable.startsWith(metaPrefix)) {
						//System.out.println(childTable + "-->" + parentTable);
						c.add(Nomenclature.removeMetaDecorator(childTable));
					}
				}

			}
		}
		catch (SQLException e) {
			logger.error("Couldn't determine what meta tables contain pid references to the given id. " + e);
		}

		return c;
	}
	//
	//	/**
	//	 * @param parentId - The globally unique id of a parent element whose children
	//	 * we wish to determine
	//	 * @return - A list of ids for elements SORTED BY ORDER (not id number) 
	//	 */
	//	public List getChildren(int parentId) {
	//		logger.warn("Unimplemented Method");
	//		//Collections.sort((List) ids); - THIS SHOULD BE SORTED BY ORDER, NOT ID
	//		return null;
	//	}

	/**
	 * @param id - The globally unique element schema id for an element
	 * @return - The element name (i.e. table name) for 'id'
	 */
	public String getElementName(int id) {
		String sql = "SELECT table_name FROM " + getSchemaTableName(Nomenclature.IDS_TO_TABLES) + " WHERE id = " + id;
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				return rs.getString("table_name");
			}
			logger.error("No table contains a row with id " + id);
		}
		catch (SQLException e) {
			logger.error("Couldn't determine which table id " + id + " belongs to." + e);
			logger.error("Statement was: " + sql);
		}
		return null;
	}

	/**
	 * @param parentId - the id of the parent element
	 * @return - a map of all child elements' order to their unique id
	 */
	public TreeMap getOrdsToIds(int parentId) {
		TreeMap ordsToIds = new TreeMap();

		// The first thing we need to do is determine what tables to look in
		Collection childElementNames = getChildElementNames(parentId);
		for (Iterator iter = childElementNames.iterator(); iter.hasNext();) {
			String childElementName = (String) iter.next();
			String metaTableName = getMetaTableName(childElementName);

			String sql = "SELECT id,ord FROM " + metaTableName + " WHERE pid=" + parentId;
			ResultSet rs = executeQuery(sql);
			try {
				while (rs.next()) {
					int ord = rs.getInt("ord");
					int id = rs.getInt("id");
					ordsToIds.put(new Integer(ord), new Integer(id));
				}
			}
			catch (SQLException e) {
				logger.error("Couldn't create ord to id map." + e);
			}
		}

		return ordsToIds;
	}

	public Map getIdsToElementNames(int parentId) {
		TreeMap idsToElementNames = new TreeMap();

		// The first thing we need to do is determine what tables to look in
		Collection childElementNames = getChildElementNames(parentId);
		for (Iterator iter = childElementNames.iterator(); iter.hasNext();) {
			String childElementName = (String) iter.next();
			String metaTableName = getMetaTableName(childElementName);

			String sql = "SELECT id,ord FROM " + metaTableName + " WHERE pid=" + parentId;
			ResultSet rs = executeQuery(sql);
			try {
				while (rs.next()) {
					int id = rs.getInt("id");
					idsToElementNames.put(new Integer(id), childElementName);
				}
			}
			catch (SQLException e) {
				logger.error("Couldn't create ord to id map." + e);
			}
		}

		return idsToElementNames;
	}

	/**
	 * 
	 * @param parentId
	 * @return - A map from Integer (id) to a Map (of attribute name,attribute value pairs)
	 */
	public Map getIdsToAttributeMap(int parentId) {
		Map idsToAttributeMap = new TreeMap();

		// The first thing we need to do is determine what tables to look in
		Collection childElementNames = getChildElementNames(parentId);
		for (Iterator iter = childElementNames.iterator(); iter.hasNext();) {
			String childElementName = (String) iter.next();

			// Get the result set for this particular element type
			String sql = "SELECT ";
			Collection dataColumnNames = getDataColumnNames(childElementName);
			/*for (Iterator iterator = dataColumnNames.iterator(); iterator.hasNext();) {
				String dataColumnName = (String) iterator.next();
				sql += dataColumnName;
				if (iter.hasNext()) {
					sql += ",";
				}
			}*/
			sql += "* FROM " + getCompleteTableName(childElementName) + " WHERE pid=" + parentId;
			
			// Get the attribute names and values
			ResultSet rs = executeQuery(sql);
			while(rs.next()){
				Map attributeMap = new HashMap();
				int childId = rs.getInt("id");
				for (Iterator iterator = dataColumnNames.iterator(); iterator.hasNext();) {
					String dataColumnName = (String) iterator.next();
					Object dataColumnValue = rs.getObject(dataColumnName);
					attributeMap.put(dataColumnName,dataColumnValue);
				}
				idsToAttributeMap.put(new Integer(childId),attributeMap);
			}			
		}

		return idsToAttributeMap;
	}

	/**
	 * @param childElementName
	 * @return
	 */
	private Collection getDataColumnNames(String childElementName) {
		logger.warn("Unimplemented Method");
		return null;
	}

	//	/**
	//	 * This will not be an exhaustive list of children. Only the children which are of type 'childElementName'
	//	 * @param parentId - The id of the parent element
	//	 * @param childElementName - The name of the element (i.e. the table) to look for children in
	//	 * @return - A List of Maps, where each map contains (name,value) pairs for each column
	//	 */
	//	public List getChildrenElements(int parentId, String childElementName) {
	//
	//		List attributeMaps = new LinkedList();
	//		String sql = "SELECT id FROM " + getCompleteTableName(childElementName) + " WHERE pid=" + parentId + " ORDER BY ord";
	//		PreparedStatement ps;
	//		try {
	//			ps = conn.prepareStatement(sql);
	//			ResultSet rs = ps.executeQuery();
	//
	//			while (rs.next()) {
	//				int childId = rs.getInt("id");
	//				attributeMaps.add(getAttributeMap(childId, childElementName));
	//			}
	//		}
	//		catch (SQLException e) {
	//			logger.error("Couldn't obtain child element information." + e);
	//		}
	//		return attributeMaps;
	//	}
	//
	//	/**
	//	 * 
	//	 * @param id - The globally unique id of the row whose data we wish to fetch
	//	 * @return - A Map from attribute names to attribute values for 'id'
	//	 */
	//	private Map getAttributeMap(int id, String elementName) {
	//
	//		String dataTable = getDataTableName(elementName);
	//		String metaTable = getMetaTableName(elementName);
	//		Collection keyCols = getKeyColumnNames(elementName);
	//		//A Semi Join
	//		String sql =
	//			"SELECT " + dataTable + ".* FROM " + dataTable + "," + metaTable + " WHERE " + metaTable + ".id = " + id + " AND ";
	//		for (Iterator iter = keyCols.iterator(); iter.hasNext();) {
	//			String keyColumnName = (String) iter.next();
	//			sql += dataTable + "." + keyColumnName + "=" + metaTable + "." + keyColumnName;
	//			if (iter.hasNext()) {
	//				sql += " AND ";
	//			}
	//		}
	//		Map attributeMap = new HashMap();
	//		try {
	//			PreparedStatement ps = conn.prepareStatement(sql);
	//			ResultSet rs = ps.executeQuery();
	//			ResultSetMetaData rsMeta = rs.getMetaData();
	//
	//			List attributes = getAttributeOrdering(elementName);
	//
	//			while (rs.next()) {
	//				for (Iterator iter = attributes.iterator(); iter.hasNext();) {
	//					String columnName = (String) iter.next();
	//					String columnValue = rs.getString(columnName);
	//					attributeMap.put(columnName, columnValue);
	//				}
	//			}
	//		}
	//		catch (Exception e) {
	//			logger.debug("Getting attribute map:\n" + sql);
	//			logger.error("Couldn't get attribute map. " + e);
	//		}
	//
	//		return attributeMap;
	//	}
	//
	//	/**
	//	 * The ordering will rely on the order that the attributes appear in the table.
	//	 * @param childElementName - The name of an xml element
	//	 * @return - A list (of Strings) in the order the attributes should appear
	//	 * inside the element tag.
	//	 */
	//	public List getAttributeOrdering(String elementName) {
	//		List attributes = new LinkedList();
	//		String sql = "SELECT * FROM " + getDataTableName(elementName);
	//
	//		PreparedStatement ps;
	//		try {
	//			ps = conn.prepareStatement(sql);
	//
	//			ResultSet rs = ps.executeQuery();
	//			//rs.next();
	//			ResultSetMetaData rsMeta = rs.getMetaData();
	//			int columnCount = rsMeta.getColumnCount();
	//
	//			for (int i = 1; i <= columnCount; i++) {
	//				attributes.add(rsMeta.getColumnName(i));
	//			}
	//		}
	//		catch (SQLException e) {
	//			logger.debug("Attempting to get a list of attributes for " + elementName + "\n\t" + sql);
	//			logger.error("Couldn't determine ordering of columns." + e);
	//		}
	//		return attributes;
	//	}
	//
	//	/**
	//	 * Note: This is not an exhaustive list of children; only those of the given element type
	//	 * @param pid - The id of the parent
	//	 * @param childElementName - The name of the child element in whose meta tables we
	//	 * hope to find elements whose pids match ours
	//	 * @return - A List of ids (integers) whose pids equal this pid
	//	 * NOTE: these are ordered by the 'ord' attribute
	//	 */
	//	public List getChildIds(int pid, String childElementName) {
	//		
	//		List childIds = new LinkedList();;
	//		
	//		try {
	//			String metaTableName = getMetaTableName(childElementName);
	//			String sql = "SELECT * FROM " +metaTableName + " WHERE pid=" +pid +" ORDER BY ord";
	//			ResultSet rs = executeQuery(sql);
	//			while(rs.next()){
	//				childIds.add(new Integer(rs.getInt("id")));
	//			}
	//		}
	//		catch (SQLException e) {
	//			logger.error("Couldn't determine children elements." + e);
	//		}
	//		return childIds;
	//	}

}
