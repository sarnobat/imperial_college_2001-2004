/*
 * Created on 28-May-2004
 *
 */
package databaseConnection.databaseManager;

/**
 * @author ss401
 *
 */
public class PreDatabaseManager extends AbstractDatabaseManager {

	/**
	 * @param databaseSchemaName
	 */
	public PreDatabaseManager(String databaseSchemaName) {
		super(databaseSchemaName);
	}



}
