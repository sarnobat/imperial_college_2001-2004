/*
 * Created on 28-May-2004
 *
 */
package databaseConnection.databaseManager;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author ss401
 * This manager assumes that the schema has already been created and thus
 * we can use the schema to deduce information about the XML files
 */
public class PostDatabaseManager extends AbstractDatabaseManager {

	/**
	 * @param databaseSchemaName
	 */
	public PostDatabaseManager(String databaseSchemaName) {
		super(databaseSchemaName);
	}

	/**
	 * @param elementName - The name of an XML element (e.g. name)
	 * @return - True if its table uses a sequence to determine the primary key value
	 * that should be inserted.
	 */
	public boolean dataTableUsesAutoKey(String elementName) {

		try {
			String[] types = { "SEQUENCE" };
			ResultSet rs = metaData.getTables("pg_class", schemaName, elementName + "%", types);
			if (rs.next()) {
				return true;
			}
			else {
				return false;
			}

		}
		catch (SQLException e) {
			logger.error("Couldn't determine whether " + elementName + " requires an auto key. " + e);
			return false;
		}

	}
	

	/**
	 * @param elementName - e.g. ps_db
	 * @return - The next primary key value that could be given to a row in its table
	 */
	public int getNextId(String elementName) {
		String sequenceName = getSequenceName(elementName);
		ResultSet rs = executeQuery("SELECT nextval('" + sequenceName + "')");
		try {
			if (rs.next()) {
				return rs.getInt("nextval");
			}
			else {
				logger.error("Couldn't determine next sequence value for primary key of " + elementName);
				return 0;
			}
		}
		catch (SQLException e) {
			logger.error("Couldn't determine next sequence value for primary key of " + elementName + ". " + e);
			return 0;
		}
	}
}
