/*
 * Created on 13-May-2004
 */
package xtractor.dataExporter.xmlWriter;

import java.io.Writer;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;


/**
 * @author ss401
 */
public class RDBWalker {

	Logger logger = Logger.getLogger(this.getClass());
	Writer fileWriter;
	ExportDatabaseManager databaseManager;
	String databaseSchemaName;

	/**
	 * @param fileWriter - The writer to write the xml output to
	 */
	public RDBWalker(Writer fileWriter, String databaseSchemaName) {
		this.fileWriter = fileWriter;
		this.databaseSchemaName = databaseSchemaName;
		this.databaseManager = new ExportDatabaseManager(databaseSchemaName);
	}

	/**
	 * Does the file writing  
	 * @param rootId - The globally unique root identifier for the element schema
	 */

	public Document writeXMLFile(int rootId) {
		String rootElementName = databaseManager.getElementName(rootId);
		Element root = new Element(rootElementName);
		Document doc = new Document(root);

		/*TreeMap m = new TreeMap();
		// find out what tables need to be searched for children
		Collection childElementNames = databaseManager.getChildElementNames(id);
		// in each table...
		for (Iterator iter = childElementNames.iterator(); iter.hasNext();) {
			String childElementName = (String) iter.next();
			// Get the ids of the children
			Collection childIds = databaseManager.getChildIds(id,childElementName);
						
			// Create the children elements and cccumulate them in an ordered map
			for (Iterator iterator = childIds.iterator(); iterator.hasNext();) {
				Integer childId = (Integer) iterator.next();
				Integer order = databaseManager.getOrder(childId,childElementName);
				Map attributes = databaseManager.getAttribtues(childId,childElementName);
				m.put(order,attributes);				
			}				
		}
		
		for (Iterator iter = m.keySet().iterator(); iter.hasNext();) {
			Integer order = (Integer) iter.next();
			Map elementNameTo
			root.addContent(new Element());
		}*/

		//regenerateElement();

		getElementInfo(rootId, root);
		/*TreeMap ordsToIds = databaseManager.getOrdsToIds(id);
		Map idsToElementNames = databaseManager.getIdsToElementNames(id);
		Map idsToAttributeMap = databaseManager.getIdsToAttributeMap(id);
		
		for (Iterator iter = ordsToIds.keySet().iterator(); iter.hasNext();) {
			Integer ord = (Integer) iter.next();
			Integer childId = (Integer) ordsToIds.get(ord);
			Map attributeNamesToValues = (Map) idsToAttributeMap.get(childId);
			String elementName = (String) idsToElementNames.get(childId);
			insertElement(root, elementName, attributeNamesToValues);
		}*/

		return doc;

	}

	private void getElementInfo(int id, Element parent) {
		TreeMap ordsToIds = databaseManager.getOrdsToIds(id);
		Map idsToElementNames = databaseManager.getIdsToElementNames(id);
		Map idsToAttributeMap = databaseManager.getIdsToAttributeMap(id);

		for (Iterator iter = ordsToIds.keySet().iterator(); iter.hasNext();) {
			Integer ord = (Integer) iter.next();
			Integer childId = (Integer) ordsToIds.get(ord);
			Map attributeNamesToValues = (Map) idsToAttributeMap.get(childId);
			String elementName = (String) idsToElementNames.get(childId);
			Element childElement = insertElement(parent, elementName, attributeNamesToValues);
			getElementInfo(childId.intValue(), childElement);
		}
	}

	/**
	 * This must be called in the right order for each element
	 * @param parent - e.g. <ps_db>
	 * @param elementName - e.g. "part"
	 * @param attributeNamesToValues - String to String, e.g. ["pno"-->"100","colour"-->"red",price-->"20"]
	 */
	private Element insertElement(Element parent, String elementName, Map attributeNamesToValues) {
		Element child = new Element(elementName);
		
		for (Iterator iter = attributeNamesToValues.keySet().iterator(); iter.hasNext();) {
			String attributeName = (String) iter.next();
			Object attributeValueObj = (Object) attributeNamesToValues.get(attributeName);
			String attributeValue = convertAttributeValueToString(attributeValueObj);

			child.setAttribute(new Attribute(attributeName, attributeValue));
		}
		parent.addContent(child);
		return child;
	}

	/**
	 * @param attributeValueObj - The value of a field in the database whose
	 * type we are unsure of
	 * @return - A string representation of the field which can be added to the XML attribute
	 */
	private String convertAttributeValueToString(Object attributeValueObj) {
		if (attributeValueObj instanceof String) {
			return (String) attributeValueObj;
		}
		else if (attributeValueObj instanceof Integer) {
			return ((Integer) attributeValueObj).toString();
		}
		else if (attributeValueObj instanceof Double) {
			return ((Double) attributeValueObj).toString();
		}
		else {
			logger.error("Invalid datatype.");
			return null;
		}
	}

}
