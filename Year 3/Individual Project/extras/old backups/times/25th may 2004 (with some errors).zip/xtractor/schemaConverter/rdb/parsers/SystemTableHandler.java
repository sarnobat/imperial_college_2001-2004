/*
 * Created on 24-May-2004
 *
 */
package xtractor.schemaConverter.rdb.parsers;

import xtractor.schemaConverter.rdb.RDBBuilder;

/**
 * @author ss401
 *
 */
public class SystemTableHandler {

	final String DELIMITER;
	final String schemaName;
	private final String SYSTEM_PREFIX = "SYSTEM_";

	public SystemTableHandler(RDBBuilder rdbBuilder) {
		this.DELIMITER = rdbBuilder.getDelimiter();
		this.schemaName = rdbBuilder.getSchemaName();

	}
	/**
	 * @return - A string of SQL code to create a table with the following structure:
	 * ss.SYSTEM_element_locations(element_name,table_name,column_name)
	 * 		columnName - The name of the column where a simple element's data should be stored 
	 * 					(null if the element is complex)
	 * 		table_name - The name of the table where this column is located OR
	 * 					 the name of the table holding a complex element's attributes
	 * This will also be useful if the user renames the tables or columns
	 */
	public String createElementLocationSystemTable() {
		String sql = "CREATE TABLE " + schemaName + "." + SYSTEM_PREFIX + "element_locations (\n";
		sql += DELIMITER + "element_name" + DELIMITER + "VARCHAR(50) NOT NULL UNIQUE,\n";
		sql += DELIMITER + "table_name" + DELIMITER + "VARCHAR(50) NOT NULL,\n";
		sql += DELIMITER + "column_name" + DELIMITER + "VARCHAR(50)\n";

		sql += "\n);";
		return sql;
	}

	/**
	 * Gets the SQL code to add a system table entry saying where an XML element's data should be
	 * inserted
	 * @param elementName - An element of simple type
	 * @param tableName - The table where the attribute that the XML element's value should be inserted is found
	 * @param attributeName - The name of the attribute where the XML element's value should be inserted
	 * @return
	 */
	public String getElementLocationSQL(String elementName, String tableName, String attributeName) {
		String sql =
			"INSERT INTO "
				+ getSystemTableName("element_locations")
				+ "(element_name,table_name,column_name) VALUES ('"
				+ elementName
				+ "','"
				+ tableName
				+ "','"
				+ attributeName
				+ "');\n";
		return sql;
	}

	/**
	 * 
	 * @param elementName - An element of complex type
	 * @param tableName
	 * @return
	 */
	public String getElementLocationSQL(String elementName, String tableName) {
		String sql =
			"INSERT INTO "
				+ getSystemTableName("element_locations")
				+ "(element_name,table_name) VALUES ('"
				+ elementName
				+ "','"
				+ tableName
				+ "');\n";
		return sql;
	}

	/**
	 * 
	 * @param tableName - The name of the table excluding any schema name or prefix
	 * @return - The fully qualified name of the table
	 */
	private String getSystemTableName(String tableName) {
		return schemaName + "." + SYSTEM_PREFIX + tableName;
	}
}
