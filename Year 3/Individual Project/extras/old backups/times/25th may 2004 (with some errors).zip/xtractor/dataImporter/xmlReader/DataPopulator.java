/*
 * Created on 25-May-2004
 *
 */
package xtractor.dataImporter.xmlReader;

/**
 * @author ss401
 *
 */
public class DataPopulator {

	private String databaseSchemaName;

	public DataPopulator(String databaseSchemaName) {
		this.databaseSchemaName = databaseSchemaName;
	}

}
