/*
 * Created on 17-Mar-2004
 *  
 */
package xtractor.dataImporter.xmlReader;

import java.io.File;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;

import xtractor.schemaConverter.exception.NoAssociatedSchemaException;
import xtractor.schemaConverter.xsd.JDomUtilities;

/**
 * @author ss401
 *  
 */

public class XMLWalker {
	String databaseSchemaName;
	Logger logger = Logger.getLogger(this.getClass());
	//DatabaseManager databaseManager;
	Document xmlDocument;
	File xmlDataFile;
	//Connection conn;
	DataPopulator dataPopulator;

	public XMLWalker(File xmlDataFile) throws NoAssociatedSchemaException {
		this.xmlDataFile = xmlDataFile;
		this.xmlDocument = JDomUtilities.getDocument(xmlDataFile);
		String schemaFileName = getAssociatedSchema();
		this.databaseSchemaName = schemaFileName.split(".x")[0];
		//this.databaseManager = new DatabaseManager(this.databaseSchemaName);
		//this.conn = DatabaseConnection.getConnection();
		this.dataPopulator = new DataPopulator(this.databaseSchemaName);
	}

	/**
	 * Populates the database with the information contained in the xml File specified in the field variable (that was set in the
	 * constructor)
	 */
	public void translateDocument() {
		Element root = xmlDocument.getRootElement();
		int rootId = translateRoot(root);
		translateChildren(root, rootId);
	}

	/**
	 * @param element - The element whose children are to be translated
	 * @param parentId - The id of the parent, which is required in the 'pid' field of each meta table
	 */
	private void translateChildren(Element parentElement, int parentId) {
		List childrenElements = parentElement.getChildren();
		int order = 1;

		for (Iterator iter = childrenElements.iterator(); iter.hasNext();) {
			Element child = (Element) iter.next();
			String childName = child.getName();

			populateDatabaseWithElement(child);

			// Get the key attributes, so that they can be put in both the
			// data table and the meta table
			Map keyAttributeNamesToValues = new TreeMap();
			List keyAttributes = databaseManager.getPrimaryKeyAttributesNames(child.getName());
			for (Iterator iterator = keyAttributes.iterator(); iterator.hasNext();) {
				String keyName = (String) iterator.next();
				if (databaseManager.isAutoKey(keyName)) {
					// get the next id from the sequence
					int id = databaseManager.getNextId(childName);
					keyAttributeNamesToValues.put(keyName, new Integer(id));
				}
				else {
					// get the key value from the XML element
					keyAttributeNamesToValues.put(keyName, child.getAttributeValue(keyName));
				}
			}

			/*
			 * Perform the data insert 
			 */
			// Add primary keys
			Map dataColumnNamesAndValues = new TreeMap(keyAttributeNamesToValues);
			// Add foreign keys for implicit containment
			List parentKeyNames = databaseManager.getPrimaryKeyAttributesNames(parentElement.getName());			
			Map parentKeyNamesToValues = databaseManager.getAttributeValues(parentElement.getName(),parentKeyNames);
			dataColumnNamesAndValues.putAll(parentKeyNamesToValues);

			// Add remaining attributes
			List attributes = child.getAttributes();
			for (Iterator iterator = attributes.iterator(); iterator.hasNext();) {
				Attribute attribute = (Attribute) iterator.next();
				dataColumnNamesAndValues.put(attribute.getName(), attribute.getValue());
			}
			databaseManager.addData(child.getName(), dataColumnNamesAndValues);

			/*
			 * Perform the meta data insert 
			 */
			Map metaColumnNamesAndValues = new TreeMap(keyAttributeNamesToValues);
			int id = databaseManager.getNextGlobalId();
			metaColumnNamesAndValues.put("id", new Integer(id));
			metaColumnNamesAndValues.put("pid", new Integer(parentId));
			metaColumnNamesAndValues.put("ord", new Integer(order));

			databaseManager.addMetaData(child.getName(), metaColumnNamesAndValues);
			order++;

			//TODO: The big question is what to do after taking care of the parent's attribute but
			// before moving on to the childs - because the parent may have character data
			//ANSWER: put them as a column named the same thing as the data table itself

			if (child.getChildren().size() > 0) {
				translateChildren(child, id);
			}

		}
	}

	/**
	 * @param root
	 * @rerturn - The id of the root to be used in child table references
	 */
	private int translateRoot(Element root) {
		String elementName = root.getName();

		// Perform insert
		TreeMap dataColumnsAndValues = new TreeMap();
		TreeMap metaColumnsAndValues = new TreeMap();
		int nextId = databaseManager.getNextGlobalId();
		metaColumnsAndValues.put("id", new Integer(nextId));
		metaColumnsAndValues.put("pid", new Integer(0));
		// note: 0 means that it has no parent		
		metaColumnsAndValues.put("ord", new Integer(1));

		if (databaseManager.dataTableUsesAutoKey(root.getName())) {
			String primaryKeyName = databaseManager.getPrimaryKeyName(elementName);

			// The key isn't explicitly stated in the XML, so we need the sequence value
			int primaryKeyValue = databaseManager.getNextId(elementName);

			// add the primary key in the data table
			dataColumnsAndValues.put(primaryKeyName, new Integer(primaryKeyValue));
			// add the foreign key in the meta table
			metaColumnsAndValues.put(primaryKeyName, new Integer(primaryKeyValue));
		}

		// Perform the data additions.
		databaseManager.addData(elementName, dataColumnsAndValues);
		databaseManager.addMetaData(elementName, metaColumnsAndValues);

		// Determine id of root element
		return nextId;

	}

	/**
	 * @return
	 */
	private String getAssociatedSchema() throws NoAssociatedSchemaException {
		Element root = xmlDocument.getRootElement();

		List attributeNamesToValues = root.getAttributes();
		for (Iterator iter = attributeNamesToValues.iterator(); iter.hasNext();) {
			Attribute a = (Attribute) iter.next();
			if (a.getName().equals("schemaLocation")) {
				String schemaLocationAttributeValue = a.getValue();
				String[] locationComponents = schemaLocationAttributeValue.split(" ");
				return locationComponents[locationComponents.length - 1];
			}
		}
		logger.error("No schema has been associated with current xml document");
		throw new NoAssociatedSchemaException("Coudln't find associated XML Schema for document" + xmlDataFile.getName());
		/*
		THIS DOESN'T WORK - PERHAPS A BUG WITH JDOM
		 String schemaLocationAttributeValue = root.getAttributeValue("schemaLocation");	
		 if(schemaLocationAttributeValue == null) {
			logger.error("No schema has been associated with current xml document");
		}
		 //The attribute will be of the form xsi:schemaLocation="http://www.w3schools.com schemaFile.xsd" 
		String[] locationComponents = schemaLocationAttributeValue.split(" ");
		 */
	}

	/**
	 * Performs the database updates specified by the root node of an xml file, and recursively does so for it's child elements
	 * @param element - The jdom element of an xml files
	 */
	private void translateElement(Element element) {
		Map attributesToValues = getAttributeNamesAndValues(element);
		translateElement(element, attributesToValues);
	}

	/**
	 * @param element - The jdom model of the element (i.e. <element>...</element>)
	 * @param attributes - A map from the name of the attribute to the value of the attribute (both are Strings)
	 */
	private void translateElement(Element element, Map attributes) {

		/* Iterate through child elements and call translateElement again
		 * This must be done before translating the parent because the parent
		 * will be referencing it, and SQL will refuse to accept references to 
		* rows not populated yet. In other words, this is a post-order traversal
		*/
		Collection childElements = element.getChildren();
		for (Iterator iter = childElements.iterator(); iter.hasNext();) {
			Element child = (Element) iter.next();
			translateElement(child);
		}

		if (attributes.size() > 0) {

			String elementName = element.getName();
			Map attributeNamesToValues = new TreeMap();

			for (Iterator iter = attributes.keySet().iterator(); iter.hasNext();) {

				String attributeName = (String) iter.next();
				String attributeValue = (String) attributes.get(attributeName);

				attributeNamesToValues.put(attributeName, attributeValue);
			}

			databaseManager.addData(elementName, attributeNamesToValues);
		}

		//TODO:Don't forget to deal with mixed content - perhaps this will be taken care of elsewhere
	}

	/**
	 * @param element - A jdom model of an xml element
	 * @return - A map (from String to String) of attribute name to attribute value
	 */
	private Map getAttributeNamesAndValues(Element element) {
		Map namesToValues = new TreeMap();

		//populate the map with the name-value pairs
		for (Iterator iter = element.getAttributes().iterator(); iter.hasNext();) {
			Attribute attribute = (Attribute) iter.next();
			namesToValues.put(attribute.getName(), attribute.getValue());
		}
		return namesToValues;
	}

}
