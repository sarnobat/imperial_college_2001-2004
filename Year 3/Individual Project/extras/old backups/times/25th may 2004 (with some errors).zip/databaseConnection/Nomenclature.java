/*
 * Created on 25-May-2004
 *
 */
package databaseConnection;

import org.apache.log4j.Logger;


/**
 * @author ss401
 *
 */
public class Nomenclature {
	
	

	static Logger logger = Logger.getLogger("Nomenclaure");
	
	public static final String PRIMARY_KEY_SUFFIX = "_pkey";
	public static final String SEQUENCE_SUFFIX = "_seq";
	public static final String META_PREFIX = "meta_";
	public static String COMPLETE_VIEW_PREFIX = "complete_";
	
	/**
	 * 
	 * @param elementName - The name of an XML element without any of the extras (e.g. ps_db)
	 * @return -The name of the primary key in the database (e.g. ps_db_pkey)
	 */
	static String getPrimaryKeyName(String elementName){
		return elementName + PRIMARY_KEY_SUFFIX;
	}
	
	/**
	 * 
	 * @param primaryKeyName - The name of an auto primary key attribute (e.g. ps_db_pkey)
	 * @return - The name of the sequence stored in the database (e.g. ps_db_pkey_seq)
	 */
	static String getPrimaryKeySequence(String primaryKeyName){
		return primaryKeyName + SEQUENCE_SUFFIX;
	}

	/**
	 * @param metaTableName - with the schema prefix
	 * @return
	 */
	public static String getCorrespondingElementName(String metaTableName) {
		String[] localMetaTableNameParts =metaTableName.split("\\."); 
		String localMetaTableName = localMetaTableNameParts[1]; 
		if(localMetaTableName.startsWith(META_PREFIX)){
			return localMetaTableName.substring(META_PREFIX.length(),localMetaTableName.length());
		}
		else{
			logger.error("Not a meta table: " +metaTableName);
			return null;
		}
	}

	/**
	 * @param elementName - The name of an XML element
	 * @return - The UNQUALIFIED name of the complete element schema view for this element
	 */
	public static String getCompleteViewName(String elementName) {
		return COMPLETE_VIEW_PREFIX +elementName;
	}
}
