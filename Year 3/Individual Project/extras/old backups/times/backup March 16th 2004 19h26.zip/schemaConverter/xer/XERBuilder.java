/*
 * Created on 24-Feb-2004
 *
 */
package schemaConverter.xer;

import java.io.File;
import java.util.Collection;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.jdom.Element;

import schemaConverter.xsd.XSDSchemaManipulator;
import schemaConverter.xsd.componentParsers.AttributeParser;
import schemaConverter.xsd.componentParsers.ElementParser;
import schemaConverter.xsd.componentParsers.ModelGroupParser;
import schemaConverter.xsd.componentParsers.SimpleTypeParser;

/**
 * @author ss401
 * Takes an XSD Schema Info model and generates an XER model
 */
public class XERBuilder {

	SimpleTypeParser simpleTypeParser;
	Logger logger = Logger.getLogger(this.getClass());
	ElementParser elementParser;
	AttributeParser attributeParser;
	ModelGroupParser modelGroupParser;
	XERFactory factory;
	XERModel model;
	XSDSchemaManipulator schemaWalker;
	String schemaName;
	
	/**
	 * @param schemaFile
	 */
	public XERBuilder(File schemaFile) {
		this.schemaWalker = new XSDSchemaManipulator(schemaFile);
		this.simpleTypeParser = new SimpleTypeParser(schemaWalker,this);
		this.elementParser = new ElementParser(schemaWalker, this);
		this.attributeParser = new AttributeParser(schemaWalker, this);
		this.modelGroupParser = new ModelGroupParser(schemaWalker, this);		
		this.factory = new XERFactory(this);
		String fileName = schemaFile.getName();
		String[] pathFragments = fileName.split(".x");
		this.schemaName = pathFragments[0];
	}

	/**
	 * @param schemaURL - the relative path of the XML Schema
	 * @return - an XER Model of the schema
	 */
	public XERModel build() {
		// This is a recursive build rather than an iterative build
		// However, new entities and relationships created must be registered with the XERModel
		model = factory.createXERModel(schemaName);
		Element rootElement = schemaWalker.getRootElement();
		XEREntity rootEntity = elementParser.parseRootElement(rootElement);
		model.setRootElement(rootEntity);
		return model;
	}

	/**
	 * Transforms the XER Model into a form that the RDBBuilder can more easily parse
	 * (e.g. create foreign key attributes from relationships)
	 * All other optimizations to the XER model should be implemented here	 
	 * @param xerModel
	 */
	public void transformModel(XERModel xerModel) {
		Collection relationships = xerModel.getRelationships();

		// Go through each XER Relationship and make the necessary additions to the parent XER Entity
		for (Iterator iter = relationships.iterator(); iter.hasNext();) {
			XERRelationship xerRelationship = (XERRelationship) iter.next();
			XEREntity parent = xerRelationship.getParent();
			XEREntity foreignEntity = xerRelationship.getChild();
			// test whether the foreign entity has a key attribute
			if (foreignEntity.hasNoKey()) {
				//TODO:Once you're using keyrefs you should delete this case				
				// Assign it a numerical one
				factory.assignAutoXERPrimaryKey(foreignEntity);
			}
			for (Iterator iterator = foreignEntity.getPrimaryKey().iterator(); iterator.hasNext();) {
				// Add all key attributes of the foreign entity to the parent entity as a foreign key
				XERAttribute keyAttribute = (XERAttribute) iterator.next();
				parent.addForeignKeyAttribute(factory.createXERForeignKey(xerRelationship, keyAttribute));
			}
		}
	}

	/**
	 * @return - The XER model containing all the entities and relationship 
	 */
	public XERModel getModel() {
		return model;
	}

	/**
	 * Convenience method
	 * @return - The xsd:attribute parser
	 */
	public AttributeParser getAttributeParser() {
		return attributeParser;
	}

	/**
	 * Convenience method
	 * @return - The xsd:element parser
	 */
	public ElementParser getElementParser() {
		return elementParser;
	}

	/**
	 * Convenience method
	 * @return - The parser for xsd:group, xsd:all, xsd:choice and xsd:sequence
	 */
	public ModelGroupParser getModelGroupParser() {
		return modelGroupParser;
	}

	/**
	 * Convenience method
	 * @return - The XER Factory to create the XER components
	 */
	public XERFactory getXERFactory() {
		return factory;
	}

	/**
	 * Conveneince method
	 * @return - The parser for <xsd:simple type...> elements
	 */
	public SimpleTypeParser getSimpleTypeParser() {
		return simpleTypeParser;
	}

}
