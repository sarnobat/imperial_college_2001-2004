/*
 * Created on 24-Feb-2004
 *
 */
package schemaConverter.xer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;

/**
 * @author ss401
 * Models and XER Entity 
 */
public class XEREntity {
	Logger logger = Logger.getLogger(this.getClass());
	//Note the attributes collection contains ALL attributes (including primary and foreign key attributes)
	Map attributes;
	Collection keyAttributes;
	Collection foreignKeyAttributes;
	String name;
	boolean convertedToSQL = false;

	XEREntity(String name, XERModel xerModel) {
		this.name = name;
		this.attributes = new TreeMap();
		this.keyAttributes = new ArrayList();
		this.foreignKeyAttributes = new ArrayList();
		xerModel.addEntity(this);
	}

	/**
	 * @return - A collection of XERAttribute for each attribute that exists in this entity
	 */
	public Collection getAttributes() {
		return attributes.values();

	}

	/**
	 * @return - The Collection of XERAttribute which uniquely identify the entity
	 */
	public Collection getPrimaryKey() {
		return keyAttributes;
	}

	/**
	 * 'attribute' should not be a primary key. Use addKeyAttribute(...) instead. 
	 * @param attribute - The attribute to be added to this entity
	 */
	public void addAttribute(XERAttribute attribute) {
		if (!attributes.keySet().contains(attribute.getName())) {
			attributes.put(attribute.getName(),attribute);
		}
	}

	public void addKeyAttribute(XERPrimaryKey attribute) {
		keyAttributes.add(attribute);
		addAttribute(attribute);
	}

	/**
	 * @param attribute - The XER attribute which is a foreign key
	 */
	public void addForeignKeyAttribute(XERAttribute attribute) {
		foreignKeyAttributes.add(attribute);
		addAttribute(attribute);
		XERForeignKey xerForeignKey = (XERForeignKey) attribute;
		logger.debug("");
	}

	/**
	 * 
	 * @return - The name of this XER Entity
	 */
	public String getName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		String acc = "";
		acc += getName() + "(";
		for (Iterator iter = attributes.values().iterator(); iter.hasNext();) {
			XERAttribute attribute = (XERAttribute) iter.next();
			acc += attribute.toString();
			if (iter.hasNext()) {
				acc += ",";
			}

		}
		acc += ")";
		return acc;
	}

	/**
	 * @return - True if this entity has no attributes which constitute the primary key
	 */
	public boolean hasNoKey() {
		return !hasPrimaryKey();
	}

	/**
	 * @return - True if this entity has at any attributes which constitute the primary key
	 */
	public boolean hasPrimaryKey() {
		return keyAttributes.size() > 0;
	}

	/**
	 * @return - A String list of comma separated attribute names
	 */
	public String getKeyAttributeNames() {
		String str = "";
		for (Iterator iter = keyAttributes.iterator(); iter.hasNext();) {
			XERPrimaryKey keyAttribute = (XERPrimaryKey) iter.next();
			str += keyAttribute.getName();
			if (iter.hasNext()) {
				str += ",";
			}
		}
		return str;
	}

	/**
	 * @return - True if the table has already been converted to SQL
	 */
	public boolean convertedToSQL() {
		return convertedToSQL;
	}

	/**
	 * Sets the flag indicating that this entity has already been converted to SQL
	 */
	public void setConverted() {
		convertedToSQL = true;
	}

}
