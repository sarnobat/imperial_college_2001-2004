/*
 * Created on 08-Mar-2004
 *
 */
package schemaConverter.xer;
import org.apache.log4j.Logger;
import org.jdom.Element;

/**
 * @author ss401
 * Factory for creating all XER Components.
 */
public class XERFactory {

	Logger logger = Logger.getLogger(this.getClass());
	XERBuilder builder;
	XERModel model;

	/**
	 * The builder is required so that the factory has access to the model
	 * @param builder - The XERBuilder constructing the XER model
	 */
	public XERFactory(XERBuilder builder) {
		this.builder = builder;
	}

	/**
	 * @return - A new XER Model
	 */
	public XERModel createXERModel(String modelName) {
		this.model = new XERModel(modelName);
		return model;
	}

	/**
	 * 
	 * @param name - the name of the entity
	 * @return - A new entity with the given name 
	 */
	public XEREntity createXEREntity(String name) {
		// Do not create an entity again if the entity already exists
		if (model.entityExists(name)) {
			return model.getEntity(name);
		}
		else {

			XEREntity entity = new XEREntity(name, builder.getModel());
			this.model.addEntity(entity);
			return entity;
		}
	}

	/**
	 * Note that the keyAttribute constitute only part of the foreign key 
	 * @param xerRelationship
	 * @param keyAttribute
	 * @return
	 */
	public XERForeignKey createXERForeignKey(XERRelationship xerRelationship, XERAttribute keyAttribute) {
		//new XERForeignKey(xerRelationship.getName(), keyAttribute, foreignEntity, xerRelationship.getMinOccurs());
		return new XERForeignKey(xerRelationship, keyAttribute);
	}

	/**
	 * The key is automatically added to 'entity'
	 * This should only be used for creating keys for entities which do not have any key specified
	 * @param entity - The XER Entity which has no primary key defined in the xml schema
	 * @return The XERPrimaryKey attribute
	 */
	public XERPrimaryKey assignAutoXERPrimaryKey(XEREntity entity) {
		//foreignEntity.addKeyAttribute(new XERPrimaryKey(foreignEntity));
		XERPrimaryKey key = new XERPrimaryKey(entity);
		entity.addKeyAttribute(key);
		return key;
	}
	/**
	 * @param attribute - The JDom model of the xsd:attribute which acts as a primary key
	 * @param entity - The entity that the attribute acts as the primary key for
	 * @return - An XERPrimaryKey model of the attribute
	 */
	public XERPrimaryKey createXERPrimaryKey(Element xsdAttribute, XEREntity entity) {
		//entity.addKeyAttribute(new XEaRAttribute(attribute));
		//XERPrimaryKey key = new XERPrimaryKey(xsdAttribute, entity);
		XERPrimaryKey key = new XERPrimaryKey(entity);
		entity.addKeyAttribute(key);
		return key;
	}

	/**
	 * @param xsdSimpleElement - The <xsd:element that has a simple type
	 * @param parent - The XER entity the element belongs to
	 */
	/*public void createXERAttributeFromXSDElement(Element xsdSimpleElement, XEREntity parent) {
		String name = xsdSimpleElement.getAttributeValue("name");
		String type = xsdSimpleElement.getAttributeValue("type");
		
		//XERAttribute = 
	}*/

	/**
	 * XER Attribute gets added to the parent
	 * @param xsdAttribute - an <xsd:attribute...> element
	 * @param parent - The parent XER entity
	 * @return - the XER Attribute that has just been created
	 */
	public XERAttribute createXERAttributeFromXSDAttribute(Element xsdAttribute, XEREntity parent) {
		String name = xsdAttribute.getAttributeValue("name");
		String type = xsdAttribute.getAttributeValue("type");
		String use = xsdAttribute.getAttributeValue("use");
		XERAttribute xerAttribute = new XERAttribute(name, type, use);
		parent.addAttribute(xerAttribute);
		return xerAttribute;
	}

	/**
	 * @param relationshipName - A unique name for the relationship so that a table for it can be created
	 * @param parent - The entity making the reference
	 * @param referredEntity - The entity being referred to 
	 * @param constrainedElement - could be a simple,complex element,choice,sequence, or anything else with cardinality constraints
	 * 				of the form minOccurs and maxOccurs
	 * @return
	 */
	public XERRelationship createXERRelationship(String relationshipName, XEREntity parent, XEREntity referredEntity, Element constrainedElement) {
		XERRelationship relationship = new XERRelationship(relationshipName, parent, referredEntity, constrainedElement);
		this.model.addRelationship(relationship);
		return relationship;
	}

	/**
	 * @param xsdElement - The simple element <xsd:element type="xsd:.."> 
	 * @param parent - The XER Entity which the attribute will be added to
	 */
	public XERAttribute createXERAttributeFromXSDElemnt(Element xsdElement, XEREntity parent) {
		String name = xsdElement.getAttributeValue("name");
		String type = xsdElement.getAttributeValue("type");
		String use = xsdElement.getAttributeValue("minOccurs");
		return createXERAttribute(name, type, use, parent);
	}

	/**
	 * 
	 * @param baseTypeName - The base type specified in the restriction
	 * @param parent - The XER Entity containing this element
	 * @return - The XER Attribute for the simple type
	 */
	public XERAttribute createXERAttributeFromRestriction(String name, String xsdType, String minOccurs, XEREntity parent) {
		/*String name = xsdElement.getAttributeValue("name");
		String minOccurs = xsdElement.getAttributeValue("minOccurs");*/
		return createXERAttribute(name, xsdType, minOccurs, parent);
	}

	/**
	 * @param attributeName - The name to be given to the attribute
	 * @param xsdType - The xsd data type which this attribute will have
	 * @param minOccurs - The minimum number of times this attribute can occur (note it's passed as a string)
	 * @param parent - The XER Entity containing this element
	 * @return
	 */
	private XERAttribute createXERAttribute(String attributeName, String xsdType, String minOccurs, XEREntity parent) {
		String use = null;
		if (use == null) {
			use = "required";
		}
		else {
			int minOccursInt = Integer.parseInt(minOccurs);
			if (minOccursInt == 0) {
				use = "optional";
			}
			else {
				use = "required";
			}
		}
		XERAttribute attribute = new XERAttribute(attributeName, xsdType, use);
		parent.addAttribute(attribute);
		return attribute;
	}

}
