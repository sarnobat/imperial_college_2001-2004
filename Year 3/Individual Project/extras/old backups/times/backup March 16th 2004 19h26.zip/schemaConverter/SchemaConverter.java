package schemaConverter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import schemaConverter.rdb.RDBBuilder;
import schemaConverter.xer.XERBuilder;
import schemaConverter.xer.XERModel;
/*
 * Created on 16-Feb-2004
 *
 */

/**
 * @author ss401
 * Root class to run schema converter
 */

public class SchemaConverter {
	static Logger logger = Logger.getRootLogger();
	static String schemaName;

	/**
	 * 
	 * @param schemaFile - The schema file which needs translating
	 */
	public static void convertSchema(File schemaFile) {
		schemaName = schemaFile.getName().split(".x")[0];
		XERBuilder xerBuilder = new XERBuilder(schemaFile);
		XERModel xerModel = xerBuilder.build();
		//TODO: Don't forget to parse the key and keyref elements; this could be instead of adding keys manually
		xerBuilder.transformModel(xerModel);
		RDBBuilder rdbBuilder = new RDBBuilder(xerModel, schemaFile);
		String sql = rdbBuilder.build();
		//System.out.println(sql);
		executeSQL(sql);

		try {
			// Create the file for creating the database schema
			File create = new File("CreateDatabase.sql");
			create.createNewFile();
			FileWriter createWriter = new FileWriter(create);
			createWriter.write(sql);
			createWriter.flush();

			// Create the file for deleting the database schema
			/*File delete = new File("DeleteDatabase.sql");
			delete.createNewFile();
			FileWriter deleteWriter = new FileWriter(delete);
			deleteWriter.write(rdbBuilder.getDeleteSQL());
			deleteWriter.flush();*/

		}
		catch (IOException e) {
			System.out.println("Couldn't create sql file" + e);
		}

	}

	private static void executeSQL(String sql) {
		try {
			Class.forName("org.postgresql.Driver");
		}
		catch (ClassNotFoundException e) {
			System.err.println("Driver not found: " + e + "\n" + e.getMessage());
		}
		try {
			Class.forName("org.postgresql.Driver");
			Connection conn = DriverManager.getConnection("jdbc:postgresql://db/ss401", "ss401", "ss401");
			Statement stmt = conn.createStatement();

			String[] statements = sql.split(";");
			String successes = "";
			String failures = "";
			for (int i = 0; i < statements.length; i++) {
				System.out.println(statements[i]);
				boolean success = stmt.execute(statements[i]);
				if (success) {
					successes += "Successful exection of: " + statements[i] + "\n";
				}
				else {
					failures += "Failed exection of: " + statements[i] + "\n";
				}
				//logger.info("\nSUCESSES\n--------------\n"+successes);
				//logger.error("\nFAILURES\n--------------\n"+failures);
			}
			conn.close();
		}
		catch (SQLException e) {
			System.err.println("SQL Exception: " + e + "\n" + e.getMessage());
			executeSQL("DROP SCHEMA " + schemaName + " CASCADE;");
		}
		catch (ClassNotFoundException e) {
			System.err.println("Couldn't locate database driver");
		}

	}

}
