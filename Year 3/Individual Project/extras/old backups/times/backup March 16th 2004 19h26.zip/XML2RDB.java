import java.io.File;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import schemaConverter.SchemaConverter;
import dataImporter.*;

/*
 * Created on 13-Mar-2004
 *
 */

/**
 * @author ss401
 *
 */
public class XML2RDB {
	static Logger logger = Logger.getRootLogger();
	/*
	 * -i [xml file] 		: Import xml data
	 * -e [document id]	: Export Data
	 * -l				: List documents
	 */
	public static void main(String[] args) {
		// Initialize logger
		BasicConfigurator.configure();
		logger.setLevel(Level.ERROR);
		
		//translateSchema("schemas/purchaseOrder.xsd");
		//importData("xml/po.xml");
		translateSchema("schemas/suppliersSchema.xsd");
	}
	
	private static void importData(String xmlFilePath) {
		File dataFile = new File(xmlFilePath);
		//DataImporter.importData(dataFile);
		DataImporter.importData(dataFile);		
	}

	private static void translateSchema(String xsdFilePath) {
		/*
		 * get the attached schema
		 * validate the document against it
		 * IF Schema not previously encountered
		 * 	create schema
		 * perform import of XML file data
		 * add the document to the document.xml list which includes id,date,database,comment
		 * 	 
		 */
		 File schemaFile = new File(xsdFilePath);
		 SchemaConverter.convertSchema(schemaFile);
		
	}
	
	private static void exportXMLFile(int docId) {
		/*
		 * create xml document
		 * validate against schema
		 * Tell the user the location of the xml file generated
		 */
	}
	
	private static void listImportedDocuments() {
		/*
		 * Iterate through xml file
		 * 	print a list of documents
		 */
	}
}
