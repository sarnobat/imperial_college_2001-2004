/*
 * Created on 16-Mar-2004
 *
 */
package dataImporter;

import java.io.File;

/**
 * @author ss401
 *
 */
public class DataImporter {
	public static void importData(File xmlDataFile){
		
	}
}
