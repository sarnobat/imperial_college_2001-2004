/*
 * Created on 15-May-2004
 *
 */
package model;

/**
 * @author ss401
 *
 */
public class ExportModel {
	
	public ExportModel() {
		
	}

}
