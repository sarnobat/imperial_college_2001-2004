/*
 * Created on 16-Mar-2004
 *
 */
package xtractor.dataImporter;

import java.io.File;

import org.apache.log4j.Logger;

import xtractor.dataImporter.xmlReader.XMLWalker;
import xtractor.schemaConverter.exception.NoAssociatedSchemaException;

/**
 * @author ss401
 *
 * Root class of dataImporter package. Main application makes static call to importData()
 */
public class DataImporter {
	Logger logger = Logger.getLogger(this.getClass());

	public void importData(File xmlDataFile) throws NoAssociatedSchemaException{

		XMLWalker xmlWalker = new XMLWalker(xmlDataFile);
		xmlWalker.translateDocument();
	}
}
