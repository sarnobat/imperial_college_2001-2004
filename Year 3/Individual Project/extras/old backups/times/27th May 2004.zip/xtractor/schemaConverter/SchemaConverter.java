package xtractor.schemaConverter;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;

import xtractor.schemaConverter.rdb.DatabaseManager;
import xtractor.schemaConverter.rdb.RDBBuilder;
import xtractor.schemaConverter.xer.XERBuilder;
import xtractor.schemaConverter.xer.XERModel;
import databaseConnection.DatabaseConnection;
import databaseConnection.SchemaDisplayer;

/*
 * Created on 16-Feb-2004
 *
 */

/**
 * @author ss401
 * Root class to run schema converter
 */

public class SchemaConverter {
	static Logger logger = Logger.getLogger("SchemaConverter");
	static String schemaName;
	static File xsdSchemaFile;
	static DatabaseManager databaseManager;

	/**
	 * 
	 * @param schemaFile - The schema file which needs translating
	 */
	public static void convertSchema(File schemaFile) {

		// Build an XER Model		
		String schemaName = schemaFile.getName().split(".x")[0];
		databaseManager = new DatabaseManager(schemaName);
		XERBuilder xerBuilder = new XERBuilder(schemaFile);
		XERModel xerModel = xerBuilder.build();

		//logger.info("Resulting XER Model:\n" + xerModel + "\n\n\n\n\n\n");

		// Parse the XER Model,creating the relational database
		File databaseCreationScript = new File("programOutput.sql");
		try {
			// Create the database from it
			//Writer sqlWriter = new OutputStreamWriter(System.out);

			FileWriter sqlWriter = new FileWriter(databaseCreationScript);
			RDBBuilder rdbBuilder = new RDBBuilder(xerModel, schemaFile, sqlWriter);
			rdbBuilder.build();
		}
		catch (IOException e) {
			logger.error("Couldn't write database creation script." + e);
		}
		Map errors = executeSQL(databaseCreationScript);

		SchemaDisplayer relationalSchema = new SchemaDisplayer(schemaName);
		logger.debug(relationalSchema.getSummary());
	}

	/**
	 * In addition to executing what's in the script, we create complete views
	 * and also append them to the script (for debugging)
	 * @param sqlFile - The file containing the list of sql statements
	 * @return - A Map from String (failed statement) to SQLException (containing reason) 
	 */
	private static Map executeSQL(File sqlFile) {

		logger.debug("Creating database schema...");
		Connection conn = DatabaseConnection.getConnection();
		Map statementToException = new TreeMap();
		int statementTotal = 0;
		try {

			FileReader r = new FileReader(sqlFile);
			Collection statements = getStatements(r);
			r.close();
			PreparedStatement ps;

			/*
			 * Execute table creation code from script
			 */
			boolean success;
			
			for (Iterator iter = statements.iterator(); iter.hasNext();) {
				String statement = (String) iter.next();
				try {
					ps = conn.prepareStatement(statement);					
					ps.execute();
				}
				catch (SQLException e) {
					logger.error("Couldn't execute statement." + statement + "\n\tREASON:" + e);
					statementToException.put(statement, e);
				}
				statementTotal++;
			}

			/*
			 * Create element schema views
			 */
			 // Get the code to do it
			Collection sqlViewCreationCommands = new LinkedList();
			try {
				String sql = databaseManager.createCompleteViews();
				String[] sqlCommands = sql.split(";");
				sqlViewCreationCommands = Arrays.asList(sqlCommands);
			}
			catch (SQLException e) {
				logger.error("Couldn't determine how to create element schema views. " + e);
			}

			// invoke the code
			// (we add the code to the script for debugging purposes)
			Writer fileWriter = new FileWriter(sqlFile,true);
			fileWriter.write("--------------------\n------ VIEWS -------\n--------------------\n");
			for (Iterator iter = sqlViewCreationCommands.iterator(); iter.hasNext();) {
				String statement = (String) iter.next();
				fileWriter.write(statement +";");
				try {
					ps = conn.prepareStatement(statement);
					ps.execute();
				}
				catch (SQLException e) {
					logger.error("Couldn't execute statement." + statement + "\n\tREASON:" + e);
					statementToException.put(statement, e);
				}
				statementTotal++;
			}
			fileWriter.flush();
		}
		catch (IOException e1) {
			logger.error("Couldn't read sql script." + e1);
		}

		logger.info("Executed " + (statementTotal - statementToException.size()) + " of " + statementTotal + " successfully.");
		return statementToException;

	}

	private static Collection getStatements(FileReader r) throws IOException {

		int c;
		String acc = "";
		while ((c = r.read()) != -1) {
			acc += (char) c;
		}

		String[] statements = acc.split(";");
		return Arrays.asList(statements);

	}

}
