/*
 * Created on 01-Jun-2004
 *
 */
package GUI.windows.dialog.dataPopulator;

import GUI.GUIController;
import GUI.windows.dialog.AbstractDialogFrame;

/**
 * @author ss401
 *
 */
public class DataPopulatorFrame extends AbstractDialogFrame {

	/**
	 * @param c
	 */
	public DataPopulatorFrame(GUIController c) {
		super(c);
	}
}
