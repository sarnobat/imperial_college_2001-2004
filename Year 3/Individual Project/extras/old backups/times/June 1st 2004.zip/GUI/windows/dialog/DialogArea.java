package GUI.windows.dialog;

/*
 * Created on 31-May-2004
 */

import javax.swing.JTextArea;

/**
 * @author ss401
 *
 */
public class DialogArea extends JTextArea {

	public DialogArea(AbstractDialogFrameController controller) {
		this.setLineWrap(true);
	}
	//	window elements
//	JTextArea textDisplay;
//	JScrollPane scrollPane;
	//
	//	private OutputStream out = new ConsoleStream(this);
	//	private PrintStream pout = new PrintStream(out, true);
	//
	//	public DialogArea() {
	//		super()

	/*this.setLayout(new GridLayout(1, 1));
	
	textDisplay = new JTextArea();
	textDisplay.setVisible(true);
	textDisplay.setEditable(false);
	textDisplay.setLineWrap(false);
	textDisplay.setWrapStyleWord(true);
	textDisplay.setFont(new Font("Monospaced", Font.PLAIN, 10));
	
	scrollPane = new JScrollPane();
	scrollPane.getViewport().setView(textDisplay);
	
	this.add(scrollPane);*/
	

}
