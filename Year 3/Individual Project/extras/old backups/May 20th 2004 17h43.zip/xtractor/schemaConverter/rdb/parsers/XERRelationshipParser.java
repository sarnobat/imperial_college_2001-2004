/*
 * Created on 20-May-2004
 *
 */
package xtractor.schemaConverter.rdb.parsers;

import xtractor.schemaConverter.rdb.RDBBuilder;
import xtractor.schemaConverter.xer.xerConstructs.XERCompoundConstruct;
import xtractor.schemaConverter.xer.xerConstructs.XERRelationship;

/**
 * @author ss401
 *
 */
public class XERRelationshipParser extends XERAbstractParser {

	/**
	 * @param builder
	 */
	public XERRelationshipParser(RDBBuilder builder) {
		super(builder);
	}

	/**
	 * @param relationship
	 * @return
	 */
	public String parseRelationship(XERRelationship relationship) {
		String sql = "CREATE TABLE " + getDataTableName(relationship) +" (";
		XERCompoundConstruct parent = relationship.getParent();
		XERCompoundConstruct child = relationship.getChild();
		
		sql += "\n);";
		return sql;
	}

	private String getDataTableName(XERRelationship relationship) {
		return databaseSchema +"." + relationship.getName();
	}


}
