/*
 * Created on 20-May-2004
 *
 */
package xtractor.schemaConverter.rdb.parsers;

import java.util.Collection;

import org.apache.log4j.Logger;

import xtractor.schemaConverter.rdb.RDBBuilder;
import xtractor.schemaConverter.rdb.SQLMapper;
import xtractor.schemaConverter.xer.xerConstructs.XEREntity;

/**
 * @author ss401
 *
 */
public class XERAbstractParser {

	Logger logger = Logger.getLogger(this.getClass());


	final String COMMENT = "--------------------";
	final String META_PREFIX = "META_";
	String DELIMITER;
	SQLMapper typeMapper;
	String databaseSchema;
	//writer not included (to prevent attribute parser from using it)

	Collection parsedEntities;

	XERAttributeParser attributeParser;

	public XERAbstractParser(RDBBuilder builder) {

		this.DELIMITER = builder.getDelimiter();
		this.typeMapper = builder.getSqlMapper();
		this.databaseSchema = builder.getPrefix();

		this.parsedEntities = builder.getParsedEntities();
		this.attributeParser = builder.getAttributeParser();
	}

	/**
	 * @param xsdTypeName - The name of a predefined XSD type
	 * @return
	 */
	protected String resolveXSDType(String xsdTypeName) {

		return typeMapper.resolveDataType(xsdTypeName);
	}

	/**
	 * @param entity - The name of an XER entity (e.g. part)
	 * @return - The fully qualified name of the data table (e.g. ss.part)
	 */
	protected String getDataTableName(XEREntity entity) {
		return databaseSchema + "." + entity.getName();
	}

	/**
	 * @param entity - The name of an XER entity (e.g. part)
	 * @return - The fully qualified name of the meta table (e.g. ss.META_part)
	 */
	protected String getMetaTableName(XEREntity entity) {
		return databaseSchema + "." + META_PREFIX + entity.getName();
	}
	
	/**
	 * 
	 * @param setName - The name for a group of tables which appears in the comment
	 * @return - A header comment which makes the SQL more readable
	 */
	protected String getComment(String setName){
		return COMMENT + DELIMITER + setName + DELIMITER + COMMENT + "\n\n";
	}

}
