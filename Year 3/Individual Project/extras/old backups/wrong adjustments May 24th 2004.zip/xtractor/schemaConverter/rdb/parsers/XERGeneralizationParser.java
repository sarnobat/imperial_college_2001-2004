/*
 * Created on 20-May-2004
 *
 */
package xtractor.schemaConverter.rdb.parsers;

import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;

import xtractor.schemaConverter.exception.EntityNotParsedException;
import xtractor.schemaConverter.exception.MultiValuedAttributeException;
import xtractor.schemaConverter.rdb.RDBBuilder;
import xtractor.schemaConverter.xer.xerConstructs.XERAutoPrimaryKey;
import xtractor.schemaConverter.xer.xerConstructs.XEREntity;
import xtractor.schemaConverter.xer.xerConstructs.XERGeneralization;
import xtractor.schemaConverter.xer.xerConstructs.XERPrimaryKey;

/**
 * @author ss401
 *
 */
public class XERGeneralizationParser extends XERAbstractParser {

	/**
	 * @param builder
	 */
	public XERGeneralizationParser(RDBBuilder builder) {
		super(builder);
	}

	/**
	 * @param generalization
	 */
	public String parseGeneralization(XERGeneralization generalization) {

		String sql = "";
		if (generalization.getPrimaryKeys().size() == 0) {
			super.createAutoKeyAttribute(generalization);
		}

		String nullCheckerSQL = DELIMITER + "CHECK (";
		String sequenceSQL = "";
		
		sql += "CREATE TABLE " + databaseSchema + "." + generalization.getName() + " (\n";

		Collection generalizationsKeyAttributes = generalization.getPrimaryKeys();
		for (Iterator iter = generalizationsKeyAttributes.iterator(); iter.hasNext();) {
			XERPrimaryKey attribute = (XERPrimaryKey) iter.next();
			if (attribute instanceof XERAutoPrimaryKey) {
				// Create the sequence
				sequenceSQL += getAutoKeyAttributeSQL((XERAutoPrimaryKey) attribute);
				
				try {
					attributeParser.parseAttribute(attribute);
				}
				catch (Exception e) {
					logger.error("Unexpected failure to parse auto key." + e);
				}
			}
			else {
				logger.error("Unexpected type of attribute.");
			}

		}

		Collection entities = generalization.getEntities();
		for (Iterator iter = entities.iterator(); iter.hasNext();) {
			XEREntity entity = (XEREntity) iter.next();

			nullCheckerSQL += "(";

			String keyAttributeNames = "";
			Collection keys = entity.getPrimaryKeys();
			for (Iterator iterator = keys.iterator(); iterator.hasNext();) {
				XERPrimaryKey key = (XERPrimaryKey) iterator.next();
				sql += DELIMITER + key.getName() + DELIMITER + resolveXSDType(key.getType());

				keyAttributeNames += key.getName();

				nullCheckerSQL += key.getName() + " IS NULL";
				sql += ",\n";
				if (iterator.hasNext()) {

					keyAttributeNames += ",";
					nullCheckerSQL += " AND ";
				}
			}
			nullCheckerSQL += ")";
			sql += DELIMITER
				+ "FOREIGN KEY ("
				+ keyAttributeNames
				+ ") REFERENCES "
				+ getDataTableName(entity)
				+ "("
				+ keyAttributeNames
				+ ")";

			sql += ",\n";
			if (iter.hasNext()) {
				nullCheckerSQL += " OR ";
			}

			// Need to create a trigger to ensure that at least one row is null
		}
		nullCheckerSQL += ")";
		if (entities.size() > 0) {
			sql += nullCheckerSQL; //DELIMITER+"CHECK ("++")";
		}
		sql += "\n);";

		return getComment(generalization.getName()) + sequenceSQL + sql;
	}
}
