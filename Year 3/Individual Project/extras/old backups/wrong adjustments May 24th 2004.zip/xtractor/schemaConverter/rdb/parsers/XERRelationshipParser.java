/*
 * Created on 20-May-2004
 *  
 */
package xtractor.schemaConverter.rdb.parsers;

import java.util.Collection;
import java.util.Iterator;

import xtractor.schemaConverter.rdb.RDBBuilder;
import xtractor.schemaConverter.xer.xerConstructs.XERCompoundConstruct;
import xtractor.schemaConverter.xer.xerConstructs.XERExplicitRelationship;
import xtractor.schemaConverter.xer.xerConstructs.XERForeignKey;
import xtractor.schemaConverter.xer.xerConstructs.XERImplicitRelationship;
import xtractor.schemaConverter.xer.xerConstructs.XERPrimaryKey;
import xtractor.schemaConverter.xer.xerConstructs.XERRelationship;

/**
 * @author ss401
 *  
 */
public class XERRelationshipParser extends XERAbstractParser {

	/**
	 * @param builder
	 */
	public XERRelationshipParser(RDBBuilder builder) {
		super(builder);
	}

	/**
	 * @param relationship
	 * @return
	 */
	public String parseRelationship(XERRelationship relationship) {

		if (relationship instanceof XERImplicitRelationship) {
			// we know that it cannot be many-to-many, so no need to create an intermediate table
			return parseImplicitRelationship((XERImplicitRelationship) relationship);
		} else if (relationship instanceof XERExplicitRelationship) {
			return parseExplicitRelationship((XERExplicitRelationship) relationship);
		} else {
			logger.error("Invalid case.");
			return null;
		}

	}

	/**
	 * @param relationship
	 * @return
	 */
	private String parseExplicitRelationship(XERExplicitRelationship relationship) {

		//TODO: It may be possible to have many-to-many, relationships,
		//but I don't know how. In such a case we need an intermediate table
		// Perhaps we can detect them when we find two separate relationships which are 'mirrors'
		// of each other

		String sql = "";

		XERCompoundConstruct parent = relationship.getParent();
		Collection parentsForeignKeyAttributes = relationship.getParentsForeignKeyAttributes();

		if (relationship.getMaxOccurs() < 2) {
			// The parent's foreign keys will be in the the expected data table
			return parseCompositeSingleRelationship(relationship);
		} else {
			// The multi-valued attribute will mean we have to consult the multi-value table
			return parseAtomicMultiValuedRelationship(relationship);

		}

	}

	/**
	 * By atomic we mean that the foreign key only contains one column in its foreign key By MultValued we mean that the foreign key may
	 * contain a column which has many values
	 * 
	 * @param relationship
	 */
	private String parseAtomicMultiValuedRelationship(XERExplicitRelationship relationship) {
		String sql = "";

		XERCompoundConstruct child = relationship.getChild();
		Collection parentsForeignKeys = relationship.getParentsForeignKeyAttributes();
		Collection childsPrimaryKeys = relationship.getChild().getPrimaryKeys();
		//sanity checks
		if (parentsForeignKeys.size() > 1) {
			logger.warn("Unimplemented case where foreign key is a composite and contains a multi-valued attribute.");
			return "";
		}
		//this should be a consequence of the first anyway, but just as a double check		
		if(childsPrimaryKeys.size() > 1){
			logger.warn("Unimplemented case where foreign key is a composite and contains a multi-valued attribute.");
			return "";
		}

		// Get the parent's single foreign key
		Iterator iter = parentsForeignKeys.iterator();
		XERForeignKey mvaForeignKey = (XERForeignKey) iter.next();
		String foreignKeyName = mvaForeignKey.getName();
		// Get the child's single primary key
		iter = childsPrimaryKeys.iterator();
		XERPrimaryKey primaryKey = (XERPrimaryKey) iter.next();
		String primaryKeyName = primaryKey.getName();

		sql += "ALTER TABLE "
			+ super.getDataTableName(mvaForeignKey)
			+ " ADD CONSTRAINT "
			+ foreignKeyName
			+ "_fkey FOREIGN KEY ("
			+ foreignKeyName
			+ ") REFERENCES "
			+ super.getDataTableName(child)
			+ "("
			+ primaryKeyName
			+ ");\n";

		return sql;

	}

	/**
	 * By composite we mean that the key can consist of several columns By Single we mean that no column is multi-valued
	 * 
	 * @param relationship
	 *                              This is probably the 'obvious' case
	 */
	private String parseCompositeSingleRelationship(XERExplicitRelationship relationship) {

		String sql = "";

		// Determine the names of the foreign keys in the parent
		XERCompoundConstruct parent = relationship.getParent();
		Collection parentsForeignKeys = relationship.getParentsForeignKeyAttributes();
		String foreignKeyNames = "";
		for (Iterator iter = parentsForeignKeys.iterator(); iter.hasNext();) {
			// Determine the name of the foreign key
			XERForeignKey foreignKey = (XERForeignKey) iter.next();
			foreignKeyNames += foreignKey.getName();
		}

		// Determine the names of the primary keys in the child
		XERCompoundConstruct child = relationship.getChild();
		Collection childsPrimaryKeys = relationship.getChild().getPrimaryKeys();
		String primaryKeyNames = "";
		for (Iterator iter = childsPrimaryKeys.iterator(); iter.hasNext();) {
			XERPrimaryKey key = (XERPrimaryKey) iter.next();
			primaryKeyNames += key.getName();
		}

		sql += "ALTER TABLE "
			+ super.getDataTableName(parent)
			+ " ADD CONSTRAINT "
			+ parent.getName()
			+ "_fkey FOREIGN KEY ("
			+ foreignKeyNames
			+ ") REFERENCES "
			+ super.getDataTableName(child)
			+ "("
			+ primaryKeyNames
			+ ") MATCH FULL;\n";

		return sql;

		//		//PICKUP It's the child's foreign keys we should be examining, not the parent's primary key
		//		// Alter each attribute in the parent if the corresponding attribute in the parent is a key column
		//		XERCompoundConstruct child = relationship.getChild();
		//		Collection childKeys = child.getPrimaryKeys();
		//		String keyNames = "";
		//		int singleAttributeCount = 0;
		//		//TODO: This doesn't work if we have several MVAs referencing something, or a combination of single and multi-valued
		// attributes referencing something
		//		for (Iterator iter = childKeys.iterator(); iter.hasNext();) {
		//			XERPrimaryKey key = (XERPrimaryKey) iter.next();
		//			if (key.getMaxOccurs() > 1) {
		//				// The reference will come from a foreign table, not the parent
		//				sql += "ALTER TABLE " + super.getDataTableName(key) +" ADD CONSTRAINT " +key.getName() +"_fkey FOREIGN KEY ("
		//				+ key.getName() +") REFERENCES " +super.getDataTableName(child)+ "("+key.getName() +");\n" ;
		//			} else {
		//				singleAttributeCount ++;
		//				keyNames += key.getName();
		//				if (iter.hasNext()) {
		//					keyNames += ",";
		//				}
		//			}
		//		}
		//
		//		if (singleAttributeCount > 0) {
		//			sql += "ALTER TABLE "
		//				+ super.getDataTableName(parent)
		//				+ " ADD CONSTRAINT "
		//				+ child.getName()
		//				+ "_fkey FOREIGN KEY ("
		//				+ keyNames
		//				+ ") REFERENCES "
		//				+ super.getDataTableName(child)
		//				+ "("
		//				+ keyNames
		//				+ ") MATCH FULL;\n";
		//		}
		//		
		//
		//		return sql;
	}

	/**
	 * @param relationship
	 * @return
	 */
	private String parseImplicitRelationship(XERImplicitRelationship relationship) {
		String sql = "";
		if (relationship.getMaxOccurs() == 1) {
			// Just create a foreign key in the parent
			//It seems we have already done this
		} else if (relationship.getMaxOccurs() > 1) {
			//
		} else {
			logger.error("Invalid case.");
		}

		//sql += "\n);";
		return sql;

	}

}
