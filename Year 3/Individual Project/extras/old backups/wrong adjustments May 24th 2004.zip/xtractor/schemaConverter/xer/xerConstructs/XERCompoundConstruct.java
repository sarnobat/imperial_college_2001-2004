/*
 * Created on 18-May-2004
 *
 */
package xtractor.schemaConverter.xer.xerConstructs;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import org.apache.log4j.Logger;

import xtractor.schemaConverter.xer.XERBuilder;

/**
 * @author ss401
 * An XERCompoundConstruct is an XER component which can contain any other constructs
 * (i.e. it's non-terminal node in the XER hierarchy)
 */
public abstract class XERCompoundConstruct extends XERConstruct {

	Logger logger = Logger.getLogger(this.getClass());
	//Note the attributes collection contains ALL attributes (including primary and foreign key attributes)
	Map attributes;
	Collection keyAttributes;
	Collection foreignKeyAttributes;
	String name;

	/**
	 * @param xerBuilder
	 */
	public XERCompoundConstruct(XERBuilder xerBuilder) {
		super(xerBuilder);
		this.attributes = new HashMap();
		this.keyAttributes = new LinkedList();
		this.foreignKeyAttributes = new LinkedList();
	}

	/**
	 * The implementations of this methods will have to use instanceof
	 * to see what to do exactly.
	 * @param xerConstruct - An XEREntity, XERGeneralization etc.
	 * @param minOccurs
	 * @param maxOccurs
	 * Note that the cardinalities will be of use when creating relationships 
	 * (so when adding an attribute they serve little purpose), but the information
	 * should still be available
	 */
	public abstract void addConstruct(XERConstruct xerConstruct, int minOccurs, int maxOccurs);

	/**
	 * @param attributeName - The name of the attribute you are trying to fetch
	 * @return - The XERAttribute which this compound construct contains
	 */
	public abstract XERAttribute getAttribute(String attributeName);

	/**
	 * 
	 * @return - The name of this XER Compound construct
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return - A collection of XERPrimaryKey attributes
	 */
	public Collection getPrimaryKeys() {
		return keyAttributes;
	}

	//	SHOULDN'T BE HERE. THEY ONLY APPLY TO XER ENTITIES
	//	/**
	//	 * @param parent - The parent XERCompoundConstruct in the XML hierarchy
	//	 */
	//	public abstract void setImplicitParent(XERCompoundConstruct parent);
	//	
	//	/**
	//	 * @return - Gets the parent XERStructure in the XML hierarchy(e.g. for 'name' it should be 'supplier')
	//	 */
	//	public abstract XERCompoundConstruct getImplicitParent();

	/**
	 * @return Returns the foreignKeyAttributes.
	 */
	public Collection getForeignKeyAttributes() {
		return foreignKeyAttributes;
	}

	public void createAutoKeyAttribute() {
		XERAutoPrimaryKey autoKey = xerBuilder.getXERFactory().createXERAutoPrimaryKey(this);
		keyAttributes.add(autoKey);
		attributes.put(autoKey.getName(), autoKey);
		//addConstruct(autoKey,1,1);
	}

}
