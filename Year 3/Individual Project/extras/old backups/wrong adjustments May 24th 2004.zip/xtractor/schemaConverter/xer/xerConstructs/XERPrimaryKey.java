/*
 * Created on 18-May-2004
 *
 */
package xtractor.schemaConverter.xer.xerConstructs;

import xtractor.schemaConverter.xer.XERBuilder;

/**
 * @author ss401
 * To create these, cast an existing XERAttribute and set the properties
 */
public class XERPrimaryKey extends XERAttribute {

	XERCompoundConstruct keyedCompoundConstruct;
	

	public XERPrimaryKey(XERAttribute attribute, XERCompoundConstruct xerCompoundConstruct, XERBuilder xerBuilder) {
		super(attribute.getName(), attribute.getType(), attribute.getMinOccurs(), attribute.getMaxOccurs(), xerBuilder);
		constraints = attribute.getConstraints();
		this.keyedCompoundConstruct = xerCompoundConstruct;
	}

}
