/*
 * Created on 24-May-2004
 *
 */
package xtractor.schemaConverter.xer.xerConstructs;

import xtractor.schemaConverter.xer.XERBuilder;

/**
 * @author ss401
 *
 */
public class XERAutoPrimaryKey extends XERPrimaryKey {

	/**
	 * @param attribute
	 * @param entity
	 * @param xerBuilder
	 */
	public XERAutoPrimaryKey(XERAttribute attribute, XERCompoundConstruct xerCompoundConstruct, XERBuilder xerBuilder) {
		super(attribute, xerCompoundConstruct, xerBuilder);
	}

}
