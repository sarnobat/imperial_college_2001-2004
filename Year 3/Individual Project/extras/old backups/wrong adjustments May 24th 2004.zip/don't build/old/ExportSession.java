/*
 * Created on 15-May-2004
 *
 */
package controller;

/**
 * @author ss401
 *
 */
public class ExportSession extends AbstractSession {

	public ExportSession(int fileId){
		//ControllerDatabaseManager
	}
}
