/*
 * Created on 01-Mar-2004
 *
 */
package xtractor.schemaConverter.xer;


/**
 * @author ss401
 *
 */
public class XERPrimaryKey extends XERAttribute {
	
	
}
