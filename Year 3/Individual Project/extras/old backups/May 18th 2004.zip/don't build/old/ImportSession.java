/*
 * Created on 15-May-2004
 */
package controller;

import org.apache.log4j.Logger;

/**
 * @author ss401
 */

public class ImportSession extends AbstractSession {
	Logger logger = Logger.getLogger(this.getClass());
}
