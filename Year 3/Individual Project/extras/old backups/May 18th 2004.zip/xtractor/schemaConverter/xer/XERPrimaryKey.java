/*
 * Created on 01-Mar-2004
 *
 */
package xtractor.schemaConverter.xer;


/**
 * @author ss401
 *
 */
public class XERPrimaryKey extends XERAttribute {
	
	XEREntity keyedEntity;
	
	/**
	 * Constructor used for creating AUTO primary key attributes. Do not use if the entity
	 * specifies key attributes or elements of its own.
	 * @param keyedEntity - The entity which a primary key needs to be created for
	 */
	public XERPrimaryKey(XEREntity keyedEntity) {
		//super(keyedEntity);
		this.keyedEntity = keyedEntity;
		setProperties("ID","xsd:primary_key_auto_number","required");
		// "primary_key_auto_number" isn't really and xsd keyword
	}
	
	/*public XERPrimaryKey(Element attribute,XEREntity keyedEntity){
		super(attribute);
		this.keyedEntity = keyedEntity;
		//setProperties(attribute.getAttributeValue("name"),attribute.getAttributeValue("type",))
	}*/
}
