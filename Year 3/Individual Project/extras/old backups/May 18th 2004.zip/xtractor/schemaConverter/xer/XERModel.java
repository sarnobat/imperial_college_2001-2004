/*
 * Created on 24-Feb-2004
 *
 */
package xtractor.schemaConverter.xer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.Logger;

/**
 * @author ss401
 *
 */
public class XERModel {

	Logger logger = Logger.getLogger(this.getClass());
	Map relationships;
	Map entities;
	String name;
	XEREntity root;

	XERModel(String modelName) {
		this.name = modelName;
		this.relationships = new TreeMap();
		this.entities = new TreeMap();
	}

	/**
	 * @return - A collection of XEREntity for each entity that exists in the XER Model  
	 */
	public Collection getEntities() {
		Collection xerEntities = entities.values();
		List l = new ArrayList(xerEntities);
		return xerEntities;
	}

	/**
	 * @return - A Collection of XERRelationship for all relationships that exist in this XER model
	 */
	public Collection getRelationships() {
		return relationships.values();
	}

	/**
	 * Adds an entity to this model
	 * @param entity - The entity to be added
	 */
	void addEntity(XEREntity entity) {
		entities.put(entity.getName(), entity);
	}
	/**
	 * Adds a relationship to this model
	 * @param entity - The relationship to be added
	 */
	void addRelationship(XERRelationship relationship) {
		relationships.put(relationship.getName()+"(" + relationship.getParent().getName() + "-->" + relationship.getChild().getName() + ")", relationship);
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		String str = "";
		str += "ENTITIES:\n";
		for (Iterator iter = entities.values().iterator(); iter.hasNext();) {
			XEREntity entity = (XEREntity) iter.next();
			String entityName = entity.getName();
			str += entityName + "(";
			Collection attributes = entity.getAttributes();
			for (Iterator iterator = attributes.iterator(); iterator.hasNext();) {
				XERAttribute attribute = (XERAttribute) iterator.next();
				str += attribute.getName();
				if (iterator.hasNext()) {
					str += ",";
				}

			}
			str += ")";
			if (iter.hasNext()) {
				str += "\n";
			}

		}
		str += "\nRELATIONSHIPS:\n";
		for (Iterator iter = relationships.keySet().iterator(); iter.hasNext();) {
			String relationshipName = (String) iter.next();
			str += relationshipName;
			if (iter.hasNext()) {
				str += ",";
			}
		}
		return str;
	}

	/**
	 * @param rootEntity - The XER Entity which is the root of the model
	 */
	public void setRootElement(XEREntity rootEntity) {
		this.root = rootEntity;		
	}

	/**
	 * @return - The XER entity which is the root of the model
	 */
	public XEREntity getRootEntity() {
		return root;
	}

	/**
	 * @return - The name of the XER model
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name - The name of the entity
	 * @return - True if the entity with the given name already exists
	 */
	public boolean entityExists(String name) {
		return entities.keySet().contains(name);
	}

	/**
	 * @param name
	 * @return
	 */
	public XEREntity getEntity(String name) {
		return (XEREntity) entities.get(name);
	}

}
