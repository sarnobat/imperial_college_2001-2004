/*
 * Created on 24-Feb-2004
 *
 */
package xtractor.schemaConverter.xer;

import java.util.Collection;
import java.util.LinkedList;

import org.apache.log4j.Logger;

/**
 * @author ss401
 *
 */
public class XERAttribute {
	Logger logger = Logger.getLogger(this.getClass());
	String type;
	boolean required;
	String name;
	
	// Constraints - required by trigger
	int strMinLength;
	int strMaxLength;
	int strExactLength;
	int numMinVal;
	int numMaxVal;
	int numTotalDigits;
	int numFactionDigits;
	Collection enumerationValues;
	
	
	protected XERAttribute(){
	}
	
	XERAttribute(String name,String type,String use){
		enumerationValues = new LinkedList();
		setProperties(name,type,use);
	}
	
	/**
	 * Constructor used for creating non-foreign key attributes
	 * @param attributeComponent - The JDom representation of an xsd:attribute component
	 */
	/*XERAttribute(Element attributeComponent) {
		setProperties(
			attributeComponent.getAttributeValue("name"),
			attributeComponent.getAttributeValue("type"),
			attributeComponent.getAttributeValue("use"));
	}*/
	
	/**
	 * Private constructor which performs the common operations of the public constructors
	 * @param name - The name of the attribute
	 * @param type - The XML Schema type of the attribte
	 * @param requirement - "optional", "required" etc. 
	 */
	protected void setProperties(String name, String type, String requirement) {
		this.name = name;
		this.type = type;
		this.required = resolveCardinality(requirement);
	}

	/**
	 * Converts cardinalities expressed in XML schema terminology into boolean
	 * @param requirement - "required","optional" etc.
	 * @return - True if the attribute is required
	 */
	public boolean resolveCardinality(String requirement) {
		if (requirement == null) {
			//Presumalby this is correct
			return true;
		}
		else if (requirement.equals("required")) {
			return true;
		}
		else if (requirement.equals("optional")) {
			return false;
		}
		else {
			logger.error("Invalid requirement specification");
			return false;
		}
	}
	


	/**
	 * @return - The XML Schema datatype which this attribute conforms to
	 */
	public String getType() {
		return type;
	}

	/**
	 * @return - Indicates whether this attribute is required in the entity
	 */
	public boolean isRequired() {
		return required;

	}
	/**
	 * @return - The name of the attribute
	 */
	public String getName() {
		return name;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return getName();
	}

	/**
	 * @return
	 */
	public int getNumFactionDigits() {
		return numFactionDigits;
	}

	/**
	 * @return
	 */
	public int getNumMaxVal() {
		return numMaxVal;
	}

	/**
	 * @return
	 */
	public int getNumMinVal() {
		return numMinVal;
	}

	/**
	 * @return
	 */
	public int getNumTotalDigits() {
		return numTotalDigits;
	}

	/**
	 * @return
	 */
	public int getStrExactLength() {
		return strExactLength;
	}

	/**
	 * @return
	 */
	public int getStrMaxLength() {
		return strMaxLength;
	}

	/**
	 * @return
	 */
	public int getStrMinLength() {
		return strMinLength;
	}

	/**
	 * @param i
	 */
	public void setNumFactionDigits(int i) {
		numFactionDigits = i;
	}

	/**
	 * @param i
	 */
	public void setNumMaxVal(int i) {
		numMaxVal = i;
	}

	/**
	 * @param i
	 */
	public void setNumMinVal(int i) {
		numMinVal = i;
	}

	/**
	 * @param i
	 */
	public void setNumTotalDigits(int i) {
		numTotalDigits = i;
	}

	/**
	 * @param i
	 */
	public void setStrExactLength(int i) {
		strExactLength = i;
	}

	/**
	 * @param i
	 */
	public void setStrMaxLength(int i) {
		strMaxLength = i;
	}

	/**
	 * @param i
	 */
	public void setStrMinLength(int i) {
		strMinLength = i;
	}
	
	
	public void addEnumerationValue(String s){
		enumerationValues.add(s);		
	}
	
	/**
	 * 
	 * @return - A collection of Strings for each possible value of the attribute
	 */
	public Collection getEnumerationValues(){
		return enumerationValues;
	}

}
