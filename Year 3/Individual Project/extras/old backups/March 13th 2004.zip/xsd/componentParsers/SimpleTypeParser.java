/*
 * Created on 08-Mar-2004
 *
 */
package xsd.componentParsers;

/**
 * @author ss401
 *
 */
public class SimpleTypeParser {

}
