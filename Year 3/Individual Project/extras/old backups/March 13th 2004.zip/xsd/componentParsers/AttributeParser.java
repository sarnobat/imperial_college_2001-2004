/*
 * Created on 25-Feb-2004
 *
 */
package xsd.componentParsers;

import org.apache.log4j.Logger;
import org.jdom.Element;

import xer.XERAttribute;
import xer.XERBuilder;
import xer.XEREntity;
import xsd.XSDSchemaManipulator;

/**
 * @author ss401
 *
 */
public class AttributeParser {
	Logger logger = Logger.getLogger(this.getClass());
	XSDSchemaManipulator schemaWalker;
	XERBuilder xerBuilder;

	public AttributeParser(XSDSchemaManipulator schemaWalker, XERBuilder xerBuilder) {
		this.schemaWalker = schemaWalker;
		this.xerBuilder = xerBuilder;
	}
	/**
	 * @param child - JDOM representation of the xsd:attribute component
	 * @param parent - XEREntity which this attribute belongs to
	 */
	public void parseAttribute(Element attribute, XEREntity parent) {
		String attributeType = attribute.getAttributeValue("type");
		String schemaComponentPrefix = attribute.getDocument().getRootElement().getNamespacePrefix();
		
		// See if the xsd:attribute is a PRIMARY key (Note: it can never act as a FOREIGN key)
		if (attributeType != null && attributeType.equals(schemaComponentPrefix + ":ID")) {
			//parent.addKeyAttribute(new XERAttribute(attribute));
			xerBuilder.getXERFactory().createXERPrimaryKey(attribute,parent);
		}
		else {
			XERAttribute xerAttribute = new XERAttribute(attribute);
			parent.addAttribute(xerAttribute);
		}
	}
}
