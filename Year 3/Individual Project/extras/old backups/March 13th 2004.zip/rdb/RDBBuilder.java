/*
 * Created on 24-Feb-2004
 *
 */
package rdb;

import java.util.Collection;
import java.util.Iterator;

import org.apache.log4j.Logger;

import xer.XERAttribute;
import xer.XEREntity;
import xer.XERForeignKey;
import xer.XERModel;
import xer.XERPrimaryKey;
import xsd.XSDSchemaManipulator;
/*
 * TODO: Need to create Triggers for schema datatypes which don't correspond exactly to SQL datatypes
 */
/**
 * @author ss401
 * Takes an XER model and generates a relational database model 
 */
public class RDBBuilder {
	private XERModel model;
	Logger logger = Logger.getLogger(this.getClass());
	SQLMapper sqlMapper;

	/**
	 * @param xerModel - The XER model to convert to a relational schema
	 */
	public RDBBuilder(XERModel xerModel, String schemaURL) {
		this.model = xerModel;
		XSDSchemaManipulator schemaWalker = new XSDSchemaManipulator(schemaURL);
		String schemaPrefix = schemaWalker.getRootElement().getNamespace().getPrefix();
		this.sqlMapper = new SQLMapper(schemaPrefix);
	}
	/**
	 * Note the XERModel will be changed by this method because the relationships will be converted into
	 * attributes which are foreign keys
	 * @param xerModel
	 * @return - The SQL which when invoked will build the database schema for the XER Model
	 */
	public String build() {
		String sql = "";
		Collection entities = model.getEntities();
		

		// Go through each XER Entity and generate the SQL to create the table
		for (Iterator iter = entities.iterator(); iter.hasNext();) {
			
			XEREntity entity = (XEREntity) iter.next();
			sql += "CREATE TABLE " + entity.getName() + " {\n";
			
			// specify each row that should exist in the table
			for (Iterator iterator = entity.getAttributes().iterator(); iterator.hasNext();) {
				XERAttribute attribute = (XERAttribute) iterator.next();
				String sqlDataType = sqlMapper.resolveDataType(attribute.getType());
				String sqlNullCondition = sqlMapper.resolveAttriubteCardinality(attribute.isRequired());
				//String sqlReference = sqlMapper.resolveAttributeReference(attribute.getReferredEntity());
				sql += "\t" + attribute.getName() + "\t" + sqlDataType + "\t" + sqlNullCondition;
				if (attribute instanceof XERPrimaryKey) {
					sql += "\tPRIMARY KEY";
				}
				else if (attribute instanceof XERForeignKey) {
					XERForeignKey foreignKeyAttribute = (XERForeignKey) attribute;
					XEREntity foreignEntity = foreignKeyAttribute.getForeignEntity();
					sql += "\tREFERENCES " + foreignEntity.getName() + "(" + foreignEntity.getKeyAttributeNames() + ")";
				}
				if (iterator.hasNext()) {
					sql += ",\n";
				}
			}

			sql += "\n}\n\n";
		}

		return sql;
	}

}
