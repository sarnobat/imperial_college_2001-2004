/*
 * Created on 08-Mar-2004
 *
 */
package xer;

import org.apache.log4j.Logger;
import org.jdom.Element;

/**
 * @author ss401
 * Factory for creating all XER Components.
 */
public class XERFactory {

	Logger logger = Logger.getLogger(this.getClass());
	XERBuilder builder;

	/**
	 * The builder is required so that the factory has access to the model
	 * @param builder - The XERBuilder constructing the XER model
	 */
	public XERFactory(XERBuilder builder) {
		this.builder = builder;
	}

	/**
	 * @return - A new XER Model
	 */
	public XERModel createXERModel(String modelName) {
		return new XERModel(modelName);
	}

	/**
	 * 
	 * @param name - the name of the entity
	 * @return - A new entity with the given name 
	 */
	public XEREntity createXEREntity(String name) {
		return new XEREntity(name, builder.getModel());
	}

	/**
	 * Note that the keyAttribute constitute only part of the foreign key 
	 * @param xerRelationship
	 * @param keyAttribute
	 * @return
	 */
	public XERForeignKey createXERForeignKey(XERRelationship xerRelationship,XERAttribute keyAttribute) {
		//new XERForeignKey(xerRelationship.getName(), keyAttribute, foreignEntity, xerRelationship.getMinOccurs());
		return new XERForeignKey(xerRelationship,keyAttribute);
	}
	
	/**
	 * The key is automatically added to 'entity'
	 * This should only be used for creating keys for entities which do not have any key specified
	 * @param entity - The XER Entity which has no primary key defined in the xml schema
	 * @return The XERPrimaryKey attribute
	 */
	public XERPrimaryKey assignAutoXERPrimaryKey(XEREntity entity) {
		//foreignEntity.addKeyAttribute(new XERPrimaryKey(foreignEntity));
		XERPrimaryKey key = new XERPrimaryKey(entity);
		entity.addKeyAttribute(key);
		return key;
	}
	/**
	 * @param attribute - The JDom model of the xsd:attribute which acts as a primary key
	 * @param entity - The entity that the attribute acts as the primary key for
	 * @return - An XERPrimaryKey model of the attribute
	 */
	public XERPrimaryKey createXERPrimaryKey(Element xsdAttribute,XEREntity entity) {
		//entity.addKeyAttribute(new XEaRAttribute(attribute));
		XERPrimaryKey key = new XERPrimaryKey(xsdAttribute,entity);
		entity.addKeyAttribute(key);
		return key;
	}
	
	/*public void createXERAttribute(Element xsdElement, XEREntity parent) {
		XERAttribute attribute = new XERAttribute(xsdElement);
		parent.addAttribute(attribute);
		
	}*/
}
