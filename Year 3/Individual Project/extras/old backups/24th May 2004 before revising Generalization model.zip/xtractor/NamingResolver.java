package xtractor;

/*
 * Created on 17-Mar-2004
 *
 */

import java.io.File;

/**
 * @author ss401
 *  
 */

public class NamingResolver {

	/**
	 * xsd schema filename --> sql schema name
	 * @param xsdFile - An xml Schema file
	 * @return - The name of the schema that this corresponds to in the database
	 */
	public static String getSchemaName(File xsdFile){
		String fileName = xsdFile.getName();
		String[] fileFragments = fileName.split(".x");
		return fileFragments[0];
	}
}
