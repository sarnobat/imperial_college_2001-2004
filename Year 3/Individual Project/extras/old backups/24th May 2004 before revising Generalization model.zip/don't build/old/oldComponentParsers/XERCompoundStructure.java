/*
 * Created on 18-May-2004
 *
 */
package xtractor.schemaConverter.xsd.componentParsers;

/**
 * @author ss401
 * This could be an XER entity or Generalization (+ others?)
 */
public abstract class XERCompoundStructure {

}
