package databaseConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

/*
 * Created on 17-Mar-2004
 *  
 */

/**
 * @author ss401
 *  
 */

public class DatabaseConnection {
	static Logger logger = Logger.getLogger("DatabaseConnection");
	static Connection conn;

	public static Connection getConnection() {

		if (conn == null) {
			try {
				Class.forName("org.postgresql.Driver");
				conn = DriverManager.getConnection("jdbc:postgresql://db/ss401", "ss401", "ss401");

			} catch (ClassNotFoundException e) {
				logger.fatal("Couldn't locate database driver.");
				System.exit(-1);
			} catch (SQLException e) {
				logger.fatal("Couldn't connect to database.");
				System.exit(-1);
			}
		}
		return conn;
	}

	public static void closeConnection() {
		if(conn != null){
			try {
				conn.close();
			} catch (SQLException e) {
				System.err.println("Couldn't close connection");
			}
		}
	}
	
}