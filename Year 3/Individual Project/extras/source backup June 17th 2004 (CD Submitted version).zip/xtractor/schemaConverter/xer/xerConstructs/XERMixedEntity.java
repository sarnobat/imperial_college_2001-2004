/*
 * Created on 27-May-2004
 *
 */
package xtractor.schemaConverter.xer.xerConstructs;

import xtractor.schemaConverter.xer.XERBuilder;

/**
 * @author ss401
 *
 */
public class XERMixedEntity extends XEREntity {

	/**
	 * @param name
	 * @param xerBuilder
	 */
	public XERMixedEntity(String name, XERBuilder xerBuilder) {
		super(name, xerBuilder);
	}

}
