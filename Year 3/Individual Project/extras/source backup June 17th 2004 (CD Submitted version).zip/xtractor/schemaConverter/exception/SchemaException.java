/*
 * Created on 17-Mar-2004
 *
 */
package xtractor.schemaConverter.exception;

/**
 * @author ss401
 *
 */

public class SchemaException extends Exception {

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		return "Couldn't convert XML schema";
	}

}
