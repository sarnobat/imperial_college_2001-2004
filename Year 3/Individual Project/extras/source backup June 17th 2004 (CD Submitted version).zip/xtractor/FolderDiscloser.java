/*
 * Created on 16-Jun-2004
 *
 */
package xtractor;

/**
 * @author ss401
 *
 */
public class FolderDiscloser {
	public static String workingFolderPath;
}
