/*
 * Created on 31-May-2004
 *
 */
package GUI.windows.dialog.rdbCreator;

import GUI.GUIController;
import GUI.windows.dialog.AbstractDialogFrame;

/**
 * @author ss401
 *
 */
public class RDBCreationFrame extends AbstractDialogFrame {

	/**
	 * @param controller
	 */
	public RDBCreationFrame(RDBCreationFrameController controller,GUIController guiController) {
		super(guiController);
	}

}
