/*
 * Created on 01-Jun-2004
 *
 */
package GUI.windows.dialog.regenerator;

import GUI.GUIController;
import GUI.windows.dialog.AbstractDialogFrame;

/**
 * @author ss401
 *
 */
public class RegeneratorDialog extends AbstractDialogFrame {

	/**
	 * @param guiController
	 */
	public RegeneratorDialog(GUIController guiController) {
		super(guiController);
	}

}
