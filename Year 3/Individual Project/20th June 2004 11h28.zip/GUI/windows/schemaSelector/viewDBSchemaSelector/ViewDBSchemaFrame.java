/*
 * Created on 17-Jun-2004
 *
 */
package GUI.windows.schemaSelector.viewDBSchemaSelector;

import GUI.GUIController;
import GUI.windows.schemaSelector.AbstractSchemaSelectorController;
import GUI.windows.schemaSelector.AbstractSelectSchemaFrame;

/**
 * @author ss401
 *
 */
public class ViewDBSchemaFrame extends AbstractSelectSchemaFrame {

	/**
	 * @param c
	 * @param dataImporterController
	 */
	public ViewDBSchemaFrame(GUIController c, AbstractSchemaSelectorController dataImporterController) {
		super(c, dataImporterController);
	}

}
