/*
 * Created on 17-Jun-2004
 *
 */
package GUI.windows.viewDatabase;

import GUI.GUIController;
import GUI.windows.XTractorFrame;

/**
 * @author ss401
 *
 */
public class DatabaseViewerFrame extends XTractorFrame {

	/**
	 * @param c
	 */
	public DatabaseViewerFrame(GUIController c) {
		super(c);
	}

}
